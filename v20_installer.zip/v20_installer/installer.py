"""
CND Manager — Instalador GUI
Versão 1.0

Guia a instalação:
  1. Escolha da pasta de instalação
  2. Escolha da pasta de dados (bancos SQLite)
  3. Escolha da pasta de backup
  4. Copia os arquivos e gera config.json com os caminhos escolhidos
  5. Cria launcher (CND_Manager.bat) na pasta de instalação

Execute com: python installer.py
Para gerar executável: pyinstaller --onefile --windowed --name CND_Installer installer.py
"""
import sys, os, shutil, json, subprocess
from pathlib import Path

try:
    import customtkinter as ctk
    from tkinter import filedialog, messagebox
except ImportError:
    print("Instale customtkinter: pip install customtkinter")
    sys.exit(1)

APP_NAME    = "CND Manager"
APP_VERSION = "1.0.0"

# Arquivos/pastas a copiar (relativos ao diretório do instalador)
_SOURCE_ITEMS = [
    "app", "data", "backup", "main.py",
    "requirements.txt", "config.json",
]

# ─── Utilitários ──────────────────────────────────────────────────────────────

def _pick_folder(title: str, initial: str) -> str | None:
    root = ctk.CTkToplevel()
    root.withdraw()
    folder = filedialog.askdirectory(title=title, initialdir=initial)
    root.destroy()
    return folder or None


def _copy_source(src_dir: Path, dst_dir: Path):
    """Copia todos os itens do instalador para o destino."""
    dst_dir.mkdir(parents=True, exist_ok=True)
    for item in _SOURCE_ITEMS:
        src = src_dir / item
        dst = dst_dir / item
        if src.is_dir():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        elif src.is_file():
            shutil.copy2(src, dst)


def _write_config(install_dir: Path, data_dir: Path, backup_dir: Path):
    """Lê o config.json base e atualiza os caminhos."""
    cfg_path = install_dir / "config.json"
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception:
        cfg = {}

    cfg.setdefault("paths", {})
    cfg["paths"]["main_db"]        = str(data_dir / "main.db")
    cfg["paths"]["catalog_db"]     = str(data_dir / "catalog.db")
    cfg["paths"]["integrity_file"] = str(data_dir / "integrity.dat")
    cfg["paths"]["lock_file"]      = str(data_dir / "app.lock")
    cfg["paths"]["backup_dir"]     = str(backup_dir)

    cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def _create_launcher(install_dir: Path):
    """Cria CND_Manager.bat que chama python main.py na pasta de instalação."""
    bat = install_dir / "CND_Manager.bat"
    bat.write_text(
        f'@echo off\n'
        f'cd /d "{install_dir}"\n'
        f'python main.py\n'
        f'if errorlevel 1 pause\n',
        encoding="cp1252"
    )
    bat.write_bytes(bat.read_bytes().replace(b"\n", b"\r\n"))


def _move_data_dirs(install_dir: Path, data_dir: Path, backup_dir: Path):
    """Move (ou cria) as pastas data e backup para os locais escolhidos."""
    # Mover data/
    src_data = install_dir / "data"
    if data_dir != src_data:
        data_dir.mkdir(parents=True, exist_ok=True)
        for f in src_data.iterdir():
            dst = data_dir / f.name
            if not dst.exists():
                shutil.copy2(f, dst)
        shutil.rmtree(src_data, ignore_errors=True)

    # Criar backup/
    backup_dir.mkdir(parents=True, exist_ok=True)
    src_bkp = install_dir / "backup"
    if backup_dir != src_bkp:
        src_bkp.rmdir() if src_bkp.exists() and not any(src_bkp.iterdir()) else None


# ─── Janela principal do instalador ──────────────────────────────────────────

class InstallerApp(ctk.CTk):

    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} — Instalador v{APP_VERSION}")
        self.geometry("700x560")
        self.resizable(False, False)
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"700x560+{(sw-700)//2}+{(sh-560)//2}")

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        # Caminhos default
        src_dir = Path(getattr(sys, "_MEIPASS", Path(__file__).parent)).resolve()
        default_install = Path.home() / "CND_Manager"
        default_data    = default_install / "data"
        default_backup  = default_install / "backup"

        self._src_dir      = src_dir
        self._install_var  = ctk.StringVar(value=str(default_install))
        self._data_var     = ctk.StringVar(value=str(default_data))
        self._backup_var   = ctk.StringVar(value=str(default_backup))
        self._auto_data    = True   # pasta data segue a de instalação

        self._build()

    def _build(self):
        # ── Cabeçalho ──────────────────────────────────────────────────
        hdr = ctk.CTkFrame(self, fg_color="#1f538d", corner_radius=0)
        hdr.pack(fill="x")
        ctk.CTkLabel(hdr, text=f"  {APP_NAME}",
                     font=ctk.CTkFont(size=20, weight="bold"),
                     text_color="white").pack(side="left", pady=16, padx=16)
        ctk.CTkLabel(hdr, text=f"v{APP_VERSION}",
                     font=ctk.CTkFont(size=11),
                     text_color="#aaccff").pack(side="right", padx=16)

        # ── Corpo ───────────────────────────────────────────────────────
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=30, pady=20)

        ctk.CTkLabel(body,
            text="Bem-vindo ao instalador do CND Manager.\n"
                 "Defina os caminhos abaixo e clique em Instalar.",
            font=ctk.CTkFont(size=12), justify="left",
            text_color="gray").pack(anchor="w", pady=(0, 16))

        def folder_row(parent, label, var, pick_cmd, row):
            ctk.CTkLabel(parent, text=label, anchor="w",
                         font=ctk.CTkFont(size=12, weight="bold"),
                         width=160).grid(row=row, column=0, sticky="w", pady=6)
            entry = ctk.CTkEntry(parent, textvariable=var, width=360)
            entry.grid(row=row, column=1, sticky="ew", padx=(8,6), pady=6)
            ctk.CTkButton(parent, text="…", width=36, command=pick_cmd).grid(
                row=row, column=2, pady=6)
            return entry

        grid = ctk.CTkFrame(body, fg_color="transparent")
        grid.pack(fill="x")
        grid.grid_columnconfigure(1, weight=1)

        folder_row(grid, "Pasta de instalação:",
                   self._install_var, self._pick_install, 0)
        folder_row(grid, "Pasta de dados (DB):",
                   self._data_var,    self._pick_data,    1)
        folder_row(grid, "Pasta de backup:",
                   self._backup_var,  self._pick_backup,  2)

        # Aviso
        ctk.CTkLabel(body,
            text="💡  Para uso em rede: defina a pasta de instalação em um caminho\n"
                 "    de rede acessível a todos os usuários (ex: \\\\servidor\\CND_Manager).\n"
                 "    Pasta de dados e backup podem estar no mesmo local ou separadas.",
            font=ctk.CTkFont(size=11), justify="left",
            text_color="#aaaaaa").pack(anchor="w", pady=(16, 0))

        ctk.CTkLabel(body,
            text="⚠  Requisito: Python 3.11+ instalado na máquina onde o app será executado.",
            font=ctk.CTkFont(size=11), justify="left",
            text_color="#ffcc66").pack(anchor="w", pady=(8, 0))

        # ── Barra de progresso ─────────────────────────────────────────
        self._progress = ctk.CTkProgressBar(body, width=600)
        self._progress.set(0)
        self._progress.pack(fill="x", pady=(20, 4))

        self._status_lbl = ctk.CTkLabel(body, text="",
                                         font=ctk.CTkFont(size=11),
                                         text_color="gray")
        self._status_lbl.pack(anchor="w")

        # ── Botões ─────────────────────────────────────────────────────
        bf = ctk.CTkFrame(self, fg_color="transparent")
        bf.pack(fill="x", padx=30, pady=(0, 20))
        self._btn_install = ctk.CTkButton(
            bf, text="Instalar", width=140, height=40,
            font=ctk.CTkFont(size=13, weight="bold"),
            command=self._install)
        self._btn_install.pack(side="left")
        ctk.CTkButton(bf, text="Cancelar", width=100, height=40,
                      fg_color="gray30", command=self.quit).pack(side="right")

    # ── Pickers ────────────────────────────────────────────────────────────────

    def _pick_install(self):
        folder = filedialog.askdirectory(title="Pasta de instalação",
                                          initialdir=self._install_var.get())
        if folder:
            self._install_var.set(folder)
            if self._auto_data:
                self._data_var.set(str(Path(folder) / "data"))
                self._backup_var.set(str(Path(folder) / "backup"))

    def _pick_data(self):
        folder = filedialog.askdirectory(title="Pasta de dados",
                                          initialdir=self._data_var.get())
        if folder:
            self._data_var.set(folder)
            self._auto_data = False

    def _pick_backup(self):
        folder = filedialog.askdirectory(title="Pasta de backup",
                                          initialdir=self._backup_var.get())
        if folder:
            self._backup_var.set(folder)

    # ── Instalação ─────────────────────────────────────────────────────────────

    def _set_status(self, msg: str, progress: float):
        self._status_lbl.configure(text=msg)
        self._progress.set(progress)
        self.update()

    def _install(self):
        install_dir = Path(self._install_var.get().strip())
        data_dir    = Path(self._data_var.get().strip())
        backup_dir  = Path(self._backup_var.get().strip())

        if not self._install_var.get().strip():
            messagebox.showwarning("Instalador", "Defina a pasta de instalação.")
            return

        self._btn_install.configure(state="disabled")

        try:
            self._set_status("Copiando arquivos…", 0.2)
            _copy_source(self._src_dir, install_dir)

            self._set_status("Configurando pastas de dados…", 0.5)
            _move_data_dirs(install_dir, data_dir, backup_dir)

            self._set_status("Gravando configuração…", 0.7)
            _write_config(install_dir, data_dir, backup_dir)

            self._set_status("Criando launcher…", 0.85)
            _create_launcher(install_dir)

            self._set_status("✔  Instalação concluída!", 1.0)
            self._status_lbl.configure(text_color="#5cc85c")

            messagebox.showinfo(
                "Instalação concluída",
                f"O {APP_NAME} foi instalado com sucesso em:\n{install_dir}\n\n"
                f"Para iniciar o aplicativo, execute:\n{install_dir / 'CND_Manager.bat'}\n\n"
                f"Certifique-se de que Python 3.11+ está instalado na máquina."
            )
        except Exception as ex:
            self._set_status(f"Erro: {ex}", 0)
            self._status_lbl.configure(text_color="red")
            messagebox.showerror("Erro na instalação", str(ex))
            self._btn_install.configure(state="normal")


if __name__ == "__main__":
    app = InstallerApp()
    app.mainloop()
