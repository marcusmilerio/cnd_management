"""
Ponto de entrada — V8.

ORDEM CRÍTICA (resolve alerta de integridade a cada abertura):

  1. Validar manifesto ANTES do bootstrap
       → bootstrap faz INSERT OR IGNORE que muda o change counter do SQLite
         mesmo sem inserir dados novos, o que altera o hash do arquivo
       → validar antes garante que comparamos o arquivo "em repouso"

  2. Bootstrap (CREATE IF NOT EXISTS + migrações + seed idempotente)

  3. Login → auditar LOGIN_SUCCESS / LOGIN_FAILURE

  4. Exibir alerta de integridade (APÓS login para saber se é admin)
       → admin: pode reconhecer → regenera manifesto → não volta mais
       → não-admin: só "Encerrar"

  5. Troca de senha obrigatória se must_change_password = 1
       → banco muda → regenerar manifesto logo após

  6. Lock

  7. Janela principal

  8. Fechar:
       a. Backup dos .db
       b. Checkpoint WAL (TRUNCATE) para garantir que o .db está completo
       c. Gerar manifesto com o hash do arquivo após checkpoint
       d. Liberar lock
"""
import json, os, sqlite3
from pathlib import Path

import customtkinter as ctk

from app.database.connection import DatabaseManager
from app.database.bootstrap import bootstrap
from app.repositories.user_repository import UserRepository
from app.repositories.catalog_repository import CatalogRepository
from app.repositories.cnd_repository import CndRepository
from app.repositories.audit_repository import AuditRepository
from app.services.user_service import UserService
from app.services.catalog_service import CatalogService
from app.services.audit_service import AuditService
from app.services.cnd_service import CndService
from app.services.backup_service import BackupService
from app.security.lock_manager import LockManager
from app.security.integrity import build_manifest, save_manifest, validate_manifest, file_sha256
from app.core.exceptions import LockInUseError, IntegrityError


def _checkpoint(db_path: str):
    """Força WAL checkpoint para garantir que o .db está completo antes do hash."""
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        conn.close()
    except Exception:
        pass


def _regen_manifest(integrity_path, main_db, catalog_db, uid, ulogin, version, secret):
    """Checkpoint → hash → salvar manifesto. Sempre nesta ordem."""
    _checkpoint(main_db)
    _checkpoint(catalog_db)
    manifest = build_manifest(main_db, catalog_db, uid, ulogin, version, secret)
    save_manifest(integrity_path, manifest)


def _backup_if_needed(backup_service) -> bool:
    """
    Faz backup apenas na primeira abertura do dia.
    Registra a data em data/last_backup_date.txt.
    Retorna True se fez backup, False se já havia sido feito hoje.
    """
    import datetime
    marker = Path("data") / "last_backup_date.txt"
    today  = datetime.date.today().isoformat()
    try:
        if marker.exists() and marker.read_text().strip() == today:
            return False  # já fez backup hoje
        backup_service.run()
        marker.write_text(today, encoding="utf-8")
        return True
    except Exception:
        return False


def _build_detail(erro, manifest_anterior, main_db, catalog_db):
    lines = [f"Erro: {erro}", ""]
    if manifest_anterior:
        h_m = (manifest_anterior.get("main_db") or {}).get("sha256", "?")
        h_c = (manifest_anterior.get("catalog_db") or {}).get("sha256", "?")
        lines += [
            f"Hash main.db  esperado : {h_m[:32]}…",
            f"Hash main.db  atual    : {file_sha256(main_db)[:32]}…",
            f"Hash catalog  esperado : {h_c[:32]}…",
            f"Hash catalog  atual    : {file_sha256(catalog_db)[:32]}…",
        ]
    return "\n".join(lines)


def run_app():
    settings    = json.loads(Path("config.json").read_text(encoding="utf-8"))
    ctk.set_appearance_mode(settings["ui"]["theme"])
    ctk.set_default_color_theme(settings["ui"]["color_theme"])

    Path("data").mkdir(exist_ok=True)
    Path("backup").mkdir(exist_ok=True)

    db_key      = os.getenv(settings["security"]["sqlcipher_key_env"],
                             settings["security"]["fallback_sqlcipher_key"])
    hmac_secret = os.getenv(settings["security"]["hmac_secret_env"],
                             settings["security"]["fallback_hmac_secret"])

    base_dir        = Path("data").resolve()
    main_db_path    = str(base_dir / Path(settings["paths"]["main_db"]).name)
    catalog_db_path = str(base_dir / Path(settings["paths"]["catalog_db"]).name)
    integrity_path  = str(base_dir / Path(settings["paths"]["integrity_file"]).name)
    lock_path       = str(base_dir / Path(settings["paths"]["lock_file"]).name)
    backup_dir      = str(Path(settings["paths"]["backup_dir"]).resolve())

    main_dbm    = DatabaseManager(main_db_path, db_key)
    catalog_dbm = DatabaseManager(catalog_db_path, db_key)

    # ── PASSO 1: Validar manifesto ANTES do bootstrap ─────────────────
    integrity_file    = Path(integrity_path)
    integrity_ok      = True
    integrity_motivo  = ""
    integrity_detalhe = ""
    manifest_anterior = None

    if not integrity_file.exists():
        # Primeira execução — ainda não há manifesto, nenhum alerta
        integrity_ok = True   # será gerado após o bootstrap
    else:
        try:
            manifest_anterior = json.loads(integrity_file.read_text(encoding="utf-8"))
        except Exception:
            pass
        try:
            validate_manifest(integrity_path, main_db_path, catalog_db_path, hmac_secret)
        except IntegrityError as e:
            integrity_ok = False
            integrity_motivo = (
                "Os arquivos de banco de dados diferem do estado registrado "
                "no último manifesto de integridade.\n\n"
                "Isso pode indicar restauração de backup, substituição "
                "legítima dos arquivos, ou uma alteração não autorizada."
            )
            integrity_detalhe = _build_detail(str(e), manifest_anterior,
                                               main_db_path, catalog_db_path)
        except Exception as e:
            integrity_ok = False
            integrity_motivo = "Não foi possível validar o manifesto de integridade."
            integrity_detalhe = str(e)

    # ── PASSO 2: Bootstrap (pode alterar o .db — por isso é APÓS a validação) ─
    with main_dbm.session() as mc, catalog_dbm.session() as cc:
        bootstrap(mc, cc)

    # ── PASSO 3: Serviços ─────────────────────────────────────────────
    audit_service   = AuditService(AuditRepository(main_dbm))
    user_service    = UserService(UserRepository(main_dbm), audit_service)
    catalog_service = CatalogService(CatalogRepository(catalog_dbm))
    cnd_service     = CndService(CndRepository(main_dbm), catalog_service, audit_service)
    backup_service  = BackupService(
        main_db_path, catalog_db_path, backup_dir,
        max_backups=settings.get("backup", {}).get("max_backups", 10),
    )

    root = ctk.CTk()
    root.withdraw()

    # ── PASSO 4: Login ────────────────────────────────────────────────
    from app.ui.windows.login_window import LoginWindow
    login_win = LoginWindow(root, user_service)
    root.wait_window(login_win)
    if not login_win.authenticated_user:
        root.destroy()
        return

    user     = login_win.authenticated_user
    is_admin = (user.get("perfil") or "").upper() == "ADMIN"

    # ── PASSO 5: Alerta de integridade (APÓS login) ───────────────────
    if not integrity_ok:
        from app.ui.windows.integrity_alert_window import IntegrityAlertWindow
        alert = IntegrityAlertWindow(
            root,
            motivo        = integrity_motivo,
            detalhe       = integrity_detalhe,
            is_admin      = is_admin,
            manifest_info = manifest_anterior,
        )
        root.wait_window(alert)

        if alert.action == "cancel":
            root.destroy()
            return

        # Admin aprovou → regenerar manifesto (com checkpoint)
        _regen_manifest(integrity_path, main_db_path, catalog_db_path,
                        user["id"], user["login"], settings["version"], hmac_secret)
        audit_service.log_integrity_override(
            {"hash_esperado": (manifest_anterior or {}).get("main_db", {}).get("sha256", "?"),
             "hash_atual": file_sha256(main_db_path)},
            user,
        )

    elif not integrity_file.exists():
        # Primeira execução — gerar manifesto agora (bootstrap já rodou)
        _regen_manifest(integrity_path, main_db_path, catalog_db_path,
                        user["id"], user["login"], settings["version"], hmac_secret)

    # ── PASSO 6: Troca de senha obrigatória ───────────────────────────
    if user_service.needs_password_change(user):
        from app.ui.windows.change_password_window import ChangePasswordWindow
        cpw = ChangePasswordWindow(root, user_service, user, obrigatorio=True)
        root.wait_window(cpw)
        if not cpw.changed:
            root.destroy()
            return
        user = user_service.user_repo.get_by_id(user["id"]) or user
        # Banco mudou (senha) → atualizar manifesto
        _regen_manifest(integrity_path, main_db_path, catalog_db_path,
                        user["id"], user["login"], settings["version"], hmac_secret)

    # ── PASSO 7: Lock ─────────────────────────────────────────────────
    lock = LockManager(lock_path, settings["lock"]["stale_after_seconds"])
    session = None
    while session is None:
        try:
            session = lock.acquire(user["id"], user["login"], user["nome_usuario"])
        except LockInUseError as e:
            from app.ui.windows.lock_wait_window import LockWaitWindow
            wait_win = LockWaitWindow(
                root,
                lock_data     = e.lock_data,
                lock_manager  = lock,
                retry_seconds = settings["lock"]["retry_check_seconds"],
                stale_seconds = settings["lock"]["stale_after_seconds"],
                is_admin      = is_admin,
            )
            root.wait_window(wait_win)
            if wait_win.action == "cancel":
                root.destroy()
                return
            elif wait_win.action == "override":
                audit_service.log_lock_override(e.lock_data, user)
                lock.force_release()

    # ── PASSO 8: Janela principal ─────────────────────────────────────
    root.deiconify()
    root.title(settings["app_name"])
    # Iniciar maximizado
    try:
        root.state("zoomed")          # Windows
    except Exception:
        try:
            root.attributes("-zoomed", True)  # Linux
        except Exception:
            root.geometry("1280x720")

    from app.ui.windows.main_window import MainWindow
    app_win = MainWindow(
        root, settings, user, session,
        cnd_service, catalog_service, lock,
        user_service    = user_service,
        backup_service  = backup_service,
        main_db_path    = main_db_path,
        catalog_db_path = catalog_db_path,
        integrity_path  = integrity_path,
        hmac_secret     = hmac_secret,
    )
    app_win.pack(fill="both", expand=True)
    app_win.set_integrity_status(True, "")
    root.update()

    root.protocol("WM_DELETE_WINDOW", lambda: _on_close(
        lock, backup_service,
        main_db_path, catalog_db_path, integrity_path,
        user, settings["version"], hmac_secret, root,
    ))
    # Backup na primeira abertura do dia (em background, não bloqueia UI)
    root.after(2000, lambda: _backup_if_needed(backup_service))
    root.mainloop()


def _on_close(lock, backup_service, main_db, catalog_db,
              integrity_path, user, version, secret, root):
    """
    Fechar:
      1. Checkpoint WAL → garante que o .db contém tudo
      2. Manifesto com hash do .db pós-checkpoint
      3. Lock release
    Backup NÃO é feito ao fechar — ocorre na primeira abertura do dia.
    """
    try:
        _regen_manifest(integrity_path, main_db, catalog_db,
                        user["id"], user["login"], version, secret)
    except Exception:
        pass
    lock.release()
    root.destroy()
