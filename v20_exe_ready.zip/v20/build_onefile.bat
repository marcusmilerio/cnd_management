@echo off
setlocal
cd /d "%~dp0"

if not exist venv (
    python -m venv venv
)

call venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install pyinstaller
python -m PyInstaller --clean CND_Manager_onefile.spec

echo.
echo Build concluido.
echo EXE gerado em: dist\CND_Manager.exe
pause
