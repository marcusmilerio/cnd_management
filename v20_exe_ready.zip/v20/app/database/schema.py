"""
Schema V7.

Mudanças vs V6:
  - cnds: UNIQUE CONSTRAINT em (empresa_grupo_informado, filial_informada,
          cnpj_numeros, esfera, uf, orgao_emissor_informado)
  - usuarios: campo must_change_password INTEGER DEFAULT 0
  - schema_version: tabela de controle de versão do schema
"""

MAIN_SCHEMA = [
    """
    CREATE TABLE IF NOT EXISTS schema_version (
        version     INTEGER NOT NULL,
        aplicado_em TEXT    NOT NULL,
        descricao   TEXT
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS usuarios (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        uuid                TEXT    NOT NULL UNIQUE,
        nome_usuario        TEXT    NOT NULL,
        login               TEXT    NOT NULL UNIQUE,
        senha_hash          TEXT    NOT NULL,
        perfil              TEXT    NOT NULL,
        ativo               INTEGER NOT NULL DEFAULT 1,
        must_change_password INTEGER NOT NULL DEFAULT 0,
        ultimo_login_em     TEXT,
        criado_em           TEXT    NOT NULL,
        atualizado_em       TEXT,
        inativado_em        TEXT
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS cnds (
        id                          INTEGER PRIMARY KEY AUTOINCREMENT,
        uuid                        TEXT    NOT NULL UNIQUE,
        esfera                      TEXT    NOT NULL,
        empresa_grupo_id            INTEGER,
        empresa_grupo_informado     TEXT    NOT NULL,
        filial_id                   INTEGER,
        filial_informada            TEXT    NOT NULL,
        uf                          TEXT    NOT NULL,
        local_id                    INTEGER,
        local_informado             TEXT    NOT NULL,
        cnpj_informado              TEXT    NOT NULL,
        cnpj_numeros                TEXT    NOT NULL,
        inscricao_estadual          TEXT,
        inscricao_municipal         TEXT,
        orgao_emissor_id            INTEGER,
        orgao_emissor_informado     TEXT    NOT NULL,
        criticidade_id              INTEGER,
        criticidade_informada       TEXT    NOT NULL,
        status_cnd_id               INTEGER,
        status_cnd_informado        TEXT    NOT NULL,
        numero_certidao             TEXT,
        prazo_vencimento_texto      TEXT,
        mapeamento                  TEXT,
        informacoes_filial          TEXT,
        responsavel_id              INTEGER,
        responsavel_informado       TEXT,
        analista_filial_id          INTEGER,
        analista_filial_informado   TEXT,
        comunicacao_resumo          TEXT,
        obs_estracta                TEXT,
        status_processo_id          INTEGER,
        status_processo_informado   TEXT,
        obs_status                  TEXT,
        obs_filial                  TEXT,
        observacoes                 TEXT,
        data_emissao                TEXT    NOT NULL,
        data_validade               TEXT    NOT NULL,
        dias_para_vencer            INTEGER,
        caminho_pdf                 TEXT,
        registro_ativo              INTEGER NOT NULL DEFAULT 1,
        registro_status             TEXT    NOT NULL DEFAULT 'Ativo',
        motivo_inativacao           TEXT,
        criado_por_usuario_id       INTEGER NOT NULL,
        criado_em                   TEXT    NOT NULL,
        atualizado_por_usuario_id   INTEGER,
        atualizado_em               TEXT,
        inativado_por_usuario_id    INTEGER,
        inativado_em                TEXT,
        integrity_signature         TEXT,
        versao_registro             INTEGER NOT NULL DEFAULT 1,
        UNIQUE (
            empresa_grupo_informado,
            filial_informada,
            cnpj_numeros,
            esfera,
            uf,
            orgao_emissor_informado
        )
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS cnd_comunicacoes (
        id                      INTEGER PRIMARY KEY AUTOINCREMENT,
        cnd_id                  INTEGER NOT NULL,
        filial_impactada_texto  TEXT    NOT NULL,
        ordem_exibicao          INTEGER NOT NULL DEFAULT 0,
        ativo                   INTEGER NOT NULL DEFAULT 1,
        criado_por_usuario_id   INTEGER,
        criado_em               TEXT    NOT NULL,
        FOREIGN KEY (cnd_id) REFERENCES cnds(id),
        UNIQUE (cnd_id, filial_impactada_texto)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS audit_log (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        evento_tipo     TEXT    NOT NULL,
        tabela_alvo     TEXT    NOT NULL,
        registro_id     INTEGER,
        payload_json    TEXT,
        campo_alterado  TEXT,
        valor_anterior  TEXT,
        valor_novo      TEXT,
        motivo          TEXT,
        usuario_id      INTEGER,
        usuario_login   TEXT,
        maquina_nome    TEXT,
        evento_em       TEXT    NOT NULL,
        sessao_id       TEXT
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS integrity_events (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        evento_tipo     TEXT    NOT NULL,
        descricao       TEXT,
        hash_detectado  TEXT,
        hash_esperado   TEXT,
        usuario_id      INTEGER,
        maquina_nome    TEXT,
        evento_em       TEXT    NOT NULL,
        acao_tomada     TEXT
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS session_events (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        sessao_id       TEXT,
        usuario_id      INTEGER,
        usuario_login   TEXT,
        maquina_nome    TEXT,
        evento_tipo     TEXT    NOT NULL,
        evento_em       TEXT    NOT NULL,
        detalhes        TEXT
    );
    """,
    # Índices para performance dos filtros mais usados na grid principal
    "CREATE INDEX IF NOT EXISTS idx_cnds_ativo_validade ON cnds(registro_ativo, data_validade);",
    "CREATE INDEX IF NOT EXISTS idx_cnds_esfera ON cnds(esfera);",
    "CREATE INDEX IF NOT EXISTS idx_cnds_uf ON cnds(uf);",
    "CREATE INDEX IF NOT EXISTS idx_cnds_empresa ON cnds(empresa_grupo_informado);",
    "CREATE INDEX IF NOT EXISTS idx_cnds_cnpj ON cnds(cnpj_numeros);",
    "CREATE INDEX IF NOT EXISTS idx_cnds_orgao ON cnds(orgao_emissor_informado);",
    "CREATE INDEX IF NOT EXISTS idx_cnds_status_cnd ON cnds(status_cnd_informado);",
    "CREATE INDEX IF NOT EXISTS idx_audit_tipo ON audit_log(evento_tipo);",
    "CREATE INDEX IF NOT EXISTS idx_audit_usuario ON audit_log(usuario_login);",
    "CREATE INDEX IF NOT EXISTS idx_audit_em ON audit_log(evento_em DESC);",
]

CATALOG_SCHEMA = [
    "CREATE TABLE IF NOT EXISTS empresas_grupos (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL UNIQUE, nome_normalizado TEXT NOT NULL UNIQUE, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL, atualizado_em TEXT);",
    "CREATE TABLE IF NOT EXISTS filiais (id INTEGER PRIMARY KEY AUTOINCREMENT, empresa_grupo_id INTEGER, codigo_filial TEXT NOT NULL, codigo_filial_normalizado TEXT NOT NULL, descricao TEXT, descricao_normalizada TEXT, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL, atualizado_em TEXT);",
    "CREATE TABLE IF NOT EXISTS locais (id INTEGER PRIMARY KEY AUTOINCREMENT, empresa_grupo_id INTEGER, uf TEXT, local TEXT NOT NULL, local_normalizado TEXT NOT NULL, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL, atualizado_em TEXT);",
    "CREATE TABLE IF NOT EXISTS orgaos_emissores (id INTEGER PRIMARY KEY AUTOINCREMENT, esfera TEXT, uf TEXT, nome_orgao TEXT NOT NULL, nome_orgao_normalizado TEXT NOT NULL, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL, atualizado_em TEXT);",
    "CREATE TABLE IF NOT EXISTS criticidades (id INTEGER PRIMARY KEY AUTOINCREMENT, valor TEXT NOT NULL UNIQUE, valor_normalizado TEXT NOT NULL UNIQUE, ordem_exibicao INTEGER NOT NULL DEFAULT 0, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL, atualizado_em TEXT);",
    "CREATE TABLE IF NOT EXISTS status_cnd (id INTEGER PRIMARY KEY AUTOINCREMENT, valor TEXT NOT NULL UNIQUE, valor_normalizado TEXT NOT NULL UNIQUE, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL, atualizado_em TEXT);",
    "CREATE TABLE IF NOT EXISTS status_processo (id INTEGER PRIMARY KEY AUTOINCREMENT, valor TEXT NOT NULL UNIQUE, valor_normalizado TEXT NOT NULL UNIQUE, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL, atualizado_em TEXT);",
    "CREATE TABLE IF NOT EXISTS responsaveis (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL UNIQUE, nome_normalizado TEXT NOT NULL UNIQUE, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL, atualizado_em TEXT);",
    "CREATE TABLE IF NOT EXISTS analistas_filial (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL UNIQUE, nome_normalizado TEXT NOT NULL UNIQUE, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL, atualizado_em TEXT);",
    "CREATE TABLE IF NOT EXISTS esferas (id INTEGER PRIMARY KEY AUTOINCREMENT, codigo TEXT NOT NULL UNIQUE, descricao TEXT NOT NULL, ativo INTEGER NOT NULL DEFAULT 1);",
    "CREATE TABLE IF NOT EXISTS ufs (id INTEGER PRIMARY KEY AUTOINCREMENT, sigla TEXT NOT NULL UNIQUE, nome TEXT NOT NULL, ativo INTEGER NOT NULL DEFAULT 1);",
]

# Versão atual do schema
SCHEMA_VERSION = 2
