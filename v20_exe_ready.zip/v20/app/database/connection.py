"""
DatabaseManager — V7.

Adicionado: shared_session() — context manager que abre uma conexão
sem auto-commit, para uso em operações atômicas que envolvem múltiplas
escritas (ex: insert CND + insert audit_log).

O caller faz commit/rollback manualmente ou via with:
    with dbm.shared_session() as conn:
        conn.execute(...)   # CND
        conn.execute(...)   # audit_log
    # commit automático ao sair sem exceção
"""
from contextlib import contextmanager
from pathlib import Path
import sqlite3

try:
    from pysqlcipher3 import dbapi2 as sqlcipher
except Exception:
    sqlcipher = None


class DatabaseManager:
    def __init__(self, db_path: str, key: str, use_sqlcipher: bool = False) -> None:
        self.db_path = Path(db_path)
        self.key = key
        self.use_sqlcipher = False   # SQLCipher reservado para fase futura

    def connect(self) -> sqlite3.Connection:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        if self.use_sqlcipher and sqlcipher:
            conn = sqlcipher.connect(str(self.db_path))
            conn.execute(f"PRAGMA key = '{self.key}';")
        else:
            conn = sqlite3.connect(str(self.db_path))

        # Performance: WAL mode + ajustes de cache/sync
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA synchronous  = NORMAL;")
        conn.execute("PRAGMA cache_size   = -8000;")   # 8 MB de cache
        conn.execute("PRAGMA temp_store   = MEMORY;")
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.row_factory = sqlite3.Row   # acesso por nome de coluna
        return conn

    @contextmanager
    def session(self):
        """Sessão com auto-commit. Para operações únicas."""
        conn = self.connect()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def shared_session(self):
        """Alias para session() — mantido para compatibilidade."""
        return self.session()
