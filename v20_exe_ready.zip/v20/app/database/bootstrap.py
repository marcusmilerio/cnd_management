"""
Bootstrap do banco de dados.

Responsabilidades:
  1. Criar todas as tabelas (CREATE IF NOT EXISTS)
  2. Aplicar migrações pendentes
  3. Seed de dados obrigatórios no catálogo
  4. Garantir que admin existe com hash argon2 válido
  5. Registrar versão inicial se schema_version estiver vazia
"""
from app.core.normalizers import normalize_upper
from app.core.utils import now_iso, new_uuid
from app.database.schema import MAIN_SCHEMA, CATALOG_SCHEMA, SCHEMA_VERSION
from app.database.migrations import apply_migrations
from app.security.password_hasher import hash_password
from app.core.enums import Profile

UF_DATA = [
    ("AC","Acre"),("AL","Alagoas"),("AP","Amapá"),("AM","Amazonas"),
    ("BA","Bahia"),("CE","Ceará"),("DF","Distrito Federal"),("ES","Espírito Santo"),
    ("GO","Goiás"),("MA","Maranhão"),("MT","Mato Grosso"),("MS","Mato Grosso do Sul"),
    ("MG","Minas Gerais"),("PA","Pará"),("PB","Paraíba"),("PR","Paraná"),
    ("PE","Pernambuco"),("PI","Piauí"),("RJ","Rio de Janeiro"),("RN","Rio Grande do Norte"),
    ("RS","Rio Grande do Sul"),("RO","Rondônia"),("RR","Roraima"),("SC","Santa Catarina"),
    ("SP","São Paulo"),("SE","Sergipe"),("TO","Tocantins"),
]


def bootstrap(main_conn, catalog_conn) -> None:
    # 1. Criar tabelas
    for stmt in MAIN_SCHEMA:
        main_conn.execute(stmt)
    for stmt in CATALOG_SCHEMA:
        catalog_conn.execute(stmt)

    # 2. Aplicar migrações pendentes
    apply_migrations(main_conn, catalog_conn)

    now = now_iso()

    # 3. Seed catálogo
    for group in ["Bayer S.A.", "D&PL", "Monsanto"]:
        catalog_conn.execute(
            "INSERT OR IGNORE INTO empresas_grupos (nome, nome_normalizado, ativo, criado_em) VALUES (?, ?, 1, ?)",
            (group, normalize_upper(group), now),
        )
    for codigo, descricao in [("Federal","Federal"),("Estadual","Estadual"),("Municipal","Municipal")]:
        catalog_conn.execute(
            "INSERT OR IGNORE INTO esferas (codigo, descricao, ativo) VALUES (?, ?, 1)",
            (codigo, descricao),
        )
    for sigla, nome in UF_DATA:
        catalog_conn.execute(
            "INSERT OR IGNORE INTO ufs (sigla, nome, ativo) VALUES (?, ?, 1)",
            (sigla, nome),
        )
    for i, valor in enumerate(["Baixa","Média","Alta","Altíssima"], start=1):
        catalog_conn.execute(
            "INSERT OR IGNORE INTO criticidades (valor, valor_normalizado, ordem_exibicao, ativo, criado_em) VALUES (?, ?, ?, 1, ?)",
            (valor, normalize_upper(valor), i, now),
        )
    for valor in ["Negativa","Positiva","Positiva com efeito de Negativa"]:
        catalog_conn.execute(
            "INSERT OR IGNORE INTO status_cnd (valor, valor_normalizado, ativo, criado_em) VALUES (?, ?, 1, ?)",
            (valor, normalize_upper(valor), now),
        )
    for valor in ["Concluído","Em andamento","Pendente","Aguardando retorno"]:
        catalog_conn.execute(
            "INSERT OR IGNORE INTO status_processo (valor, valor_normalizado, ativo, criado_em) VALUES (?, ?, 1, ?)",
            (valor, normalize_upper(valor), now),
        )

    # 4. Garantir admin com hash argon2 válido
    cur = main_conn.execute("SELECT id, senha_hash, must_change_password FROM usuarios WHERE login = ?", ("admin",))
    row = cur.fetchone()

    if row is None:
        # Criar admin — must_change_password=1 para forçar troca na primeira entrada
        main_conn.execute(
            "INSERT INTO usuarios (uuid, nome_usuario, login, senha_hash, perfil, ativo, must_change_password, criado_em) "
            "VALUES (?, ?, ?, ?, ?, 1, 1, ?)",
            (new_uuid(), "Administrador", "admin", hash_password("admin123"), Profile.ADMIN, now),
        )
    else:
        admin_id, senha_hash, _ = row
        hash_valido = (
            isinstance(senha_hash, str)
            and senha_hash.startswith("$argon2")
            and len(senha_hash) > 50
            and "PLACEHOLDER" not in senha_hash
        )
        if not hash_valido:
            main_conn.execute(
                "UPDATE usuarios SET senha_hash = ?, must_change_password = 1, atualizado_em = ? WHERE id = ?",
                (hash_password("admin123"), now, admin_id),
            )

    # 5. Registrar versão inicial se schema_version estiver vazia
    count = main_conn.execute("SELECT COUNT(*) FROM schema_version").fetchone()[0]
    if count == 0:
        main_conn.execute(
            "INSERT INTO schema_version (version, aplicado_em, descricao) VALUES (?, ?, ?)",
            (SCHEMA_VERSION, now, "versão inicial"),
        )
