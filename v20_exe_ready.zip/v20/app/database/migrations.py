"""
Framework de migrações — V10.

Migrações adicionadas:
  3 — atualizado_em em usuarios (coluna pode não existir em bancos antigos)
  4 — inativado_por_usuario_id / inativado_em em cnds
  5 — must_change_password em usuarios (idempotente, já existia na v1)
"""
from app.core.utils import now_iso

_MIGRATIONS: list[tuple[int, str, callable]] = []


def _migration(version: int, desc: str):
    def decorator(fn):
        _MIGRATIONS.append((version, desc, fn))
        return fn
    return decorator


def _try_alter(conn, sql: str):
    """Executa ALTER TABLE ignorando erro se coluna já existe."""
    try:
        conn.execute(sql)
    except Exception:
        pass


@_migration(1, "Adicionar must_change_password em usuarios")
def _m1(main_conn, _):
    _try_alter(main_conn,
        "ALTER TABLE usuarios ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0")


@_migration(2, "Adicionar payload_json em audit_log")
def _m2(main_conn, _):
    _try_alter(main_conn,
        "ALTER TABLE audit_log ADD COLUMN payload_json TEXT")


@_migration(3, "Adicionar atualizado_em em usuarios")
def _m3(main_conn, _):
    _try_alter(main_conn,
        "ALTER TABLE usuarios ADD COLUMN atualizado_em TEXT")


@_migration(4, "Adicionar colunas de inativação em cnds")
def _m4(main_conn, _):
    for col_sql in [
        "ALTER TABLE cnds ADD COLUMN atualizado_por_usuario_id INTEGER",
        "ALTER TABLE cnds ADD COLUMN atualizado_em TEXT",
        "ALTER TABLE cnds ADD COLUMN inativado_por_usuario_id INTEGER",
        "ALTER TABLE cnds ADD COLUMN inativado_em TEXT",
        "ALTER TABLE cnds ADD COLUMN motivo_inativacao TEXT",
        "ALTER TABLE cnds ADD COLUMN integrity_signature TEXT",
        "ALTER TABLE cnds ADD COLUMN versao_registro INTEGER NOT NULL DEFAULT 1",
    ]:
        _try_alter(main_conn, col_sql)


@_migration(5, "Adicionar inativado_em em usuarios")
def _m5(main_conn, _):
    _try_alter(main_conn,
        "ALTER TABLE usuarios ADD COLUMN inativado_em TEXT")


def _get_current_version(conn) -> int:
    try:
        row = conn.execute("SELECT MAX(version) FROM schema_version").fetchone()
        return row[0] if row and row[0] is not None else 0
    except Exception:
        return 0


def apply_migrations(main_conn, catalog_conn) -> list[int]:
    main_conn.execute("""
        CREATE TABLE IF NOT EXISTS schema_version (
            version     INTEGER NOT NULL,
            aplicado_em TEXT    NOT NULL,
            descricao   TEXT
        )
    """)
    current = _get_current_version(main_conn)
    applied = []
    for version, desc, fn in sorted(_MIGRATIONS, key=lambda x: x[0]):
        if version <= current:
            continue
        try:
            fn(main_conn, catalog_conn)
            main_conn.execute(
                "INSERT INTO schema_version (version, aplicado_em, descricao) VALUES (?, ?, ?)",
                (version, now_iso(), desc),
            )
            applied.append(version)
        except Exception as e:
            print(f"[MIGRATION WARNING] versão {version} '{desc}': {e}")
    return applied
