"""
CndRepository — V7.

Adicionados:
  - find_by_unique_key: verifica unicidade antes de insert
  - reactivate: reativa registro inativo
  - list_inactive: lista registros inativos para a aba de inativos
  - list_summary: agora inclui cnpj_informado na query
"""
from app.core.utils import now_iso


_SUMMARY_COLS = """
    id,
    empresa_grupo_informado,
    filial_informada,
    cnpj_informado,
    esfera,
    uf,
    local_informado,
    orgao_emissor_informado,
    status_cnd_informado,
    data_emissao,
    data_validade,
    CAST(julianday(date(data_validade)) - julianday(date('now','localtime')) AS INTEGER) AS dias_para_vencer,
    criticidade_informada,
    status_processo_informado,
    responsavel_informado,
    analista_filial_informado,
    comunicacao_resumo,
    caminho_pdf,
    registro_ativo,
    registro_status,
    inscricao_estadual,
    inscricao_municipal,
    numero_certidao,
    mapeamento,
    strftime('%Y', data_emissao)  AS ano_emissao,
    strftime('%Y-%m', data_emissao) AS mes_emissao,
    strftime('%Y', data_validade)   AS ano_validade,
    strftime('%Y-%m', data_validade) AS mes_validade
"""

_ORDER = """
    ORDER BY
        CASE WHEN data_validade IS NULL OR data_validade = '' THEN 1 ELSE 0 END,
        data_validade ASC
"""


class CndRepository:
    def __init__(self, dbm):
        self.dbm = dbm

    def list_summary(self) -> list[dict]:
        """Registros ATIVOS, ordenados por validade."""
        with self.dbm.session() as conn:
            cur = conn.execute(
                f"SELECT {_SUMMARY_COLS} FROM cnds WHERE registro_ativo = 1 {_ORDER}"
            )
            return [dict(row) for row in cur.fetchall()]

    def list_inactive(self) -> list[dict]:
        """Registros INATIVOS, para aba de inativos."""
        with self.dbm.session() as conn:
            cur = conn.execute(
                f"SELECT {_SUMMARY_COLS}, motivo_inativacao FROM cnds "
                f"WHERE registro_ativo = 0 {_ORDER}"
            )
            return [dict(row) for row in cur.fetchall()]

    def get_by_id(self, cnd_id: int) -> dict | None:
        with self.dbm.session() as conn:
            cur = conn.execute("SELECT * FROM cnds WHERE id = ?", (cnd_id,))
            row = cur.fetchone()
            return dict(row) if row else None

    def find_by_unique_key(
        self,
        empresa_grupo_informado: str,
        filial_informada: str,
        cnpj_numeros: str,
        esfera: str,
        uf: str,
        orgao_emissor_informado: str,
    ) -> int | None:
        """
        Retorna o id do registro com esta combinação única, independente
        de estar ativo ou inativo. None se não existir.
        """
        with self.dbm.session() as conn:
            cur = conn.execute(
                """
                SELECT id FROM cnds
                WHERE empresa_grupo_informado = ?
                  AND filial_informada        = ?
                  AND cnpj_numeros            = ?
                  AND esfera                  = ?
                  AND uf                      = ?
                  AND orgao_emissor_informado = ?
                LIMIT 1
                """,
                (empresa_grupo_informado, filial_informada, cnpj_numeros,
                 esfera, uf, orgao_emissor_informado),
            )
            row = cur.fetchone()
            return row[0] if row else None

    def insert(self, payload: dict) -> int:
        keys         = ", ".join(payload.keys())
        placeholders = ", ".join(["?"] * len(payload))
        with self.dbm.session() as conn:
            conn.execute(
                f"INSERT INTO cnds ({keys}) VALUES ({placeholders})",
                tuple(payload.values()),
            )
            return conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def update(self, cnd_id: int, payload: dict):
        assignments = ", ".join([f"{k} = ?" for k in payload.keys()])
        values = list(payload.values()) + [cnd_id]
        with self.dbm.session() as conn:
            conn.execute(
                f"UPDATE cnds SET {assignments} WHERE id = ?",
                tuple(values),
            )

    def inactivate(self, cnd_id: int, motivo: str, usuario_id: int, updated_at: str):
        with self.dbm.session() as conn:
            conn.execute(
                """
                UPDATE cnds
                SET registro_ativo            = 0,
                    registro_status           = 'Inativo',
                    motivo_inativacao         = ?,
                    atualizado_por_usuario_id = ?,
                    atualizado_em             = ?,
                    inativado_por_usuario_id  = ?,
                    inativado_em              = ?,
                    versao_registro           = COALESCE(versao_registro, 1) + 1
                WHERE id = ?
                """,
                (motivo, usuario_id, updated_at, usuario_id, updated_at, cnd_id),
            )

    def reactivate(self, cnd_id: int, usuario_id: int, updated_at: str):
        with self.dbm.session() as conn:
            conn.execute(
                """
                UPDATE cnds
                SET registro_ativo            = 1,
                    registro_status           = 'Ativo',
                    motivo_inativacao         = NULL,
                    atualizado_por_usuario_id = ?,
                    atualizado_em             = ?,
                    inativado_por_usuario_id  = NULL,
                    inativado_em              = NULL,
                    versao_registro           = COALESCE(versao_registro, 1) + 1
                WHERE id = ?
                """,
                (usuario_id, updated_at, cnd_id),
            )

    # ── Comunicação ──────────────────────────────────────────────────────

    def list_comunicacoes(self, cnd_id: int) -> list[str]:
        with self.dbm.session() as conn:
            cur = conn.execute(
                "SELECT filial_impactada_texto FROM cnd_comunicacoes "
                "WHERE cnd_id = ? AND ativo = 1 ORDER BY ordem_exibicao, id",
                (cnd_id,),
            )
            return [row[0] for row in cur.fetchall()]

    def set_comunicacoes(self, cnd_id: int, filiais: list[str], usuario_id: int):
        now = now_iso()
        with self.dbm.session() as conn:
            conn.execute(
                "UPDATE cnd_comunicacoes SET ativo = 0 WHERE cnd_id = ?", (cnd_id,)
            )
            seen = set()
            for idx, filial in enumerate(filiais):
                f = filial.strip()
                if not f or f in seen:
                    continue
                seen.add(f)
                try:
                    conn.execute(
                        "INSERT INTO cnd_comunicacoes "
                        "(cnd_id, filial_impactada_texto, ordem_exibicao, ativo, criado_por_usuario_id, criado_em) "
                        "VALUES (?, ?, ?, 1, ?, ?)",
                        (cnd_id, f, idx, usuario_id, now),
                    )
                except Exception:
                    # UNIQUE constraint — ignora silenciosamente duplicata
                    pass

    def update_comunicacao_resumo(self, cnd_id: int, resumo: str):
        with self.dbm.session() as conn:
            conn.execute(
                "UPDATE cnds SET comunicacao_resumo = ? WHERE id = ?",
                (resumo, cnd_id),
            )
