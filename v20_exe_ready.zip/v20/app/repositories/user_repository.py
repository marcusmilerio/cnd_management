from app.core.utils import now_iso


class UserRepository:
    def __init__(self, dbm):
        self.dbm = dbm

    def get_by_login(self, login: str) -> dict | None:
        with self.dbm.session() as conn:
            cur = conn.execute("SELECT * FROM usuarios WHERE login = ?", (login,))
            row = cur.fetchone()
            if not row: return None
            return dict(zip([d[0] for d in cur.description], row))

    def get_by_id(self, user_id: int) -> dict | None:
        with self.dbm.session() as conn:
            cur = conn.execute("SELECT * FROM usuarios WHERE id = ?", (user_id,))
            row = cur.fetchone()
            if not row: return None
            return dict(zip([d[0] for d in cur.description], row))

    def list_all(self) -> list[dict]:
        with self.dbm.session() as conn:
            cur = conn.execute(
                "SELECT id,uuid,nome_usuario,login,perfil,ativo,"
                "must_change_password,ultimo_login_em,criado_em "
                "FROM usuarios ORDER BY nome_usuario"
            )
            return [dict(row) for row in cur.fetchall()]

    def insert_user(self, uuid, nome_usuario, login, senha_hash, perfil, must_change_password=1) -> int:
        now = now_iso()
        with self.dbm.session() as conn:
            conn.execute(
                "INSERT INTO usuarios (uuid,nome_usuario,login,senha_hash,perfil,"
                "ativo,must_change_password,criado_em) VALUES (?,?,?,?,?,1,?,?)",
                (uuid, nome_usuario, login, senha_hash, perfil, must_change_password, now),
            )
            return conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def touch_login(self, user_id: int):
        with self.dbm.session() as conn:
            conn.execute("UPDATE usuarios SET ultimo_login_em=? WHERE id=?", (now_iso(), user_id))

    def update_password(self, user_id: int, senha_hash: str, must_change: int = 0):
        with self.dbm.session() as conn:
            conn.execute(
                "UPDATE usuarios SET senha_hash=?,must_change_password=?,atualizado_em=? WHERE id=?",
                (senha_hash, must_change, now_iso(), user_id),
            )

    def reactivate_user(self, user_id: int):
        now = now_iso()
        with self.dbm.session() as conn:
            conn.execute(
                "UPDATE usuarios SET ativo=1, inativado_em=NULL, atualizado_em=? WHERE id=?",
                (now, user_id),
            )

    def deactivate_user(self, user_id: int):
        now = now_iso()
        with self.dbm.session() as conn:
            conn.execute(
                "UPDATE usuarios SET ativo=0,inativado_em=?,atualizado_em=? WHERE id=?",
                (now, now, user_id),
            )
