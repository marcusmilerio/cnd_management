class AuditRepository:
    def __init__(self, dbm): self.dbm = dbm
    def insert_event(self, payload):
        keys = ", ".join(payload.keys())
        placeholders = ", ".join(["?"] * len(payload))
        with self.dbm.session() as conn:
            conn.execute(f"INSERT INTO audit_log ({keys}) VALUES ({placeholders})", tuple(payload.values()))
