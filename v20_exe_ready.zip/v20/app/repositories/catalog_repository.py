from app.core.normalizers import normalize_upper
from app.core.utils import now_iso


class CatalogRepository:
    TABLE_MAP = {
        "empresas_grupos":  ("nome",          "nome_normalizado"),
        "filiais":          ("codigo_filial",  "codigo_filial_normalizado"),
        "locais":           ("local",          "local_normalizado"),
        "orgaos_emissores": ("nome_orgao",     "nome_orgao_normalizado"),
        "criticidades":     ("valor",          "valor_normalizado"),
        "status_cnd":       ("valor",          "valor_normalizado"),
        "status_processo":  ("valor",          "valor_normalizado"),
        "responsaveis":     ("nome",           "nome_normalizado"),
        "analistas_filial": ("nome",           "nome_normalizado"),
    }

    def __init__(self, dbm):
        self.dbm = dbm

    def list_simple(self, table: str) -> list[dict]:
        col = self.TABLE_MAP[table][0]
        with self.dbm.session() as conn:
            cur = conn.execute(
                f"SELECT id, {col} FROM {table} WHERE ativo = 1 ORDER BY {col}"
            )
            return [{"id": r[0], "value": r[1]} for r in cur.fetchall()]

    def get_or_create_simple(self, table: str, value: str) -> int:
        col, norm_col = self.TABLE_MAP[table]
        nv = normalize_upper(value)

        with self.dbm.session() as conn:
            cur = conn.execute(
                f"SELECT id FROM {table} WHERE {norm_col} = ?", (nv,)
            )
            row = cur.fetchone()
            if row:
                return row[0]

        with self.dbm.session() as conn:
            conn.execute(
                f"INSERT OR IGNORE INTO {table} ({col}, {norm_col}, ativo, criado_em) "
                f"VALUES (?, ?, 1, ?)",
                (value.strip(), nv, now_iso()),
            )
            cur = conn.execute(
                f"SELECT id FROM {table} WHERE {norm_col} = ?", (nv,)
            )
            row = cur.fetchone()
            return row[0] if row else None
