from app.core.exceptions import AuthenticationError
from app.security.password_hasher import verify_password

class AuthManager:
    def __init__(self, user_repo) -> None:
        self.user_repo = user_repo

    def login(self, login: str, password: str) -> dict:
        user = self.user_repo.get_by_login(login)
        if not user or not user["ativo"]:
            raise AuthenticationError("Usuário inválido ou inativo.")
        if not verify_password(password, user["senha_hash"]):
            raise AuthenticationError("Senha inválida.")
        return user
