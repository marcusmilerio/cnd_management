import hashlib, hmac, json, os
from pathlib import Path
from app.core.exceptions import IntegrityError
from app.core.utils import now_iso

def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""): h.update(chunk)
    return h.hexdigest()

def make_hmac(payload, secret):
    return hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()

def build_manifest(main_db, catalog_db, user_id, user_login, app_version, secret):
    manifest = {"manifest_version":1,"app_versao":app_version,"gerado_em":now_iso(),"gerado_por_usuario_id":user_id,"gerado_por_login":user_login,"main_db":{"arquivo":main_db,"sha256":file_sha256(main_db),"tamanho_bytes":os.path.getsize(main_db)},"catalog_db":{"arquivo":catalog_db,"sha256":file_sha256(catalog_db),"tamanho_bytes":os.path.getsize(catalog_db)}}
    payload = json.dumps(manifest, ensure_ascii=False, sort_keys=True)
    manifest["manifest_hmac"] = make_hmac(payload, secret)
    return manifest

def save_manifest(path, manifest):
    Path(path).write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

def validate_manifest(path, main_db, catalog_db, secret):
    manifest = json.loads(Path(path).read_text(encoding="utf-8"))
    given = manifest.pop("manifest_hmac", "")
    payload = json.dumps(manifest, ensure_ascii=False, sort_keys=True)
    if not hmac.compare_digest(given, make_hmac(payload, secret)): raise IntegrityError("HMAC do manifesto inválido.")
    if manifest["main_db"]["sha256"] != file_sha256(main_db): raise IntegrityError("Hash do main.db divergente.")
    if manifest["catalog_db"]["sha256"] != file_sha256(catalog_db): raise IntegrityError("Hash do catalog.db divergente.")
    manifest["manifest_hmac"] = given
    return manifest
