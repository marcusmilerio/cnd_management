"""
Gerenciador de lock de uso exclusivo.

Fluxo:
  - acquire()       : cria app.lock; levanta LockInUseError se já existir lock válido
  - heartbeat()     : atualiza heartbeat_em no lock
  - release()       : remove app.lock (encerramento normal)
  - force_release() : remove app.lock mesmo que não seja nosso (para override de órfão)
  - is_stale(data)  : verifica se o heartbeat passou do timeout
  - _read()         : lê o lock atual (usado pelo LockWaitWindow)
"""
import json
from pathlib import Path
from datetime import datetime

from app.core.exceptions import LockInUseError
from app.core.utils import get_hostname, now_iso, new_uuid


class LockManager:
    def __init__(self, lock_file: str, stale_after_seconds: int = 90) -> None:
        self.lock_file = Path(lock_file)
        self.stale_after_seconds = stale_after_seconds
        self._session_data: dict | None = None

    def _read(self) -> dict | None:
        if not self.lock_file.exists():
            return None
        try:
            return json.loads(self.lock_file.read_text(encoding="utf-8"))
        except Exception:
            return None

    def is_stale(self, data: dict | None) -> bool:
        if not data or "heartbeat_em" not in data:
            return True
        try:
            hb = datetime.fromisoformat(data["heartbeat_em"])
            return (datetime.now() - hb).total_seconds() > self.stale_after_seconds
        except Exception:
            return True

    def acquire(self, usuario_id=None, usuario_login="", usuario_nome="") -> dict:
        current = self._read()
        if current and not self.is_stale(current):
            raise LockInUseError("Aplicação em uso por outro usuário.", current)

        data = {
            "lock_version":  1,
            "sessao_id":     new_uuid(),
            "usuario_id":    usuario_id,
            "usuario_login": usuario_login,
            "usuario_nome":  usuario_nome,
            "maquina_nome":  get_hostname(),
            "aberto_em":     now_iso(),
            "heartbeat_em":  now_iso(),
        }
        self.lock_file.parent.mkdir(parents=True, exist_ok=True)
        self.lock_file.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        self._session_data = data
        return data

    def heartbeat(self) -> None:
        data = self._read()
        if not data:
            return
        data["heartbeat_em"] = now_iso()
        self.lock_file.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def release(self) -> None:
        if self.lock_file.exists():
            self.lock_file.unlink()
        self._session_data = None

    def force_release(self) -> None:
        """Remove o lock independentemente de quem o criou (usado no override de órfão)."""
        if self.lock_file.exists():
            self.lock_file.unlink()
