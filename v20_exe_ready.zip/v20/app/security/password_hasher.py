from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError, InvalidHashError

_hasher = PasswordHasher()


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    """
    Verifica a senha contra o hash armazenado.
    Retorna False para qualquer falha — incluindo hash malformado/corrompido,
    que gera VerificationError ou InvalidHashError em vez de VerifyMismatchError.
    """
    try:
        return _hasher.verify(hashed, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False
    except Exception:
        # Qualquer outro erro (ex: hash de formato desconhecido) → negar acesso
        return False
