"""
DateField — V18.

Exibe a data selecionada em campo somente leitura.
Botão "📅 Selecionar" abre DatePickerWindow (calendário visual).
Botão "✕" limpa o campo.

Interface pública: get(), get_iso(), set(), delete(), insert().
"""
from datetime import date, datetime
import customtkinter as ctk


# ══════════════════════════════════════════════════════════════════════════════
#  Janela de calendário
# ══════════════════════════════════════════════════════════════════════════════

class DatePickerWindow(ctk.CTkToplevel):
    """Calendário mensal clicável. Chama on_select(date) ao confirmar."""

    DAYS   = ["Seg","Ter","Qua","Qui","Sex","Sáb","Dom"]
    MONTHS = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho",
              "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"]

    def __init__(self, master, initial: date | None, on_select):
        super().__init__(master)
        self.on_select   = on_select
        self._selected   = initial or date.today()
        self._view_year  = self._selected.year
        self._view_month = self._selected.month

        self.title("Selecionar Data")
        self.resizable(False, False)
        self.grab_set()
        self._build()
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = self.winfo_width(), self.winfo_height()
        self.geometry(f"+{(sw-w)//2}+{(sh-h)//2}")

    def _build(self):
        # ── Cabeçalho: mês/ano + navegação ───────────────────────────
        hdr = ctk.CTkFrame(self, fg_color="transparent")
        hdr.pack(fill="x", padx=10, pady=(10,4))

        ctk.CTkButton(hdr, text="◀", width=32, command=self._prev_month).pack(side="left")
        self._hdr_lbl = ctk.CTkLabel(hdr, text="", font=ctk.CTkFont(size=13, weight="bold"), width=180)
        self._hdr_lbl.pack(side="left", expand=True)
        ctk.CTkButton(hdr, text="▶", width=32, command=self._next_month).pack(side="right")

        # ── Grade de dias ─────────────────────────────────────────────
        self._grid_frame = ctk.CTkFrame(self, fg_color="transparent")
        self._grid_frame.pack(padx=10, pady=(0,6))

        # Cabeçalho dos dias da semana
        for ci, d in enumerate(self.DAYS):
            ctk.CTkLabel(self._grid_frame, text=d, width=38,
                         font=ctk.CTkFont(size=10),
                         text_color="gray").grid(row=0, column=ci, padx=1, pady=(0,2))

        self._day_btns: list[ctk.CTkButton] = []
        for i in range(42):
            r, c = divmod(i, 7)
            btn = ctk.CTkButton(self._grid_frame, text="", width=38, height=32,
                                fg_color="transparent", hover_color="gray30",
                                command=lambda idx=i: self._on_day(idx))
            btn.grid(row=r+1, column=c, padx=1, pady=1)
            self._day_btns.append(btn)

        # ── Rodapé ────────────────────────────────────────────────────
        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=10, pady=(0,10))
        ctk.CTkButton(foot, text="Hoje", width=80,
                      command=self._go_today).pack(side="left")
        ctk.CTkButton(foot, text="Cancelar", width=80,
                      fg_color="gray30",
                      command=self.destroy).pack(side="right")

        self._render()

    def _render(self):
        import calendar
        self._hdr_lbl.configure(
            text=f"{self.MONTHS[self._view_month-1]}  {self._view_year}")

        # Primeiro dia da semana (0=segunda) e total de dias
        first_wd, n_days = calendar.monthrange(self._view_year, self._view_month)
        # first_wd: 0=segunda, 6=domingo → nossa grade começa na segunda

        today = date.today()
        for i, btn in enumerate(self._day_btns):
            day_num = i - first_wd + 1
            if 1 <= day_num <= n_days:
                d = date(self._view_year, self._view_month, day_num)
                btn.configure(text=str(day_num), state="normal")
                # Realces
                if d == self._selected:
                    btn.configure(fg_color="#1f538d", hover_color="#1a4a7a",
                                  text_color="white")
                elif d == today:
                    btn.configure(fg_color="gray25", hover_color="gray30",
                                  text_color=("gray10","gray90"))
                else:
                    btn.configure(fg_color="transparent", hover_color="gray30",
                                  text_color=("gray10","gray90"))
            else:
                btn.configure(text="", state="disabled",
                              fg_color="transparent")

    def _on_day(self, idx):
        import calendar
        first_wd, n_days = calendar.monthrange(self._view_year, self._view_month)
        day_num = idx - first_wd + 1
        if 1 <= day_num <= n_days:
            self._selected = date(self._view_year, self._view_month, day_num)
            self.on_select(self._selected)
            self.destroy()

    def _prev_month(self):
        if self._view_month == 1:
            self._view_month = 12; self._view_year -= 1
        else:
            self._view_month -= 1
        self._render()

    def _next_month(self):
        if self._view_month == 12:
            self._view_month = 1; self._view_year += 1
        else:
            self._view_month += 1
        self._render()

    def _go_today(self):
        today = date.today()
        self._view_year  = today.year
        self._view_month = today.month
        self._selected   = today
        self._render()


# ══════════════════════════════════════════════════════════════════════════════
#  DateField
# ══════════════════════════════════════════════════════════════════════════════

class DateField(ctk.CTkFrame):
    """
    Campo de data com calendário visual.
    Exibe a data em label somente leitura.
    Botão 📅 abre o calendário. Botão ✕ limpa.
    """

    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.grid_columnconfigure(0, weight=1)

        self._value: date | None = None

        # Linha 0: label de exibição + botões
        row0 = ctk.CTkFrame(self, fg_color="transparent")
        row0.grid(row=0, column=0, sticky="ew")
        row0.grid_columnconfigure(0, weight=1)

        self._display = ctk.CTkEntry(row0, state="disabled", width=120,
                                      placeholder_text="dd/mm/aaaa")
        self._display.grid(row=0, column=0, sticky="ew", padx=(0,4))

        self._btn_pick = ctk.CTkButton(
            row0, text="📅", width=36, height=28,
            command=self._open_picker)
        self._btn_pick.grid(row=0, column=1, padx=(0,2))

        self._btn_clear = ctk.CTkButton(
            row0, text="✕", width=28, height=28,
            fg_color="gray30", hover_color="gray20",
            command=self.delete)
        self._btn_clear.grid(row=0, column=2)

    def _open_picker(self):
        DatePickerWindow(self, initial=self._value, on_select=self._on_picked)

    def _on_picked(self, d: date):
        self._value = d
        self._refresh_display()

    def _refresh_display(self):
        self._display.configure(state="normal")
        self._display.delete(0, "end")
        if self._value:
            self._display.insert(0, self._value.strftime("%d/%m/%Y"))
        self._display.configure(state="disabled")

    def disable(self):
        """Desabilita o campo (readonly externo)."""
        self._btn_pick.configure(state="disabled")
        self._btn_clear.configure(state="disabled")

    def enable(self):
        """Reabilita o campo."""
        self._btn_pick.configure(state="normal")
        self._btn_clear.configure(state="normal")

    # ── Interface pública ──────────────────────────────────────────────

    def get(self) -> str:
        """Retorna dd/mm/aaaa ou string vazia."""
        return self._value.strftime("%d/%m/%Y") if self._value else ""

    def get_iso(self) -> str:
        """Retorna AAAA-MM-DD ou string vazia."""
        return self._value.isoformat() if self._value else ""

    def set(self, value: str):
        """Aceita ISO (AAAA-MM-DD), BR (dd/mm/aaaa) ou vazio."""
        value = (value or "").strip()
        if not value:
            self._value = None
            self._refresh_display()
            return
        for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
            try:
                self._value = datetime.strptime(value, fmt).date()
                self._refresh_display()
                return
            except ValueError:
                continue
        # Valor inválido: ignora
        self._value = None
        self._refresh_display()

    def delete(self, *_):
        self._value = None
        self._refresh_display()

    def insert(self, _idx, value: str):
        self.set(value)
