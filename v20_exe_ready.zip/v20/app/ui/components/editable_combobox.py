import customtkinter as ctk
class EditableComboBox(ctk.CTkComboBox):
    def __init__(self, master, values=None, **kwargs):
        super().__init__(master, values=values or [], **kwargs)
        self.set("")
