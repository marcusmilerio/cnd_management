"""
FilePickerField — V18.

Expõe btn_selecionar e btn_abrir para controle externo (habilitar/desabilitar por perfil).
"""
import os
from pathlib import Path
import customtkinter as ctk
from tkinter import filedialog, messagebox


class FilePickerField(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)

        self.var = ctk.StringVar()

        self.entry = ctk.CTkEntry(self, textvariable=self.var)
        self.entry.pack(side="left", fill="x", expand=True, padx=(0, 6))

        self.btn_selecionar = ctk.CTkButton(
            self, text="Selecionar", command=self.pick_file, width=100)
        self.btn_selecionar.pack(side="left", padx=2)

        self.btn_abrir = ctk.CTkButton(
            self, text="Abrir", command=self.open_file, width=80)
        self.btn_abrir.pack(side="left")

    def pick_file(self):
        name = filedialog.askopenfilename(
            filetypes=[("PDF", "*.pdf"), ("Todos", "*.*")])
        if name:
            self.var.set(str(Path(name)))

    def open_file(self):
        path = self.var.get().strip()
        if not path:
            messagebox.showwarning("PDF", "Nenhum arquivo selecionado.")
            return
        if not os.path.exists(path):
            messagebox.showwarning("Arquivo não encontrado",
                f"O arquivo abaixo não foi encontrado no disco:\n\n{path}\n\n"
                "O caminho pode estar desatualizado ou o arquivo foi movido/excluído.")
            return
        try:
            os.startfile(path)
        except Exception as e:
            messagebox.showerror("Erro ao abrir PDF", str(e))

    def get(self) -> str:
        return self.var.get().strip()
