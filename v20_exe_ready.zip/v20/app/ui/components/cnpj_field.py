"""
Campo de CNPJ com máscara automática.
_error_label só ocupa espaço quando há erro (grid_remove quando vazio).
"""
import re
import customtkinter as ctk


def _format_cnpj(digits: str) -> str:
    d = digits[:14]
    if len(d) <= 2:  return d
    if len(d) <= 5:  return f"{d[:2]}.{d[2:]}"
    if len(d) <= 8:  return f"{d[:2]}.{d[2:5]}.{d[5:]}"
    if len(d) <= 12: return f"{d[:2]}.{d[2:5]}.{d[5:8]}/{d[8:]}"
    return f"{d[:2]}.{d[2:5]}.{d[5:8]}/{d[8:12]}-{d[12:14]}"


def _validate_cnpj_digits(digits: str) -> bool:
    if len(digits) != 14 or len(set(digits)) == 1:
        return False
    def calc(d, weights):
        s = sum(int(d[i]) * weights[i] for i in range(len(weights)))
        r = s % 11
        return 0 if r < 2 else 11 - r
    w1 = [5,4,3,2,9,8,7,6,5,4,3,2]
    w2 = [6,5,4,3,2,9,8,7,6,5,4,3,2]
    return (calc(digits, w1) == int(digits[12]) and
            calc(digits, w2) == int(digits[13]))


class CnpjField(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.grid_columnconfigure(0, weight=1)

        self._var   = ctk.StringVar()
        self._entry = ctk.CTkEntry(self, textvariable=self._var,
                                    placeholder_text="00.000.000/0000-00")
        self._entry.grid(row=0, column=0, sticky="ew")

        # _error_label começa fora do grid — só aparece quando há erro
        self._error_label = ctk.CTkLabel(
            self, text="", text_color="red",
            font=ctk.CTkFont(size=10), anchor="w")

        vcmd = (self.register(self._on_validate), "%P")
        self._entry.configure(validate="key", validatecommand=vcmd)
        self._entry.bind("<FocusOut>",   self._on_focus_out)
        self._entry.bind("<KeyRelease>", self._on_key)

    def _only_digits(self, v: str) -> str:
        return re.sub(r"\D", "", v)

    def _on_validate(self, proposed: str) -> bool:
        if not proposed: return True
        return len(self._only_digits(proposed)) <= 14

    def _on_key(self, _=None):
        raw    = self._var.get()
        digits = self._only_digits(raw)
        fmt    = _format_cnpj(digits)
        if fmt != raw:
            self._var.set(fmt)
            try: self._entry.icursor("end")
            except: pass
        self._clear_error()

    def _on_focus_out(self, _=None):
        digits = self._only_digits(self._var.get())
        if not digits:
            self._clear_error(); return
        if len(digits) != 14:
            self._show_error("CNPJ deve ter 14 dígitos"); return
        if not _validate_cnpj_digits(digits):
            self._show_error("CNPJ inválido (dígito verificador)")
        else:
            self._clear_error()
        self._var.set(_format_cnpj(digits))

    def _show_error(self, msg: str):
        self._error_label.configure(text=msg)
        self._error_label.grid(row=1, column=0, sticky="w")

    def _clear_error(self):
        self._error_label.configure(text="")
        self._error_label.grid_remove()

    # ── Interface pública ──────────────────────────────────────────────
    def get(self) -> str:       return self._var.get().strip()
    def get_digits(self) -> str: return self._only_digits(self._var.get())

    def set(self, value: str):
        digits = self._only_digits(str(value or ""))
        self._var.set(_format_cnpj(digits) if digits else "")
        self._clear_error()

    def delete(self, *_):
        self._var.set("")
        self._clear_error()

    def insert(self, _idx, value: str):
        self.set(value)
