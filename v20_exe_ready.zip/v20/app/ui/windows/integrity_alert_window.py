"""
Janela de alerta de integridade — V2.

Melhorias vs V1:
  - Distingue claramente os 3 cenários (primeira execução / banco substituído / possível fraude)
  - Botões com rótulos contextuais e descritivos
  - Admin pode aprovar com dois motivos distintos:
      "backup"   → restauração de backup legítima
      "other"    → outra razão (banco de teste, migração, etc.)
  - Ao aprovar, manifesto é regenerado e o alerta NÃO volta na próxima abertura

Atributos após fechar:
  action: "accept"  — admin aprovou, manifesto será regenerado
          "cancel"  — encerrar aplicação
"""
import customtkinter as ctk
from tkinter import messagebox
from datetime import datetime


class IntegrityAlertWindow(ctk.CTkToplevel):

    def __init__(self, master, motivo: str, detalhe: str,
                 is_admin: bool, manifest_info: dict | None = None):
        super().__init__(master)

        self.action = "cancel"
        self.approve_reason = ""
        self._is_admin = is_admin
        self._manifest_info = manifest_info or {}

        self.title("CND Manager — Verificação de Integridade")
        self.geometry("560x520")
        self.resizable(False, True)
        self.grab_set()

        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"560x520+{(sw-560)//2}+{(sh-520)//2}")

        self._build_ui(motivo, detalhe)

    def _build_ui(self, motivo: str, detalhe: str):
        # Cabeçalho
        hdr = ctk.CTkFrame(self, fg_color="#7a1a1a", corner_radius=0)
        hdr.pack(fill="x")
        ctk.CTkLabel(
            hdr,
            text="⚠  DIVERGÊNCIA DE INTEGRIDADE DETECTADA",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color="white",
        ).pack(pady=10)

        # Explicação do que aconteceu
        scroll = ctk.CTkScrollableFrame(self, height=300)
        scroll.pack(fill="both", expand=True, padx=16, pady=(12, 4))

        ctk.CTkLabel(
            scroll,
            text="O que foi detectado:",
            font=ctk.CTkFont(size=12, weight="bold"),
            anchor="w",
        ).pack(fill="x", pady=(0, 4))

        ctk.CTkLabel(
            scroll,
            text=motivo,
            font=ctk.CTkFont(size=11),
            wraplength=500,
            justify="left",
            anchor="w",
        ).pack(fill="x", pady=(0, 10))

        # Informações do manifesto anterior (quando disponível)
        if self._manifest_info:
            info_frame = ctk.CTkFrame(scroll, fg_color=("gray90","gray20"), corner_radius=6)
            info_frame.pack(fill="x", pady=(0, 10))
            ctk.CTkLabel(
                info_frame,
                text="Último manifesto registrado:",
                font=ctk.CTkFont(size=10, weight="bold"),
                anchor="w",
            ).pack(anchor="w", padx=8, pady=(6, 2))
            for linha in self._format_manifest_info():
                ctk.CTkLabel(
                    info_frame,
                    text=linha,
                    font=ctk.CTkFont(size=10, family="Courier New"),
                    anchor="w",
                    justify="left",
                ).pack(anchor="w", padx=8)
            ctk.CTkLabel(info_frame, text="").pack(pady=2)

        # Detalhe técnico dos hashes
        if detalhe:
            ctk.CTkLabel(
                scroll,
                text="Detalhe técnico:",
                font=ctk.CTkFont(size=12, weight="bold"),
                anchor="w",
            ).pack(fill="x", pady=(0, 4))
            detail_box = ctk.CTkTextbox(
                scroll, height=90,
                font=ctk.CTkFont(size=10, family="Courier New"),
            )
            detail_box.pack(fill="x", pady=(0, 10))
            detail_box.insert("1.0", detalhe)
            detail_box.configure(state="disabled")

        # O que pode ter causado isso
        ctk.CTkLabel(
            scroll,
            text="Causas possíveis:",
            font=ctk.CTkFont(size=12, weight="bold"),
            anchor="w",
        ).pack(fill="x", pady=(0, 4))
        causas = (
            "• Restauração de backup  (legítimo — use o botão abaixo)\n"
            "• Substituição de banco por banco de teste  (legítimo)\n"
            "• Migração ou atualização dos arquivos  (legítimo)\n"
            "• Alteração direta dos arquivos sem passar pela aplicação  (suspeito)\n"
            "• Corrupção ou substituição não autorizada  (suspeito)"
        )
        ctk.CTkLabel(
            scroll,
            text=causas,
            font=ctk.CTkFont(size=11),
            justify="left",
            anchor="w",
            wraplength=500,
        ).pack(fill="x", pady=(0, 8))

        # Ação para não-admin
        if not self._is_admin:
            ctk.CTkLabel(
                scroll,
                text="⛔  Seu perfil não permite aprovar divergências.\n"
                     "Contate o administrador do sistema.",
                font=ctk.CTkFont(size=11),
                text_color=("#aa0000", "#ff8888"),
                justify="left",
                anchor="w",
            ).pack(fill="x", pady=(4, 0))

        # Botões de ação
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=16, pady=(4, 14))

        if self._is_admin:
            # Botão principal: reconhecer como legítimo e regenerar manifesto
            ctk.CTkButton(
                btn_frame,
                text="✔  Reconhecer e continuar",
                width=210,
                fg_color="#1a5e1a",
                hover_color="#144e14",
                command=self._accept,
            ).pack(side="left", padx=(0, 8))

            ctk.CTkLabel(
                btn_frame,
                text="Atualiza o manifesto com\nos arquivos atuais em disco",
                font=ctk.CTkFont(size=9),
                text_color="gray",
                justify="left",
            ).pack(side="left", padx=(0, 20))

        ctk.CTkButton(
            btn_frame,
            text="Encerrar",
            width=100,
            fg_color="transparent",
            border_width=1,
            command=self._cancel,
        ).pack(side="right")

    def _format_manifest_info(self) -> list[str]:
        m = self._manifest_info
        lines = []
        gerado_em = m.get("gerado_em", "?")
        try:
            gerado_em = datetime.fromisoformat(gerado_em).strftime("%d/%m/%Y %H:%M:%S")
        except Exception:
            pass
        lines.append(f"  Gerado em  : {gerado_em}")
        lines.append(f"  Gerado por : {m.get('gerado_por_login', '?')}")
        lines.append(f"  Versão app : {m.get('app_versao', '?')}")
        h_main = (m.get("main_db") or {}).get("sha256", "?")
        h_cat  = (m.get("catalog_db") or {}).get("sha256", "?")
        lines.append(f"  Hash main  : {h_main[:32]}…")
        lines.append(f"  Hash cat.  : {h_cat[:32]}…")
        return lines

    def _accept(self):
        self.action = "accept"
        self.approve_reason = "admin_reconheceu"
        self.grab_release()
        self.destroy()

    def _cancel(self):
        self.action = "cancel"
        self.grab_release()
        self.destroy()
