"""
MainWindow — V10.

- DASHBOARD como primeira aba
- Abas com padding e estilo melhorado
- Exportar: apenas registros da subaba ativa (esfera+grupo), respeitando filtros
- Filtro Status CND: correspondência exata (==) não parcial
- Filtro de vencimento renomeado para "Vencimento"
- Comboboxes de filtro: placeholder visível, largura +30%
- "Reativar Selecionada" → "Reativar Registro"  
- open_edit passa is_inactive para CndFormWindow
"""
import customtkinter as ctk
from tkinter import ttk, messagebox, filedialog, font as tkfont
from datetime import datetime

from app.core.normalizers import strip_accents
from app.ui.windows.cnd_form_window import CndFormWindow
from app.ui.windows.dashboard_frame import DashboardFrame

_ESFERAS = ("Federal", "Estadual", "Municipal")
_GRUPOS  = ("Bayer S.A.", "D&PL", "Monsanto")

_COLUMNS = (
    ("empresa","Empresa",130,"w"),("filial","Filial",80,"center"),
    ("cnpj","CNPJ",130,"center"),
    ("ie","Insc. Est.",110,"center"),("im","Insc. Mun.",110,"center"),
    ("uf","UF",40,"center"),
    ("orgao","Órgão",140,"w"),("status","Status CND",140,"w"),
    ("emissao","Emissão",86,"center"),("validade","Validade",86,"center"),
    ("dias","Dias",48,"center"),("crit","Criticidade",84,"center"),
    ("pdf","PDF",28,"center"),("comm","Comunicação",160,"w"),
)
_COLS_INAT = (
    ("empresa","Empresa",130,"w"),("filial","Filial",80,"center"),
    ("cnpj","CNPJ",130,"center"),("uf","UF",40,"center"),
    ("orgao","Órgão",140,"w"),("status","Status CND",140,"w"),
    ("validade","Validade",86,"center"),("motivo","Motivo",200,"w"),
)
_VENC = ("Vencidas","≤ 15 dias","≤ 30 dias","OK (> 30)")

_C_NORMAL   = "#1f538d"
_C_ADMIN    = "#1a3a6a"
_C_NEUTRAL  = "#3a3a3a"
_C_EXPORT   = "#1a5a2a"
_C_DISABLED = "#444444"
_C_DIS_TXT  = "#777777"


def _btn(parent, text, cmd, enabled=True, color=None, pady=3):
    c  = color if (enabled and color) else (_C_NORMAL if enabled else _C_DISABLED)
    tc = None if enabled else _C_DIS_TXT
    kw = dict(text=text, width=162, command=(cmd if enabled else lambda: None),
               fg_color=c, hover_color=(c if not enabled else None))
    if tc: kw["text_color"] = tc
    if not enabled: kw["state"] = "disabled"
    b = ctk.CTkButton(parent, **kw)
    b.pack(fill="x", padx=6, pady=pady)
    return b


class MainWindow(ctk.CTkFrame):

    def __init__(self, root, settings, user, session,
                 cnd_service, catalog_service, lock_manager,
                 user_service=None, backup_service=None,
                 main_db_path=None, catalog_db_path=None,
                 integrity_path=None, hmac_secret=None):
        super().__init__(root)
        self.root=root; self.settings=settings; self.user=user; self.session=session
        self.cnd_service=cnd_service; self.catalog_service=catalog_service
        self.lock_manager=lock_manager; self.user_service=user_service
        self.backup_service=backup_service; self.main_db_path=main_db_path
        self.catalog_db_path=catalog_db_path; self.integrity_path=integrity_path
        self.hmac_secret=hmac_secret

        self._all_rows: list[dict] = []
        self._inactive_rows: list[dict] = []
        self._filtered_rows: list[dict] = []
        self._sort_state: dict = {}

        p = (user.get("perfil") or "").upper()
        self._is_admin    = p == "ADMIN"
        self._is_consulta = p == "CONSULTA"
        self._is_editor   = p.startswith("EDITOR_")

        self._apply_tab_style()
        self._build_ui()
        self.refresh_grid()
        self._heartbeat()

    # ── Estilo abas ────────────────────────────────────────────────────

    def _apply_tab_style(self):
        """
        Usa o tema nativo do SO — sem forçar clam nem cores customizadas.
        Isso dá a aparência padrão do Windows (igual Propriedades de Internet).
        Apenas ajustamos padding e fonte para dar espaço adequado ao texto.
        """
        s = ttk.Style()
        # Não trocar o tema — deixar o nativo do SO (Vista/Win10/Win11 style)
        # Abas principais: padding generoso + fonte bold
        s.configure("CND.TNotebook",     tabposition="nw")
        s.configure("CND.TNotebook.Tab", padding=[16, 6],
                    font=("Segoe UI", 10, "bold"))
        # Subabas: mais compactas
        s.configure("CNDSub.TNotebook",     tabposition="nw")
        s.configure("CNDSub.TNotebook.Tab", padding=[12, 5],
                    font=("Segoe UI", 9))

    # ── UI ─────────────────────────────────────────────────────────────

    def _build_ui(self):
        top = ctk.CTkFrame(self, corner_radius=0)
        top.pack(fill="x")
        ctk.CTkLabel(top, text=self.settings["app_name"],
                     font=ctk.CTkFont(size=15, weight="bold")).pack(side="left", padx=14, pady=8)
        self._int_lbl = ctk.CTkLabel(top, text="✔ Integridade OK",
                                      font=ctk.CTkFont(size=11), text_color="green")
        self._int_lbl.pack(side="left", padx=10)
        ctk.CTkLabel(top, text=f"{self.user['nome_usuario']}  |  {self.user['perfil']}",
                     font=ctk.CTkFont(size=11), text_color="gray").pack(side="right", padx=14, pady=8)

        # Filtros
        fb = ctk.CTkFrame(self, fg_color="transparent")
        fb.pack(fill="x", padx=10, pady=(6,0))
        ctk.CTkLabel(fb, text="Filtros:", width=48).pack(side="left")

        # Largura +30% e placeholder sempre visível via set()
        def _fcb(placeholder, width):
            v = ctk.StringVar()
            cb = ctk.CTkComboBox(fb, variable=v, values=[placeholder], width=int(width*1.3),
                                  command=lambda _: self._filter(),
                                  text_color="gray")
            cb.set(placeholder)
            cb._placeholder = placeholder
            cb._var = v
            cb.pack(side="left", padx=3)
            cb.bind("<Return>", lambda _: self._filter())
            # FocusIn: limpa placeholder, texto normal
            cb.bind("<FocusIn>",  lambda e, c=cb: self._on_cb_focusin(c))
            # FocusOut: restaura placeholder se vazio
            cb.bind("<FocusOut>", lambda e, c=cb: self._on_cb_focusout(c))
            return cb

        self._fe  = _fcb("Empresa",   120)
        self._ff  = _fcb("Filial",     90)
        self._fc  = _fcb("CNPJ",      110)
        self._fu  = _fcb("UF",         50)
        self._fs  = _fcb("Status",    140)

        # Vencimento como combobox fixo — esmaecido igual aos outros
        self._fv_var = ctk.StringVar(value="Vencimento")
        self._fv = ctk.CTkComboBox(fb, variable=self._fv_var,
                                    values=["Vencimento"] + list(_VENC),
                                    width=130, command=lambda _: self._filter(),
                                    text_color="gray")
        self._fv.set("Vencimento")
        self._fv.pack(side="left", padx=3)
        self._fv.bind("<FocusIn>",  lambda e: self._on_fv_focusin())
        self._fv.bind("<FocusOut>", lambda e: self._on_fv_focusout())

        # Texto livre: CTkEntry simples, +50% de largura
        self._ft = ctk.CTkEntry(fb, placeholder_text="Texto livre…", width=195)
        self._ft.pack(side="left", padx=3)
        self._ft.bind("<Return>", lambda _: self._filter())

        # Comunicação — busca parcial na lista de filiais impactadas
        self._fcomm = ctk.CTkEntry(fb, placeholder_text="Comunicação…", width=150)
        self._fcomm.pack(side="left", padx=3)
        self._fcomm.bind("<Return>", lambda _: self._filter())

        ctk.CTkButton(fb, text="Filtrar", width=64, command=self._filter,
                      fg_color=_C_NORMAL).pack(side="left", padx=3)
        ctk.CTkButton(fb, text="Limpar", width=60, command=self._clear,
                      fg_color=_C_NEUTRAL).pack(side="left", padx=2)

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=10, pady=8)

        left = ctk.CTkFrame(body, width=176)
        left.pack(side="left", fill="y", padx=(0,8))
        left.pack_propagate(False)
        self._sidebar(left)

        center = ctk.CTkFrame(body)
        center.pack(side="left", fill="both", expand=True)
        self._nb = ttk.Notebook(center, style="CND.TNotebook")
        self._nb.pack(fill="both", expand=True)
        self._nb_sub: dict[str, ttk.Notebook] = {}
        self._trees:  dict[str, ttk.Treeview] = {}

        # DASHBOARD primeiro
        df = ttk.Frame(self._nb)
        self._nb.add(df, text="  DASHBOARD  ")
        self._dash = DashboardFrame(df)
        self._dash.pack(fill="both", expand=True)

        # Esferas
        for esf in _ESFERAS:
            ef = ttk.Frame(self._nb); self._nb.add(ef, text=f"  {esf}  ")
            ns = ttk.Notebook(ef, style="CNDSub.TNotebook"); ns.pack(fill="both", expand=True)
            self._nb_sub[esf] = ns
            for grp in _GRUPOS:
                gf = ttk.Frame(ns); ns.add(gf, text=f"  {grp}  ")
                self._trees[f"{esf}|{grp}"] = self._make_tree(gf)
            tf = ttk.Frame(ns); ns.add(tf, text="  Todas  ")
            self._trees[f"{esf}|Todas"] = self._make_tree(tf)

        inf = ttk.Frame(self._nb); self._nb.add(inf, text="  Inativos  ")
        self._tree_inat = self._make_tree_inat(inf)

        # Índices das abas (DASHBOARD=0, Federal=1, Estadual=2, Municipal=3, Inativos=4)
        self._DASH_IDX  = 0
        self._ESF_START = 1   # índice da primeira esfera
        self._INAT_IDX  = 1 + len(_ESFERAS)  # = 4

        self._sv = ctk.StringVar(value="")
        ctk.CTkLabel(self, textvariable=self._sv, anchor="w",
                     font=ctk.CTkFont(size=11)).pack(fill="x", padx=12, pady=(0,6))

    def _on_fv_focusin(self):
        try: self._fv.configure(text_color=("gray10","gray90"))
        except: pass

    def _on_fv_focusout(self):
        if self._fv_var.get() == "Vencimento":
            try: self._fv.configure(text_color="gray")
            except: pass

    def _on_cb_focusin(self, cb):
        """Ao receber foco: limpa placeholder e muda cor do texto para normal."""
        if cb.get().strip() == cb._placeholder:
            cb.set("")
        try:
            cb.configure(text_color=("gray10","gray90"))
        except Exception:
            pass

    def _on_cb_focusout(self, cb):
        """Ao perder foco sem valor: restaura placeholder esmaecido."""
        if not cb.get().strip():
            cb.set(cb._placeholder)
            try:
                cb.configure(text_color="gray")
            except Exception:
                pass

    def _sidebar(self, p):
        # Todos os botões sempre visíveis.
        # Ativação por perfil:
        #   Admin       → todos
        #   Editor      → Adicionar CND, Abrir Seleção, Exportar Excel
        #   Visualizador→ Abrir Seleção, Exportar Excel
        a = self._is_admin
        e = self._is_editor   # qualquer editor (federal/estadual/municipal)
        c = self._is_consulta

        ctk.CTkLabel(p, text="── CNDs ──", font=ctk.CTkFont(size=10),
                     text_color="gray").pack(pady=(8,2))
        _btn(p, "Adicionar CND",    self.add_cnd,     enabled=(a or e))
        _btn(p, "Abrir Seleção",    self.open_edit,   enabled=True)

        ctk.CTkLabel(p, text="── Dados ──", font=ctk.CTkFont(size=10),
                     text_color="gray").pack(pady=(6,2))
        _btn(p, "Exportar Excel",   self.export_excel,   enabled=True,  color=_C_EXPORT)
        _btn(p, "Backup",           self.backup_now,     enabled=a,     color=_C_NEUTRAL)
        _btn(p, "Restaurar Backup", self.restore_backup, enabled=a,     color=_C_ADMIN)

        ctk.CTkLabel(p, text="── Admin ──", font=ctk.CTkFont(size=10),
                     text_color="gray").pack(pady=(6,2))
        _btn(p, "Gestão de Usuários",  self.manage_users,     enabled=a, color=_C_ADMIN)
        _btn(p, "Exportar Auditoria",  self.export_auditoria, enabled=a, color=_C_ADMIN)

    # ── Treeviews ──────────────────────────────────────────────────────

    def _make_tree(self, parent):
        fr = ttk.Frame(parent); fr.pack(fill="both", expand=True)
        cols = tuple(c[0] for c in _COLUMNS)
        t = ttk.Treeview(fr, columns=cols, show="headings", height=20)
        for cid, hd, w, a in _COLUMNS:
            t.heading(cid, text=hd, command=lambda c=cid, tt=t: self._sort(tt,c))
            t.column(cid, width=w, anchor=a, minwidth=40, stretch=False)
        v = ttk.Scrollbar(fr, orient="vertical",   command=t.yview)
        h = ttk.Scrollbar(fr, orient="horizontal", command=t.xview)
        t.configure(yscrollcommand=v.set, xscrollcommand=h.set)
        v.pack(side="right", fill="y"); h.pack(side="bottom", fill="x")
        t.pack(fill="both", expand=True)
        t.tag_configure("vencida",   background="#cc0000", foreground="#ffffff")
        t.tag_configure("urgente15", foreground="#cc0000")
        t.tag_configure("atencao30", foreground="#cc8800")
        t.tag_configure("ok",        foreground="#228822")
        # Duplo clique numa linha → abre edição; duplo clique no header → autosize
        t.bind("<Double-1>", lambda e, tt=t: self._on_tree_double(e, tt))
        return t

    def _make_tree_inat(self, parent):
        fr = ttk.Frame(parent); fr.pack(fill="both", expand=True)
        cols = tuple(c[0] for c in _COLS_INAT)
        t = ttk.Treeview(fr, columns=cols, show="headings", height=20)
        for cid, hd, w, a in _COLS_INAT:
            t.heading(cid, text=hd); t.column(cid, width=w, anchor=a, minwidth=28)
        v = ttk.Scrollbar(fr, orient="vertical",   command=t.yview)
        h = ttk.Scrollbar(fr, orient="horizontal", command=t.xview)
        t.configure(yscrollcommand=v.set, xscrollcommand=h.set)
        v.pack(side="right", fill="y"); h.pack(side="bottom", fill="x")
        t.pack(fill="both", expand=True)
        t.bind("<Double-1>", lambda e, tt=t: self._on_tree_double(e, tt))
        return t

    # ── Autosize de colunas ───────────────────────────────────────────

    def _on_tree_double(self, event, tree):
        """
        Duplo clique:
          - Na região 'heading' (separador de header) → autosize da coluna
          - Em qualquer outra região → abre edição da linha selecionada
        """
        region = tree.identify_region(event.x, event.y)
        if region == "separator":
            # Identificar qual coluna está à esquerda do separador
            col = tree.identify_column(event.x)
            self._autosize_column(tree, col)
        else:
            self.open_edit()

    def _autosize_column(self, tree, col_id):
        """Ajusta uma única coluna pelo conteúdo mais largo (header ou dados)."""
        try:
            f = tkfont.nametofont("TkDefaultFont")
        except Exception:
            f = tkfont.Font()
        pad = 20   # padding lateral

        # Largura do header
        header_text = tree.heading(col_id, "text")
        max_w = f.measure(header_text) + pad

        # Largura do conteúdo das linhas visíveis
        col_idx = int(col_id.replace("#", "")) - 1
        for iid in tree.get_children(""):
            vals = tree.item(iid, "values")
            if col_idx < len(vals):
                w = f.measure(str(vals[col_idx])) + pad
                if w > max_w:
                    max_w = w

        tree.column(col_id, width=max_w)

    def _autosize_tree(self, tree):
        """Ajusta TODAS as colunas de uma tree pelo conteúdo mais longo."""
        try:
            f = tkfont.nametofont("TkDefaultFont")
        except Exception:
            f = tkfont.Font()
        pad = 20

        cols = tree["columns"]
        # Medir headers
        widths = {}
        for col in cols:
            widths[col] = f.measure(tree.heading(col, "text")) + pad

        # Medir conteúdo de todas as linhas
        for iid in tree.get_children(""):
            vals = tree.item(iid, "values")
            for i, col in enumerate(cols):
                if i < len(vals):
                    w = f.measure(str(vals[i])) + pad
                    if w > widths[col]:
                        widths[col] = w

        for col, w in widths.items():
            tree.column(col, width=w)

    def _autosize_all(self):
        """Chama autosize em todas as trees visíveis após popular os dados."""
        for t in self._trees.values():
            self._autosize_tree(t)
        self._autosize_tree(self._tree_inat)

    # ── Dados / filtros ────────────────────────────────────────────────

    def refresh_grid(self):
        self._all_rows      = self.cnd_service.cnd_repo.list_summary()
        self._inactive_rows = self.cnd_service.cnd_repo.list_inactive()
        self._update_filter_opts()
        self._filter()
        self._pop_inat()

    def _update_filter_opts(self):
        rows = self._all_rows
        def _opts(key, ph):
            return [ph] + sorted({str(r.get(key) or "").strip() for r in rows if r.get(key)})
        self._fe.configure(values=_opts("empresa_grupo_informado", self._fe._placeholder))
        self._ff.configure(values=_opts("filial_informada",        self._ff._placeholder))
        self._fc.configure(values=_opts("cnpj_informado",          self._fc._placeholder))
        ufs = [self._fu._placeholder] + sorted({(r.get("uf") or "").upper() for r in rows if r.get("uf")})
        self._fu.configure(values=ufs)
        self._fs.configure(values=_opts("status_cnd_informado",    self._fs._placeholder))

    def _cb_val(self, cb) -> str:
        v = cb.get().strip()
        return "" if v == cb._placeholder else v

    def _filter(self):
        emp  = strip_accents(self._cb_val(self._fe)).lower()
        fil  = strip_accents(self._cb_val(self._ff)).lower()
        cnpj = self._cb_val(self._fc).replace(".","").replace("/","").replace("-","")
        uf   = self._cb_val(self._fu).upper()
        # Status: comparação EXATA (ignora acento, ignora case)
        sta_raw = self._cb_val(self._fs)
        sta  = strip_accents(sta_raw).lower()
        venc = self._fv_var.get()
        if venc == "Vencimento": venc = ""
        txt    = strip_accents(self._ft.get().strip()).lower()
        comm_f = strip_accents(self._fcomm.get().strip()).lower()

        ok = []
        for r in self._all_rows:
            if emp  and emp  not in strip_accents(r.get("empresa_grupo_informado") or "").lower(): continue
            if fil  and fil  not in strip_accents(r.get("filial_informada")        or "").lower(): continue
            if cnpj and cnpj not in (r.get("cnpj_informado") or "").replace(".","").replace("/","").replace("-",""): continue
            if uf   and uf   != (r.get("uf") or "").upper(): continue
            # Status: correspondência EXATA (strip_accents + lower)
            if sta and strip_accents(r.get("status_cnd_informado") or "").lower() != sta: continue
            if venc:
                d = r.get("dias_para_vencer")
                if d is None: continue
                d = int(d)
                if venc == "Vencidas"  and d >= 0:   continue
                if venc == "≤ 15 dias" and not (0 <= d <= 15):  continue
                if venc == "≤ 30 dias" and not (16 <= d <= 30): continue
                if venc == "OK (> 30)" and d <= 30:  continue
            if txt:
                # Busca em TODAS as colunas disponíveis no resumo
                hay = strip_accents(" ".join(str(r.get(k) or "") for k in (
                    "empresa_grupo_informado","filial_informada","cnpj_informado",
                    "uf","orgao_emissor_informado","status_cnd_informado",
                    "criticidade_informada","status_processo_informado",
                    "data_emissao","data_validade","comunicacao_resumo",
                    "numero_certidao",
                ))).lower()
                if txt not in hay: continue
            if comm_f and comm_f not in strip_accents(
                    r.get("comunicacao_resumo") or "").lower():
                continue
            ok.append(r)

        self._filtered_rows = ok

        for t in self._trees.values():
            for i in t.get_children(): t.delete(i)

        for r in ok:
            esf = r.get("esfera",""); grp = r.get("empresa_grupo_informado","")
            tag = self._tag(r.get("dias_para_vencer")); vals = self._vals(r)
            k = f"{esf}|{grp}"
            if k in self._trees:
                self._trees[k].insert("","end", iid=str(r["id"]), values=vals,
                                       tags=(tag,) if tag else ())
            k2 = f"{esf}|Todas"
            if k2 in self._trees:
                self._trees[k2].insert("","end", iid=f"t{r['id']}", values=vals,
                                        tags=(tag,) if tag else ())
        self._dash.update(ok)
        # Autosize: ajustar largura de todas as colunas pelo conteúdo atual
        self.after(50, self._autosize_all)

        v    = sum(1 for r in ok if (r.get("dias_para_vencer") is not None and int(r["dias_para_vencer"]) < 0))
        a15  = sum(1 for r in ok if (r.get("dias_para_vencer") is not None and 0 <= int(r["dias_para_vencer"]) <= 15))
        a30  = sum(1 for r in ok if (r.get("dias_para_vencer") is not None and 16 <= int(r["dias_para_vencer"]) <= 30))
        aok  = sum(1 for r in ok if (r.get("dias_para_vencer") is not None and int(r["dias_para_vencer"]) > 30))
        self._sv.set(
            f"Total: {len(self._all_rows)}  |  Filtrado: {len(ok)}  |  "
            f"Vencidas: {v}  |  ≤15d: {a15}  |  ≤30d: {a30}  |  OK: {aok}  |  Inativos: {len(self._inactive_rows)}"
        )

    def _pop_inat(self):
        for i in self._tree_inat.get_children(): self._tree_inat.delete(i)
        for r in self._inactive_rows:
            self._tree_inat.insert("","end", iid=f"i{r['id']}", values=(
                r.get("empresa_grupo_informado",""), r.get("filial_informada",""),
                r.get("cnpj_informado",""), r.get("uf",""),
                r.get("orgao_emissor_informado",""), r.get("status_cnd_informado",""),
                r.get("data_validade","") or "", r.get("motivo_inativacao","") or "",
            ))

    def _clear(self):
        for cb in (self._fe, self._ff, self._fc, self._fu, self._fs):
            cb.set(cb._placeholder)
            try: cb.configure(text_color="gray")
            except: pass
        self._ft.delete(0, "end")
        self._fcomm.delete(0, "end")
        self._fv.set("Vencimento")
        self._filter()

    @staticmethod
    def _vals(r):
        # Ordem deve ser IDÊNTICA à de _COLUMNS:
        # empresa, filial, cnpj, ie, im, uf, orgao, status,
        # emissao, validade, dias, crit, pdf, comm
        pdf  = "✓" if r.get("caminho_pdf") else ""
        comm = (r.get("comunicacao_resumo") or "").strip()
        d    = r.get("dias_para_vencer")
        return (
            r.get("empresa_grupo_informado",""),
            r.get("filial_informada",""),
            r.get("cnpj_informado",""),
            r.get("inscricao_estadual","") or "",
            r.get("inscricao_municipal","") or "",
            r.get("uf",""),
            r.get("orgao_emissor_informado",""),
            r.get("status_cnd_informado",""),
            (lambda s: f"{s[8:10]}-{s[5:7]}-{s[0:4]}" if len(s)==10 and s[4]=="-" else s)(r.get("data_emissao","") or ""),
            (lambda s: f"{s[8:10]}-{s[5:7]}-{s[0:4]}" if len(s)==10 and s[4]=="-" else s)(r.get("data_validade","") or ""),
            "" if d is None else str(d),
            r.get("criticidade_informada",""),
            pdf,
            comm,
        )

    @staticmethod
    def _tag(d):
        """
        Esquema de cor por prazo de vencimento:
          vencida   → d < 0        (vencida)   linha vermelha + fonte branca
          urgente15 → 0 <= d <= 15 (≤ 15 dias) linha branca  + fonte vermelha
          atencao30 → 16 <= d <= 30(≤ 30 dias) linha branca  + fonte amarela
          ok        → d > 30       (segura)    linha branca  + fonte verde
        """
        if d is None: return ""
        try: d = int(d)
        except: return ""
        if d < 0:   return "vencida"
        if d <= 15: return "urgente15"
        if d <= 30: return "atencao30"
        return "ok"

    # ── Seleção ────────────────────────────────────────────────────────

    def _cur_tree(self):
        try:
            idx = self._nb.index("current")
            # Dashboard=0, esferas=1,2,3, inativos=4
            if idx <= self._DASH_IDX or idx >= self._INAT_IDX:
                return None
            esf = _ESFERAS[idx - self._ESF_START]
            ns  = self._nb_sub[esf]
            si  = ns.index("current")
            grps = list(_GRUPOS) + ["Todas"]
            grp = grps[si] if si < len(grps) else "Todas"
            return self._trees.get(f"{esf}|{grp}")
        except: return None

    def _is_inat_tab(self):
        try: return self._nb.index("current") == self._INAT_IDX
        except: return False

    def _cur_esfera_grupo(self):
        """Retorna (esfera, grupo) da subaba ativa, para nomear exportação."""
        try:
            idx = self._nb.index("current")
            if idx <= self._DASH_IDX or idx >= self._INAT_IDX:
                return "Todos", "Todos"
            esf = _ESFERAS[idx - self._ESF_START]
            ns  = self._nb_sub[esf]
            si  = ns.index("current")
            grps = list(_GRUPOS) + ["Todas"]
            grp = grps[si] if si < len(grps) else "Todas"
            return esf, grp
        except: return "Todos", "Todos"

    def _cur_tree_rows(self) -> list[dict]:
        """Retorna apenas os registros visíveis na subaba ativa."""
        t = self._cur_tree()
        if t is None: return self._filtered_rows
        ids_na_tela = set()
        for iid in t.get_children(""):
            try: ids_na_tela.add(int(iid.lstrip("t")))
            except: pass
        return [r for r in self._filtered_rows if r.get("id") in ids_na_tela]

    def _sel_id(self):
        if self._is_inat_tab():
            s = self._tree_inat.selection()
            if not s: return None
            try: return int(s[0].lstrip("i"))
            except: return None
        t = self._cur_tree()
        if not t: return None
        s = t.selection()
        if not s: return None
        try: return int(s[0].lstrip("t"))
        except: return None

    def _sel_cnd(self):
        sid = self._sel_id()
        return self.cnd_service.get_cnd_by_id(sid) if sid else None

    def _assert_perm(self, r):
        if not r: raise ValueError("Registro não encontrado.")
        if not self.cnd_service.can_manage_esfera(self.user, r["esfera"]):
            raise PermissionError("Seu perfil não permite alterar registros desta esfera.")

    # ── Ações ──────────────────────────────────────────────────────────

    def add_cnd(self):
        if self._is_consulta:
            messagebox.showinfo("Permissão","Perfil somente leitura."); return
        try:
            win = CndFormWindow(self, self.catalog_service, self.cnd_service,
                                self.user, self.session["sessao_id"])
            win.grab_set()
            self.wait_window(win)
            self.refresh_grid()
        except Exception as ex: messagebox.showerror("Erro", str(ex))

    def open_edit(self):
        sid = self._sel_id()
        if not sid: messagebox.showwarning("Seleção","Selecione uma CND."); return
        try:
            r = self._sel_cnd()
            if not r: messagebox.showwarning("Seleção","Registro não encontrado."); return
            win = CndFormWindow(
                self, self.catalog_service, self.cnd_service,
                self.user, self.session["sessao_id"],
                cnd_id=sid,
                readonly=False,
                on_inactivate_callback=self.refresh_grid,
            )
            # grab_set garante janela única: bloqueia cliques na janela principal
            win.grab_set()
            self.wait_window(win)
            self.refresh_grid()
        except Exception as ex: messagebox.showerror("Erro", str(ex))

    def reactivate(self):
        """Reativar via sidebar — só funciona na aba Inativos."""
        if not self._is_inat_tab():
            messagebox.showinfo("Reativar","Selecione um registro na aba Inativos."); return
        sid = self._sel_id()
        if not sid: messagebox.showwarning("Seleção","Selecione uma CND inativa."); return
        try:
            r = self._sel_cnd(); self._assert_perm(r)
            if not messagebox.askyesno("Reativar",
                f"{r.get('empresa_grupo_informado','')} / {r.get('filial_informada','')}\nConfirma?"): return
            self.cnd_service.reactivate_cnd(sid, self.user, self.session["sessao_id"])
            messagebox.showinfo("OK","CND reativada."); self.refresh_grid()
        except Exception as ex: messagebox.showerror("Erro", str(ex))

    def export_excel(self):
        """Exporta APENAS os registros da subaba ativa, com filtros aplicados."""
        rows = self._cur_tree_rows()
        if not rows:
            messagebox.showinfo("Exportar","Nenhum registro visível na aba atual."); return

        esfera, grupo = self._cur_esfera_grupo()
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        nome_sugerido = (
            f"CND_{esfera}_{grupo.replace(' ','_').replace('.','').replace('/','')}"
            f"_{ts}.xlsx"
        )

        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel","*.xlsx"),("Todos","*.*")],
            initialfile=nome_sugerido,
            title="Salvar exportação Excel",
        )
        if not path: return

        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment

            # Buscar dados completos de cada CND (incluindo campos da janela de edição)
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = f"{esfera} {grupo}"[:31]

            # Headers = todos os labels da CndFormWindow
            headers = [
                "Esfera","Empresa/Grupo","Filial","UF","Local","CNPJ",
                "Inscrição Estadual","Inscrição Municipal","Órgão Emissor",
                "Criticidade","Status CND","Número da Certidão","Prazo Vencimento",
                "Mapeamento","Informações Filial","Responsável","Analista Filial",
                "OBS eStracta","Status Processo","OBS Status","OBS Filial","Observações",
                "Data Emissão","Data Validade","Dias para Vencer",
                "Caminho PDF","Comunicação","Motivo Inativação",
            ]

            hdr_fill = PatternFill("solid", fgColor="1F538D")
            hdr_font = Font(bold=True, color="FFFFFF")
            for ci, h in enumerate(headers, 1):
                cell = ws.cell(row=1, column=ci, value=h)
                cell.fill = hdr_fill; cell.font = hdr_font
                cell.alignment = Alignment(horizontal="center")

            for ri, r in enumerate(rows, 2):
                # Buscar registro completo para ter TODOS os campos
                full = self.cnd_service.get_cnd_by_id(r["id"])
                if not full: full = r
                d = full.get("dias_para_vencer")
                ws.append([
                    full.get("esfera",""),
                    full.get("empresa_grupo_informado",""),
                    full.get("filial_informada",""),
                    full.get("uf",""),
                    full.get("local_informado",""),
                    full.get("cnpj_informado",""),
                    full.get("inscricao_estadual","") or "",
                    full.get("inscricao_municipal","") or "",
                    full.get("orgao_emissor_informado",""),
                    full.get("criticidade_informada",""),
                    full.get("status_cnd_informado",""),
                    full.get("numero_certidao","") or "",
                    full.get("prazo_vencimento_texto","") or "",
                    full.get("mapeamento","") or "",
                    full.get("informacoes_filial","") or "",
                    full.get("responsavel_informado","") or "",
                    full.get("analista_filial_informado","") or "",
                    full.get("obs_estracta","") or "",
                    full.get("status_processo_informado","") or "",
                    full.get("obs_status","") or "",
                    full.get("obs_filial","") or "",
                    full.get("observacoes","") or "",
                    full.get("data_emissao","") or "",
                    full.get("data_validade","") or "",
                    int(d) if d is not None else "",
                    full.get("caminho_pdf","") or "",
                    full.get("comunicacao_resumo","") or "",
                    full.get("motivo_inativacao","") or "",
                ])
                # Colorir linha por vencimento (mesmo esquema da tela)
                if d is not None:
                    d_int = int(d)
                    if d_int < 0:
                        # Vencida: fundo vermelho + fonte branca
                        _fill = PatternFill("solid", fgColor="CC0000")
                        _font_color = "FFFFFF"
                    elif d_int <= 15:
                        # Urgente ≤15d: fundo branco + fonte vermelha
                        _fill = None
                        _font_color = "CC0000"
                    elif d_int <= 30:
                        # Atenção ≤30d: fundo branco + fonte amarela/laranja
                        _fill = None
                        _font_color = "CC8800"
                    else:
                        # OK >30d: fundo branco + fonte verde
                        _fill = None
                        _font_color = "228822"
                    for ci in range(1, len(headers)+1):
                        cell = ws.cell(row=ri, column=ci)
                        if _fill:
                            cell.fill = _fill
                        cell.font = Font(color=_font_color,
                                         bold=(cell.font.bold if cell.font else False))

            for col in ws.columns:
                ml = max((len(str(c.value or "")) for c in col), default=10)
                ws.column_dimensions[col[0].column_letter].width = min(ml+4, 45)

            wb.save(path)
            messagebox.showinfo("Exportação",
                f"{len(rows)} registros exportados para:\n{path}")
        except ImportError:
            messagebox.showerror("Erro","Instale openpyxl: pip install openpyxl")
        except Exception as ex:
            messagebox.showerror("Erro na exportação", str(ex))

    def export_auditoria(self):
        """Exporta todo o log de auditoria para Excel (só admin)."""
        if not self._is_admin:
            messagebox.showinfo("Permissão", "Apenas administradores podem exportar a auditoria.")
            return
        from datetime import datetime
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx"), ("Todos", "*.*")],
            initialfile=f"CND_Auditoria_{ts}.xlsx",
            title="Salvar log de auditoria",
        )
        if not path: return
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment

            # Buscar todos os registros de auditoria
            with self.cnd_service.cnd_repo.dbm.session() as conn:
                cur = conn.execute("""
                    SELECT
                        a.id,
                        a.evento_em,
                        a.evento_tipo,
                        a.tabela_alvo,
                        a.registro_id,
                        a.usuario_login,
                        a.maquina_nome,
                        a.sessao_id,
                        a.campo_alterado,
                        a.valor_anterior,
                        a.valor_novo,
                        a.motivo,
                        a.payload_json
                    FROM audit_log a
                    ORDER BY a.evento_em DESC
                """)
                cols_db = [d[0] for d in cur.description]
                rows_db = [dict(zip(cols_db, row)) for row in cur.fetchall()]

            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Auditoria"

            headers = [
                "ID", "Data/Hora", "Tipo de Evento", "Tabela",
                "ID Registro", "Usuário", "Máquina", "Sessão",
                "Campo Alterado", "Valor Anterior", "Valor Novo",
                "Motivo", "Payload (JSON)",
            ]

            hdr_fill = PatternFill("solid", fgColor="1F538D")
            hdr_font = Font(bold=True, color="FFFFFF")
            for ci, h in enumerate(headers, 1):
                cell = ws.cell(row=1, column=ci, value=h)
                cell.fill = hdr_fill
                cell.font = hdr_font
                cell.alignment = Alignment(horizontal="center")

            # Cores por tipo de evento
            _event_colors = {
                "LOGIN_FAILURE":      "FFCCCC",
                "LOCK_OVERRIDE":      "FFE0B0",
                "INTEGRITY_OVERRIDE": "FFE0B0",
                "INACTIVATE_CND":     "FFF0CC",
                "CREATE_CND":         "E8F5E9",
                "UPDATE_CND":         "E3F2FD",
                "REACTIVATE_CND":     "E8F5E9",
                "CREATE_USER":        "F3E5F5",
                "INACTIVATE_USER":    "FFCCCC",
                "UPDATE_USER":        "FFF0CC",
            }

            for ri, r in enumerate(rows_db, 2):
                ws.append([
                    r.get("id"),
                    r.get("evento_em", ""),
                    r.get("evento_tipo", ""),
                    r.get("tabela_alvo", ""),
                    r.get("registro_id"),
                    r.get("usuario_login", ""),
                    r.get("maquina_nome", ""),
                    r.get("sessao_id", "") or "",
                    r.get("campo_alterado", "") or "",
                    r.get("valor_anterior", "") or "",
                    r.get("valor_novo", "") or "",
                    r.get("motivo", "") or "",
                    r.get("payload_json", "") or "",
                ])
                cor = _event_colors.get(r.get("evento_tipo", ""))
                if cor:
                    fill = PatternFill("solid", fgColor=cor)
                    for ci in range(1, len(headers)+1):
                        ws.cell(row=ri, column=ci).fill = fill

            # Larguras
            ws.column_dimensions["A"].width = 8
            ws.column_dimensions["B"].width = 20
            ws.column_dimensions["C"].width = 22
            ws.column_dimensions["D"].width = 12
            ws.column_dimensions["E"].width = 12
            ws.column_dimensions["F"].width = 18
            ws.column_dimensions["G"].width = 16
            ws.column_dimensions["H"].width = 14
            ws.column_dimensions["I"].width = 20
            ws.column_dimensions["J"].width = 25
            ws.column_dimensions["K"].width = 25
            ws.column_dimensions["L"].width = 30
            ws.column_dimensions["M"].width = 50

            # Congelar cabeçalho
            ws.freeze_panes = "A2"

            wb.save(path)
            msg = f"{len(rows_db)} registros exportados para:\n{path}"
            messagebox.showinfo("Auditoria exportada", msg)
        except ImportError:
            messagebox.showerror("Erro", "Instale openpyxl: pip install openpyxl")
        except Exception as ex:
            messagebox.showerror("Erro na exportação", str(ex))

    def backup_now(self):
        if not self.backup_service: messagebox.showinfo("Backup","Serviço indisponível."); return
        r = self.backup_service.run()
        if r: messagebox.showinfo("Backup",f"Backup concluído:\n{r[0].name}")
        else:  messagebox.showerror("Backup","Falha ao realizar backup.")

    def restore_backup(self):
        if not self._is_admin: messagebox.showinfo("Permissão","Apenas administradores."); return
        from app.ui.windows.restore_backup_window import RestoreBackupWindow
        win = RestoreBackupWindow(self, self.backup_service,
                                  self.main_db_path, self.catalog_db_path, self.integrity_path,
                                  self.user, self.settings["version"], self.hmac_secret,
                                  on_restore=lambda: messagebox.showinfo("Restaurado",
                                      "Feche e reabra a aplicação."))
        self.wait_window(win)
        if win.restored: self.refresh_grid()

    def manage_users(self):
        if not self._is_admin: messagebox.showinfo("Permissão","Apenas administradores."); return
        from app.ui.windows.user_management_window import UserManagementWindow
        win = UserManagementWindow(self, self.user_service, self.user)
        self.wait_window(win)

    # ── Integridade / Utilitários ──────────────────────────────────────

    def set_integrity_status(self, ok, detail=""):
        if ok: self._int_lbl.configure(text="✔ Integridade OK", text_color="green")
        else:  self._int_lbl.configure(
            text=f"⚠ {detail}" if detail else "⚠ Integridade ALERTA", text_color="orange")

    def _sort(self, tree, col):
        k = id(tree); rev = self._sort_state.get((k,col), False)
        items = [(tree.set(i,col),i) for i in tree.get_children("")]
        try:
            if col == "dias": items.sort(key=lambda x: int(x[0]) if x[0] else 9999, reverse=rev)
            else:             items.sort(key=lambda x: x[0].lower(), reverse=rev)
        except: items.sort(reverse=rev)
        for idx,(_,i) in enumerate(items): tree.move(i,"",idx)
        self._sort_state[(k,col)] = not rev

    def _heartbeat(self):
        self.lock_manager.heartbeat()
        self.after(self.settings["lock"]["heartbeat_seconds"]*1000, self._heartbeat)

    def on_close(self):
        self.lock_manager.release(); self.root.destroy()
