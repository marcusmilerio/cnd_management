"""Gestão de Usuários — exclusiva para ADMIN."""
import customtkinter as ctk
from tkinter import ttk, messagebox

_PERFIS = [
    ("ADMIN",            "Administrador — acesso total"),
    ("EDITOR_FEDERAL",   "Editor Federal — apenas CNDs Federais"),
    ("EDITOR_ESTADUAL",  "Editor Estadual — apenas CNDs Estaduais"),
    ("EDITOR_MUNICIPAL", "Editor Municipal — apenas CNDs Municipais"),
    ("CONSULTA",         "Visualizador — somente leitura"),
]
_LABEL = {v: l for v, l in _PERFIS}


class UserManagementWindow(ctk.CTkToplevel):
    def __init__(self, master, user_service, admin_user: dict):
        super().__init__(master)
        self.user_service = user_service
        self.admin_user   = admin_user
        self.title("CND Manager — Gestão de Usuários")
        self.geometry("900x580")
        self.minsize(720, 460)
        self.grab_set()
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"900x580+{(sw-900)//2}+{(sh-580)//2}")
        self._build_ui()
        self._load()

    def _build_ui(self):
        ctk.CTkLabel(self, text="Gestão de Usuários",
                     font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w", padx=16, pady=(12,4))

        # Grid
        tf = ctk.CTkFrame(self)
        tf.pack(fill="both", expand=True, padx=16, pady=(0,4))
        cols = ("nome","login","perfil","ativo","ul","tmp")
        self._tree = ttk.Treeview(tf, columns=cols, show="headings", height=13)
        for cid, hd, w, a in [
            ("nome","Nome",200,"w"),("login","Login",100,"center"),
            ("perfil","Perfil",200,"w"),("ativo","Situação",80,"center"),
            ("ul","Último login",150,"center"),("tmp","Senha temp?",90,"center"),
        ]:
            self._tree.heading(cid, text=hd)
            self._tree.column(cid, width=w, anchor=a, minwidth=40)
        vsb = ttk.Scrollbar(tf, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self._tree.pack(fill="both", expand=True)
        self._tree.tag_configure("inativo", foreground="gray")

        # Novo usuário
        nf = ctk.CTkFrame(self)
        nf.pack(fill="x", padx=16, pady=(0,4))
        ctk.CTkLabel(nf, text="Novo usuário:",
                     font=ctk.CTkFont(size=12, weight="bold")).grid(
                     row=0, column=0, columnspan=7, sticky="w", padx=8, pady=(8,2))
        ctk.CTkLabel(nf, text="Nome:").grid(row=1, column=0, padx=(8,2), pady=6)
        self._e_nome  = ctk.CTkEntry(nf, width=170, placeholder_text="Nome completo")
        self._e_nome.grid(row=1, column=1, padx=4, pady=6)
        ctk.CTkLabel(nf, text="Login:").grid(row=1, column=2, padx=(8,2))
        self._e_login = ctk.CTkEntry(nf, width=110, placeholder_text="login")
        self._e_login.grid(row=1, column=3, padx=4)
        ctk.CTkLabel(nf, text="Perfil:").grid(row=1, column=4, padx=(8,2))
        self._perf_var = ctk.StringVar(value="EDITOR_FEDERAL")
        ctk.CTkComboBox(nf, values=[v for v,_ in _PERFIS],
                        variable=self._perf_var, width=170).grid(row=1,column=5,padx=4)
        ctk.CTkButton(nf, text="Criar", width=90,
                      command=self._create).grid(row=1, column=6, padx=8)
        ctk.CTkLabel(nf, text="Senha inicial: 1234 — usuário trocará no primeiro acesso",
                     font=ctk.CTkFont(size=10), text_color="gray").grid(
                     row=2, column=0, columnspan=7, sticky="w", padx=8, pady=(0,6))

        # Ações
        af = ctk.CTkFrame(self, fg_color="transparent")
        af.pack(fill="x", padx=16, pady=(0,12))
        ctk.CTkButton(af, text="Resetar senha (→ 1234)", width=190,
                      fg_color="#7a5000", command=self._reset).pack(side="left", padx=(0,8))
        ctk.CTkButton(af, text="Excluir usuário", width=140,
                      fg_color="#7a1a1a", command=self._delete).pack(side="left", padx=(0,8))
        ctk.CTkButton(af, text="Atualizar", width=100,
                      command=self._load).pack(side="left", padx=(0,8))
        ctk.CTkButton(af, text="Fechar", width=90,
                      command=self.destroy).pack(side="right")

    def _load(self):
        for i in self._tree.get_children(): self._tree.delete(i)
        for u in self.user_service.list_users():
            ul  = (u.get("ultimo_login_em") or "—")[:19]
            tag = () if u.get("ativo") else ("inativo",)
            self._tree.insert("","end", iid=str(u["id"]), values=(
                u.get("nome_usuario",""), u.get("login",""),
                _LABEL.get(u.get("perfil",""), u.get("perfil","")),
                "Ativo" if u.get("ativo") else "Inativo",
                ul, "Sim" if u.get("must_change_password") else "Não",
            ), tags=tag)

    def _sel_id(self):
        s = self._tree.selection()
        return int(s[0]) if s else None

    def _create(self):
        try:
            self.user_service.create_user(
                nome=self._e_nome.get(), login=self._e_login.get(),
                perfil=self._perf_var.get(), admin_user=self.admin_user)
            messagebox.showinfo("Criado",
                f"Usuário '{self._e_login.get()}' criado.\nSenha inicial: 1234", parent=self)
            self._e_nome.delete(0,"end"); self._e_login.delete(0,"end")
            self._load()
        except Exception as e:
            messagebox.showerror("Erro", str(e), parent=self)

    def _reset(self):
        uid = self._sel_id()
        if not uid:
            messagebox.showwarning("Seleção","Selecione um usuário.", parent=self); return
        u = self.user_service.user_repo.get_by_id(uid)
        ativo = u.get("ativo", 1)
        msg = (
            f"Resetar senha de '{u['login']}' para '1234'?\n"
            "O usuário precisará trocar no próximo acesso."
        )
        if not ativo:
            msg += "\n\nAtenção: este usuário está inativo. Ao resetar a senha, ele será REATIVADO."
        if not messagebox.askyesno("Resetar senha", msg, parent=self): return
        try:
            self.user_service.reset_password(uid, self.admin_user, reactivate=True)
            if ativo:
                messagebox.showinfo("Ok","Senha redefinida para '1234'.", parent=self)
            else:
                messagebox.showinfo("Ok","Usuário reativado e senha redefinida para '1234'.", parent=self)
            self._load()
        except Exception as e:
            messagebox.showerror("Erro", str(e), parent=self)

    def _delete(self):
        uid = self._sel_id()
        if not uid:
            messagebox.showwarning("Seleção","Selecione um usuário.", parent=self); return
        u = self.user_service.user_repo.get_by_id(uid)
        if not messagebox.askyesno("Excluir",
            f"Excluir usuário '{u['login']}'?\n"
            "O registro permanece no banco mas o acesso será bloqueado.", parent=self): return
        try:
            self.user_service.deactivate_user(uid, self.admin_user)
            messagebox.showinfo("Ok","Usuário excluído.", parent=self)
            self._load()
        except Exception as e:
            messagebox.showerror("Erro", str(e), parent=self)
