"""
Janela de troca de senha.

Aberta obrigatoriamente quando must_change_password = 1.
Pode ser aberta voluntariamente também (modo não-obrigatório).

Atributos após fechar:
  changed (bool) — True se a senha foi trocada com sucesso
"""
import customtkinter as ctk
from tkinter import messagebox


class ChangePasswordWindow(ctk.CTkToplevel):
    def __init__(self, master, user_service, user: dict, obrigatorio: bool = True):
        super().__init__(master)

        self.user_service = user_service
        self.user         = user
        self.obrigatorio  = obrigatorio
        self.changed      = False

        titulo = "Troca de senha obrigatória" if obrigatorio else "Alterar senha"
        self.title(f"CND Manager — {titulo}")
        self.geometry("440x400")
        self.resizable(False, False)
        self.grab_set()

        # Não pode fechar sem trocar se for obrigatório
        if obrigatorio:
            self.protocol("WM_DELETE_WINDOW", self._on_cancel_obrigatorio)

        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"440x400+{(sw-440)//2}+{(sh-400)//2}")

        self._build_ui()

    def _build_ui(self):
        if self.obrigatorio:
            hdr = ctk.CTkFrame(self, fg_color="#5a3a00", corner_radius=0)
            hdr.pack(fill="x")
            ctk.CTkLabel(
                hdr,
                text="⚠  Troca de senha obrigatória",
                font=ctk.CTkFont(size=13, weight="bold"),
                text_color="white",
            ).pack(pady=10)
            ctk.CTkLabel(
                self,
                text=f"Olá, {self.user.get('nome_usuario', '')}.\n"
                     "Esta é sua primeira entrada ou sua senha foi redefinida.\n"
                     "Defina uma nova senha para continuar.",
                font=ctk.CTkFont(size=11),
                text_color="gray",
                justify="center",
                wraplength=360,
            ).pack(pady=(12, 4))
        else:
            ctk.CTkLabel(
                self,
                text="Alterar senha",
                font=ctk.CTkFont(size=14, weight="bold"),
            ).pack(pady=(20, 4))

        form = ctk.CTkFrame(self, fg_color="transparent")
        form.pack(fill="x", padx=30, pady=8)

        ctk.CTkLabel(form, text="Senha atual:", anchor="w").pack(fill="x")
        self._atual = ctk.CTkEntry(form, show="*", width=340)
        self._atual.pack(fill="x", pady=(0, 8))

        ctk.CTkLabel(form, text="Nova senha (mín. 4 caracteres):", anchor="w").pack(fill="x")
        self._nova = ctk.CTkEntry(form, show="*", width=340)
        self._nova.pack(fill="x", pady=(0, 8))

        ctk.CTkLabel(form, text="Confirmar nova senha:", anchor="w").pack(fill="x")
        self._confirma = ctk.CTkEntry(form, show="*", width=340)
        self._confirma.pack(fill="x", pady=(0, 8))

        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=30, pady=(0, 20))

        ctk.CTkButton(
            btn_frame, text="Salvar nova senha",
            command=self._save, width=200, height=36,
        ).pack(anchor="center", pady=(0, 8))

        if not self.obrigatorio:
            ctk.CTkButton(
                btn_frame, text="Cancelar",
                command=self.destroy,
                fg_color="gray30", border_width=1, width=120,
            ).pack(anchor="center")

        self._atual.focus()
        self.bind("<Return>", lambda _e: self._save())

    def _save(self):
        try:
            self.user_service.change_password(
                self.user["id"],
                self._atual.get(),
                self._nova.get(),
                self._confirma.get(),
            )
            messagebox.showinfo("Senha alterada", "Senha alterada com sucesso!", parent=self)
            self.changed = True
            self.grab_release()
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Erro", str(exc), parent=self)
            self._nova.delete(0, "end")
            self._confirma.delete(0, "end")
            self._nova.focus()

    def _on_cancel_obrigatorio(self):
        messagebox.showwarning(
            "Troca obrigatória",
            "Você deve definir uma nova senha antes de continuar.\n"
            "Use o botão 'Salvar nova senha'.",
            parent=self,
        )
