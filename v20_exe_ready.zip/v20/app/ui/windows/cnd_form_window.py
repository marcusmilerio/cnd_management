"""
CndFormWindow — V17.

Janela única para todos os perfis. Botões sempre visíveis.
Ativação por perfil:
  ADMIN            → todos ativos
  EDITOR (esfera própria ou novo) → todos ativos
  EDITOR (esfera alheia) → apenas Cancelar e Abrir PDF
  CONSULTA         → apenas Cancelar e Abrir PDF

Espaçamento padronizado:
  EP = pady=(3,3)   — espaçamento pequeno entre campos do mesmo grupo
  EG = pady=(3,14)  — espaçamento grande após último campo do grupo
"""
import os
import customtkinter as ctk
from tkinter import messagebox, simpledialog, filedialog

from app.models.cnd import CND
from app.ui.components.editable_combobox import EditableComboBox
from app.ui.components.file_picker_field import FilePickerField
from app.ui.components.cnpj_field import CnpjField
from app.ui.components.date_field import DateField
from app.ui.windows.communication_window import CommunicationWindow

_EP = (3, 3)    # espaçamento pequeno (dentro de grupo)
_EG = (3, 42)   # espaçamento grande  (fim de grupo)

_FIELD_MAP = {
    "Esfera":               "esfera",
    "Empresa/Grupo":        "empresa_grupo_informado",
    "Filial":               "filial_informada",
    "UF":                   "uf",
    "Local":                "local_informado",
    "CNPJ":                 "cnpj_informado",
    "Inscrição Estadual":   "inscricao_estadual",
    "Inscrição Municipal":  "inscricao_municipal",
    "Órgão Emissor":        "orgao_emissor_informado",
    "Criticidade":          "criticidade_informada",
    "Status CND":           "status_cnd_informado",
    "Número da Certidão":   "numero_certidao",
    "Data Emissão":         "data_emissao",
    "Data Validade":        "data_validade",
    "Prazo Vencimento":     "prazo_vencimento_texto",
    "Mapeamento":           "mapeamento",
    "Informações Filial":   "informacoes_filial",
    "Responsável":          "responsavel_informado",
    "Analista Filial":      "analista_filial_informado",
    "OBS eStracta":         "obs_estracta",
    "Status":               "status_processo_informado",
    "OBS Status":           "obs_status",
    "OBS Filial":           "obs_filial",
    "Observações":          "observacoes",
}

_UFS = ["AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG",
        "PA","PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO"]

# Mapa de espaçamento: label → pady que vem DEPOIS desse campo
# Campos sem entrada usam EP; campos que encerram grupo usam EG
_PADY_MAP = {
    "Inscrição Municipal": _EG,   # fim do grupo identificação básica
    "Prazo Vencimento":    _EG,   # fim do grupo certidão/datas
    "Observações":         _EG,   # fim do grupo observações
    "Comunicação":         _EG,   # comunicação isolada
}
_PADY_DEFAULT = _EP


def _btn_kw(text, cmd, enabled, color=None):
    """Gera kwargs para CTkButton sempre visível, disabled quando sem permissão."""
    if enabled:
        kw = dict(text=text, command=cmd)
        if color: kw["fg_color"] = color
        if color: kw["hover_color"] = _darken(color)
    else:
        kw = dict(text=text, command=lambda: None,
                  fg_color="#444444", hover_color="#444444",
                  text_color="#777777", state="disabled")
    return kw


def _darken(hex_color: str) -> str:
    """Escurece uma cor hex em ~20%."""
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
    return "#{:02x}{:02x}{:02x}".format(
        max(0,int(r*0.8)), max(0,int(g*0.8)), max(0,int(b*0.8)))


class CndFormWindow(ctk.CTkToplevel):

    def __init__(self, master, catalog_service, cnd_service, usuario, sessao_id,
                 cnd_id=None, readonly=False, on_inactivate_callback=None):
        super().__init__(master)

        self.catalog_service       = catalog_service
        self.cnd_service           = cnd_service
        self.usuario               = usuario
        self.sessao_id             = sessao_id
        self.cnd_id                = cnd_id
        self.on_inactivate_callback= on_inactivate_callback

        # Dados
        self.original_data          = None
        self._comunicacao_filiais   = []
        if self.cnd_id:
            self.original_data = self.cnd_service.get_cnd_by_id(self.cnd_id)
            if not self.original_data:
                raise ValueError("Registro de CND não encontrado para edição.")
            self._comunicacao_filiais = self.cnd_service.get_comunicacoes(self.cnd_id)

        # Permissões
        perfil          = (usuario.get("perfil","") or "").upper()
        esfera_registro = (self.original_data or {}).get("esfera","")
        registro_ativo  = int((self.original_data or {}).get("registro_ativo",1)) == 1

        self._pode_editar = (
            perfil == "ADMIN"
            or self.cnd_id is None   # novo registro
            or (perfil.startswith("EDITOR_")
                and self.cnd_service.can_manage_esfera(usuario, esfera_registro))
        )
        # Consulta ou editor fora da esfera → somente leitura nos campos
        self._campos_readonly = (
            readonly
            or perfil == "CONSULTA"
            or not self._pode_editar
        )

        # Status do registro
        self._eh_inativo    = (self.original_data is not None and not registro_ativo)
        self._can_inactivate= self._pode_editar and self.cnd_id is not None and registro_ativo
        self._can_reactivate= self._pode_editar and self.cnd_id is not None and self._eh_inativo

        # Widgets
        self.fields:          dict                  = {}
        self._cnpj_widget:    CnpjField | None      = None
        self._data_emissao:   DateField | None      = None
        self._data_validade:  DateField | None      = None

        # Título
        if self.cnd_id:
            self.title(f"Edição de CND #{self.cnd_id}")
        else:
            self.title("Cadastro de CND")

        self.geometry("1020x860")
        self.minsize(900, 700)
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"1020x860+{(sw-1020)//2}+{(sh-860)//2}")
        # Sempre em primeiro plano — bloqueia interação com a janela principal
        self.transient(master)
        self.lift()
        self.focus_force()

        self._build_ui()
        if self.original_data:
            self._load_data()
        if self._campos_readonly:
            self._apply_readonly()
        else:
            self._apply_editable()

    # ── Construção ─────────────────────────────────────────────────────

    def _build_ui(self):
        self._scroll = ctk.CTkScrollableFrame(self)
        self._scroll.pack(fill="both", expand=True, padx=12, pady=12)
        self._scroll.grid_columnconfigure(1, weight=1)
        self._render_fields()

    def _render_fields(self):
        for w in self._scroll.winfo_children(): w.destroy()
        self.fields.clear()

        cs              = self.catalog_service
        catalog_filiais = [i["value"] for i in cs.list_values("filiais")]

        # (label, tipo, values_ou_None)
        # Tipo: combo | text | textbox | cnpj | date
        field_defs = [
            # ── Grupo 1: identificação básica ──────────────────────────
            ("Esfera",             "combo",   ["Federal","Estadual","Municipal"]),
            ("Empresa/Grupo",      "combo",   [i["value"] for i in cs.list_values("empresas_grupos")]),
            ("Filial",             "combo",   catalog_filiais),
            ("UF",                 "combo",   _UFS),
            ("Local",              "combo",   [i["value"] for i in cs.list_values("locais")]),
            ("CNPJ",               "cnpj",    None),
            ("Inscrição Estadual", "text",    None),
            ("Inscrição Municipal","text",    None),   # EG depois deste
            # ── Grupo 2: certidão e datas ──────────────────────────────
            ("Órgão Emissor",      "combo",   [i["value"] for i in cs.list_values("orgaos_emissores")]),
            ("Criticidade",        "combo",   [i["value"] for i in cs.list_values("criticidades")]),
            ("Status CND",         "combo",   [i["value"] for i in cs.list_values("status_cnd")]),
            ("Número da Certidão", "text",    None),
            ("Data Emissão",       "date",    None),
            ("Data Validade",      "date",    None),
            ("Prazo Vencimento",   "text",    None),   # EG depois deste
            # ── Grupo 3: operacional ───────────────────────────────────
            ("Mapeamento",         "text",    None),
            ("Informações Filial", "text",    None),
            ("Responsável",        "combo",   [i["value"] for i in cs.list_values("responsaveis")]),
            ("Analista Filial",    "combo",   [i["value"] for i in cs.list_values("analistas_filial")]),
            ("OBS eStracta",       "textbox", None),
            ("Status",             "combo",   [i["value"] for i in cs.list_values("status_processo")]),
            ("OBS Status",         "textbox", None),
            ("OBS Filial",         "textbox", None),
            ("Observações",        "textbox", None),  # EG depois deste
        ]

        row = 0
        for label, tipo, values in field_defs:
            pady = _PADY_MAP.get(label, _PADY_DEFAULT)
            lbl_sticky = "nw" if tipo == "textbox" else "w"

            ctk.CTkLabel(self._scroll, text=label, anchor="w").grid(
                row=row, column=0, sticky=lbl_sticky, padx=8, pady=pady)

            if tipo == "cnpj":
                w = CnpjField(self._scroll)
                w.grid(row=row, column=1, sticky="ew", padx=8, pady=pady)
                self._cnpj_widget = w
            elif tipo == "date":
                w = DateField(self._scroll)
                w.grid(row=row, column=1, sticky="ew", padx=8, pady=pady)
                if label == "Data Emissão":   self._data_emissao  = w
                else:                          self._data_validade = w
            elif tipo == "textbox":
                w = ctk.CTkTextbox(self._scroll, height=80)
                w.grid(row=row, column=1, sticky="ew", padx=8, pady=pady)
                self.fields[label] = w
            elif tipo == "combo":
                w = EditableComboBox(self._scroll, values=values or [])
                w.grid(row=row, column=1, sticky="ew", padx=8, pady=pady)
                self.fields[label] = w
            else:
                w = ctk.CTkEntry(self._scroll)
                w.grid(row=row, column=1, sticky="ew", padx=8, pady=pady)
                self.fields[label] = w
            row += 1

        # ── Comunicação ────────────────────────────────────────────────
        pady_comm = _PADY_MAP.get("Comunicação", _EG)
        ctk.CTkLabel(self._scroll, text="Comunicação", anchor="w").grid(
            row=row, column=0, sticky="nw", padx=8, pady=pady_comm)
        comm_outer = ctk.CTkFrame(self._scroll, fg_color="transparent")
        comm_outer.grid(row=row, column=1, sticky="ew", padx=8, pady=pady_comm)
        comm_outer.grid_columnconfigure(0, weight=1)

        self._comm_textbox = ctk.CTkTextbox(comm_outer, height=60, state="disabled")
        self._comm_textbox.grid(row=0, column=0, sticky="ew", padx=(0,8))

        # Botão Editar comunicação — ativo só se pode editar
        self._btn_editar_comm = ctk.CTkButton(
            comm_outer, width=80,
            **_btn_kw("Editar",
                       lambda f=catalog_filiais: self._open_comm(f),
                       self._pode_editar))
        self._btn_editar_comm.grid(row=0, column=1)
        row += 1

        # ── PDF ────────────────────────────────────────────────────────
        ctk.CTkLabel(self._scroll, text="Caminho do PDF", anchor="w").grid(
            row=row, column=0, sticky="w", padx=8, pady=_EG)
        # FilePickerField já contém: [entry] [Selecionar] [Abrir]
        self.pdf = FilePickerField(self._scroll)
        self.pdf.grid(row=row, column=1, sticky="ew", padx=8, pady=_EG)
        row += 1

        # ── Botões de ação ─────────────────────────────────────────────
        # Regras por perfil:
        #   _pode_editar = True  → Salvar, Inativar/Reativar, Editar comm, Selecionar PDF ativos
        #   _pode_editar = False → apenas Cancelar e Abrir PDF ativos
        #   Abrir PDF: sempre ativo (gerenciado pelo FilePickerField.btn_abrir)
        #   Selecionar PDF: ativo só se _pode_editar

        bf = ctk.CTkFrame(self._scroll, fg_color="transparent")
        bf.grid(row=row, column=0, columnspan=2, sticky="ew", padx=8, pady=14)

        # Salvar
        ctk.CTkButton(bf,
            **_btn_kw("Salvar Alterações" if self.cnd_id else "Salvar",
                       self.save, self._pode_editar, "#1f538d")
        ).pack(side="left", padx=6)

        # Inativar / Reativar
        if self._eh_inativo:
            ctk.CTkButton(bf,
                **_btn_kw("Reativar Registro",
                           self._reativar, self._can_reactivate, "#1a5a1a")
            ).pack(side="left", padx=6)
        else:
            ctk.CTkButton(bf,
                **_btn_kw("Inativar Registro",
                           self._inativar, self._can_inactivate, "#7a1a1a")
            ).pack(side="left", padx=6)

        # Cancelar — sempre ativo
        ctk.CTkButton(bf, text="Cancelar",
                      fg_color="#3a3a3a", hover_color="#4a4a4a",
                      command=self.destroy).pack(side="left", padx=6)

        self._refresh_comm_display()

    # ── Comunicação ────────────────────────────────────────────────────

    def _open_comm(self, catalog_filiais):
        win = CommunicationWindow(self,
            filiais_atuais=self._comunicacao_filiais,
            filial_ref=self._get_value("Filial") if "Filial" in self.fields else "",
            catalog_filiais=catalog_filiais)
        self.wait_window(win)
        if win.confirmed:
            self._comunicacao_filiais = win.result
        self._refresh_comm_display()

    def _refresh_comm_display(self):
        self._comm_textbox.configure(state="normal")
        self._comm_textbox.delete("1.0","end")
        txt = ", ".join(self._comunicacao_filiais) if self._comunicacao_filiais else "(nenhuma)"
        self._comm_textbox.insert("1.0", txt)
        self._comm_textbox.configure(state="disabled")

    # ── PDF ────────────────────────────────────────────────────────────


    def _apply_readonly(self):
        _tc = "#777777"
        for w in self.fields.values():
            try:
                if isinstance(w, ctk.CTkTextbox): w.configure(state="disabled", text_color=_tc)
                else:                              w.configure(state="disabled", text_color=_tc)
            except: pass
        # CNPJ
        if self._cnpj_widget:
            try: self._cnpj_widget._entry.configure(state="disabled", text_color=_tc)
            except: pass
        # Datas — usar método disable() do novo DateField
        for attr in ("_data_emissao","_data_validade"):
            wgt = getattr(self, attr, None)
            if wgt:
                try: wgt.disable()
                except: pass
        # PDF: entry desabilitado (não editável), Selecionar desabilitado,
        # Abrir permanece ativo para visualizar o documento
        try:
            self.pdf.entry.configure(state="disabled", text_color=_tc)
            self.pdf.btn_selecionar.configure(
                state="disabled", fg_color="#444444",
                hover_color="#444444", text_color="#777777")
        except Exception:
            pass
        try: self._comm_textbox.configure(text_color=_tc)
        except: pass

    def _apply_editable(self):
        _tc = ("gray10","gray90")
        for w in self.fields.values():
            try:
                if not isinstance(w, ctk.CTkTextbox): w.configure(text_color=_tc)
            except: pass
        if self._cnpj_widget:
            try: self._cnpj_widget._entry.configure(text_color=_tc)
            except: pass
        for attr in ("_data_emissao","_data_validade"):
            wgt = getattr(self, attr, None)
            if wgt:
                try: wgt.enable()
                except: pass

    # ── Carga ──────────────────────────────────────────────────────────

    def _load_data(self):
        d = self.original_data
        for label, key in _FIELD_MAP.items():
            if label in ("Data Emissão","Data Validade","CNPJ"): continue
            if label in self.fields:
                self._set_val(self.fields[label], d.get(key,""))
        if self._cnpj_widget:
            self._cnpj_widget.set(d.get("cnpj_informado",""))
        if self._data_emissao:
            self._data_emissao.set(d.get("data_emissao",""))
        if self._data_validade:
            self._data_validade.set(d.get("data_validade",""))
        if d.get("caminho_pdf"):
            # Garantir entry normal durante load — será desabilitado em apply_readonly
            self.pdf.entry.configure(state="normal")
            self._set_val(self.pdf.entry, d["caminho_pdf"])
        self._refresh_comm_display()

    # ── Helpers ────────────────────────────────────────────────────────

    def _set_val(self, widget, value):
        value = "" if value is None else str(value)
        if isinstance(widget, ctk.CTkTextbox):
            widget.delete("1.0","end"); widget.insert("1.0",value); return
        try: widget.delete(0,"end")
        except: pass
        try: widget.insert(0,value); return
        except: pass
        try: widget.set(value)
        except: pass

    def _get_value(self, label: str) -> str:
        w = self.fields.get(label)
        if w is None: return ""
        if isinstance(w, ctk.CTkTextbox): return w.get("1.0","end").strip()
        return w.get().strip()

    # ── Inativar / Reativar ────────────────────────────────────────────

    def _inativar(self):
        r = self.cnd_service.get_cnd_by_id(self.cnd_id)
        if not r: return
        if not messagebox.askyesno("Inativar — 1/2",
            f"Empresa : {r.get('empresa_grupo_informado','')}\n"
            f"Filial  : {r.get('filial_informada','')}\n"
            f"Esfera  : {r.get('esfera','')}\n\nConfirmar inativação?", parent=self): return
        if not messagebox.askyesno("Inativar — 2/2",
            "Esta ação será auditada.\nConfirma definitivamente?", parent=self): return
        motivo = simpledialog.askstring("Motivo","Informe o motivo:", parent=self)
        if motivo is None: return
        if not motivo.strip():
            messagebox.showwarning("Motivo","Motivo é obrigatório.", parent=self); return
        try:
            self.cnd_service.inactivate_cnd(self.cnd_id, motivo, self.usuario, self.sessao_id)
            messagebox.showinfo("OK","Registro inativado.", parent=self)
            if self.on_inactivate_callback: self.on_inactivate_callback()
            self.destroy()
        except Exception as ex:
            messagebox.showerror("Erro", str(ex), parent=self)

    def _reativar(self):
        r = self.cnd_service.get_cnd_by_id(self.cnd_id)
        if not r: return
        if not messagebox.askyesno("Reativar",
            f"{r.get('empresa_grupo_informado','')} / {r.get('filial_informada','')}\nConfirma?",
            parent=self): return
        try:
            self.cnd_service.reactivate_cnd(self.cnd_id, self.usuario, self.sessao_id)
            messagebox.showinfo("OK","Registro reativado.", parent=self)
            if self.on_inactivate_callback: self.on_inactivate_callback()
            self.destroy()
        except Exception as ex:
            messagebox.showerror("Erro", str(ex), parent=self)

    # ── Salvar ─────────────────────────────────────────────────────────

    def save(self):
        try:
            emissao  = self._data_emissao.get_iso()  if self._data_emissao  else ""
            validade = self._data_validade.get_iso() if self._data_validade else ""
            cnpj_val = self._cnpj_widget.get()        if self._cnpj_widget  else ""

            model = CND(
                esfera=self._get_value("Esfera"),
                empresa_grupo_informado=self._get_value("Empresa/Grupo"),
                filial_informada=self._get_value("Filial"),
                uf=self._get_value("UF"),
                local_informado=self._get_value("Local"),
                cnpj_informado=cnpj_val,
                inscricao_estadual=self._get_value("Inscrição Estadual"),
                inscricao_municipal=self._get_value("Inscrição Municipal"),
                orgao_emissor_informado=self._get_value("Órgão Emissor"),
                criticidade_informada=self._get_value("Criticidade"),
                status_cnd_informado=self._get_value("Status CND"),
                numero_certidao=self._get_value("Número da Certidão"),
                prazo_vencimento_texto=self._get_value("Prazo Vencimento"),
                mapeamento=self._get_value("Mapeamento"),
                informacoes_filial=self._get_value("Informações Filial"),
                responsavel_informado=self._get_value("Responsável"),
                analista_filial_informado=self._get_value("Analista Filial"),
                comunicacao_resumo=", ".join(self._comunicacao_filiais),
                obs_estracta=self._get_value("OBS eStracta"),
                status_processo_informado=self._get_value("Status"),
                obs_status=self._get_value("OBS Status"),
                obs_filial=self._get_value("OBS Filial"),
                observacoes=self._get_value("Observações"),
                data_emissao=emissao,
                data_validade=validade,
                caminho_pdf=self.pdf.get(),
                id=self.cnd_id,
                versao_registro=(self.original_data or {}).get("versao_registro",1),
            )

            if self.cnd_id:
                self.cnd_service.update_cnd(self.cnd_id, model, self.usuario, self.sessao_id)
                self.cnd_service.save_comunicacoes(
                    self.cnd_id, self._comunicacao_filiais, self.usuario, self.sessao_id)
                self.original_data = self.cnd_service.get_cnd_by_id(self.cnd_id)
                self._render_fields()
                self._load_data()
                messagebox.showinfo("Sucesso","CND atualizada.", parent=self)
            else:
                new_id = self.cnd_service.create_cnd(model, self.usuario, self.sessao_id)
                if self._comunicacao_filiais:
                    self.cnd_service.save_comunicacoes(
                        new_id, self._comunicacao_filiais, self.usuario, self.sessao_id)
                messagebox.showinfo("Sucesso","CND salva.", parent=self)
                self.destroy()
        except Exception as ex:
            messagebox.showerror("Erro", str(ex), parent=self)
