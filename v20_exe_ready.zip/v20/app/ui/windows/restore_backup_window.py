"""Restaurar Backup — exclusivo para ADMIN."""
import shutil, sqlite3
import customtkinter as ctk
from tkinter import ttk, messagebox
from pathlib import Path


class RestoreBackupWindow(ctk.CTkToplevel):
    def __init__(self, master, backup_service, main_db_path, catalog_db_path,
                 integrity_path, user, version, hmac_secret, on_restore=None):
        super().__init__(master)
        self.backup_service  = backup_service
        self.main_db         = main_db_path
        self.catalog_db      = catalog_db_path
        self.integrity_path  = integrity_path
        self.user            = user
        self.version         = version
        self.hmac_secret     = hmac_secret
        self.on_restore      = on_restore
        self.restored        = False

        self.title("CND Manager — Restaurar Backup")
        self.geometry("680x400")
        self.minsize(560, 340)
        self.grab_set()
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"680x400+{(sw-680)//2}+{(sh-400)//2}")
        self._build_ui()
        self._load()

    def _build_ui(self):
        hdr = ctk.CTkFrame(self, fg_color="#2a1a4a", corner_radius=0)
        hdr.pack(fill="x")
        ctk.CTkLabel(hdr, text="Restaurar Backup",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color="white").pack(pady=10)
        ctk.CTkLabel(self,
                     text="Selecione o backup. Os dados atuais serão completamente substituídos.\n"
                          "Reinicie a aplicação após restaurar.",
                     font=ctk.CTkFont(size=11), text_color="gray",
                     wraplength=620, justify="center").pack(pady=(8,4))

        tf = ctk.CTkFrame(self)
        tf.pack(fill="both", expand=True, padx=16, pady=4)
        self._tree = ttk.Treeview(tf, columns=("dt","kb","cat"), show="headings", height=8)
        for cid, hd, w in [("dt","Data / Hora",200),("kb","Tamanho (KB)",120),("cat","Catálogo?",120)]:
            self._tree.heading(cid, text=hd)
            self._tree.column(cid, width=w, anchor="center")
        vsb = ttk.Scrollbar(tf, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self._tree.pack(fill="both", expand=True)

        bf = ctk.CTkFrame(self, fg_color="transparent")
        bf.pack(fill="x", padx=16, pady=(4,12))
        ctk.CTkButton(bf, text="Restaurar selecionado", width=180,
                      fg_color="#2a1a4a", command=self._restore).pack(side="left", padx=(0,8))
        ctk.CTkButton(bf, text="Cancelar", width=100,
                      fg_color="gray30", command=self.destroy).pack(side="right")

    def _load(self):
        for i in self._tree.get_children(): self._tree.delete(i)
        bkps = self.backup_service.list_backups()
        if not bkps:
            self._tree.insert("","end", values=("Nenhum backup disponível","",""))
            return
        for b in bkps:
            self._tree.insert("","end", iid=b["timestamp"], values=(
                b["data_hora"], b["tamanho_kb"], "Sim" if b["cat_existe"] else "Não"))

    def _restore(self):
        sel = self._tree.selection()
        if not sel:
            messagebox.showwarning("Seleção","Selecione um backup.", parent=self); return
        ts = sel[0]
        b  = next((x for x in self.backup_service.list_backups() if x["timestamp"]==ts), None)
        if not b:
            messagebox.showerror("Erro","Backup não encontrado.", parent=self); return

        if not messagebox.askyesno("Confirmar restauração",
            f"Restaurar backup de {b['data_hora']}?\n\n"
            "ATENÇÃO: os dados atuais serão COMPLETAMENTE substituídos.\n"
            "Esta ação não pode ser desfeita.", parent=self): return

        try:
            # Salvar backup dos dados atuais antes de sobrescrever
            self.backup_service.run()

            shutil.copy2(b["main"], self.main_db)
            if b["cat_existe"]:
                shutil.copy2(b["catalog"], self.catalog_db)

            # Checkpoint e manifesto
            for p in (self.main_db, self.catalog_db):
                try:
                    c = sqlite3.connect(p)
                    c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                    c.close()
                except Exception:
                    pass

            from app.security.integrity import build_manifest, save_manifest
            m = build_manifest(self.main_db, self.catalog_db,
                               self.user["id"], self.user["login"],
                               self.version, self.hmac_secret)
            save_manifest(self.integrity_path, m)

            self.restored = True
            messagebox.showinfo("Concluído",
                f"Backup de {b['data_hora']} restaurado.\n\n"
                "Feche e reabra a aplicação para carregar os dados.", parent=self)
            if self.on_restore: self.on_restore()
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Erro", str(exc), parent=self)
