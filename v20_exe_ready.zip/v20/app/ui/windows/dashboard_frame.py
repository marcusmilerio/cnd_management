"""
Dashboard configurável V17.

- 5 painéis fixos (sempre presentes, sem botão fechar)
- Botão [+] no lugar do 6º painel — adiciona novo painel, abre configuração
- Painéis extras têm botão [×] para fechar; ao fechar, demais se reorganizam
- Máximo 20 painéis no total
- Configurações persistidas em data/dashboard_config.json
- Botão ⚙ com fundo grafite para visibilidade
"""
import json, os
from app.core.path_utils import get_data_dir
import customtkinter as ctk
from tkinter import ttk
from collections import Counter, defaultdict

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.ticker as mticker
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

_PAL = ["#4e9af1","#f0a500","#e05c5c","#5cc85c","#9b5ce0",
        "#f06292","#4db6ac","#ffb74d","#a1887f","#78909c",
        "#80cbc4","#ce93d8","#ef9a9a","#ffe082","#b0bec5"]

_NUM_FIXED = 5
_MAX_PANELS = 20

_DIMS = [
    ("Esfera",               "esfera"),
    ("Empresa/Grupo",        "empresa_grupo_informado"),
    ("Filial",               "filial_informada"),
    ("UF",                   "uf"),
    ("Local",                "local_informado"),
    ("CNPJ",                 "cnpj_informado"),
    ("Órgão Emissor",        "orgao_emissor_informado"),
    ("Status CND",           "status_cnd_informado"),
    ("Criticidade",          "criticidade_informada"),
    ("Status Processo",      "status_processo_informado"),
    ("Responsável",          "responsavel_informado"),
    ("Analista Filial",      "analista_filial_informado"),
    ("Tem PDF?",             "__tem_pdf"),
    ("Tem Comunicação?",     "__tem_comunicacao"),
    ("Faixa de Vencimento",  "__faixa_vencimento"),
    ("Mês Vencimento",       "mes_validade"),
    ("Ano Vencimento",       "ano_validade"),
    ("Mês Emissão",          "mes_emissao"),
    ("Ano Emissão",          "ano_emissao"),
]
_DIM_LABELS = [d[0] for d in _DIMS]
_DIM_KEY    = {d[0]: d[1] for d in _DIMS}

_METS = [
    ("Quantidade total",       "__count"),
    ("Qtd. vencidas",          "__vencidas"),
    ("Qtd. vence ≤ 15d",       "__urgente15"),
    ("Qtd. vence 16-30d",      "__atencao30"),
    ("Qtd. OK (> 30d)",        "__ok"),
    ("Qtd. sem data validade", "__sem_data"),
    ("Qtd. com PDF",           "__com_pdf"),
    ("Qtd. com comunicação",   "__com_comm"),
    ("Dias médios p/ vencer",  "__dias_medio"),
    ("Dias mínimo",            "__dias_min"),
    ("Dias máximo",            "__dias_max"),
    ("% do total",             "__pct_total"),
]
_MET_LABELS = [m[0] for m in _METS]
_MET_KEY    = {m[0]: m[1] for m in _METS}

_CHART_METRICA  = ["Barra vertical","Barra horizontal","Pizza","Linha","Tabela simples"]
_CHART_DIMENSAO = ["Barra empilhada","Barra agrupada","Tabela cruzada"]

_F_ESFERAS  = ["Todas","Federal","Estadual","Municipal"]
_F_EMPRESAS = ["Todas","Bayer S.A.","D&PL","Monsanto"]
_F_CRITS    = ["Todas","Baixa","Média","Alta","Altíssima"]
_F_STATUS   = ["Todos","Negativa","Positiva","Positiva com efeito de Negativa"]


# ══════════════════════════════════════════════════════════════════════════════
#  Motor de dados
# ══════════════════════════════════════════════════════════════════════════════

def _dim_val(row, key):
    if key == "__tem_pdf":
        return "Com PDF" if row.get("caminho_pdf") else "Sem PDF"
    if key == "__tem_comunicacao":
        return "Com Comunicação" if (row.get("comunicacao_resumo") or "").strip() else "Sem Comunicação"
    if key == "__faixa_vencimento":
        d = row.get("dias_para_vencer")
        if d is None: return "Sem data"
        d = int(d)
        if d < 0:    return "Vencida"
        if d <= 15:  return "≤ 15 dias"
        if d <= 30:  return "≤ 30 dias"
        return "OK (> 30d)"
    return str(row.get(key) or "—").strip()


def _metric_val(rows, key, total_geral=0):
    if not rows: return 0
    if key == "__count":      return len(rows)
    if key == "__vencidas":   return sum(1 for r in rows if (r.get("dias_para_vencer") is not None and int(r["dias_para_vencer"]) < 0))
    if key == "__urgente15":  return sum(1 for r in rows if (r.get("dias_para_vencer") is not None and 0 <= int(r["dias_para_vencer"]) <= 15))
    if key == "__atencao30":  return sum(1 for r in rows if (r.get("dias_para_vencer") is not None and 16 <= int(r["dias_para_vencer"]) <= 30))
    if key == "__ok":         return sum(1 for r in rows if (r.get("dias_para_vencer") is not None and int(r["dias_para_vencer"]) > 30))
    if key == "__sem_data":   return sum(1 for r in rows if r.get("dias_para_vencer") is None)
    if key == "__com_pdf":    return sum(1 for r in rows if r.get("caminho_pdf"))
    if key == "__com_comm":   return sum(1 for r in rows if (r.get("comunicacao_resumo") or "").strip())
    if key == "__pct_total":  return round(len(rows)/total_geral*100,1) if total_geral else 0
    dias = [int(r["dias_para_vencer"]) for r in rows if r.get("dias_para_vencer") is not None]
    if not dias: return 0
    if key == "__dias_medio": return round(sum(dias)/len(dias),1)
    if key == "__dias_min":   return min(dias)
    if key == "__dias_max":   return max(dias)
    return 0


def _apply_filters(rows, cfg):
    r = rows
    if cfg.get("f_esf","Todas") not in ("Todas",""):   r = [x for x in r if x.get("esfera") == cfg["f_esf"]]
    if cfg.get("f_emp","Todas") not in ("Todas",""):   r = [x for x in r if x.get("empresa_grupo_informado") == cfg["f_emp"]]
    if cfg.get("f_uf","Todas")  not in ("Todas",""):   r = [x for x in r if (x.get("uf") or "").upper() == cfg["f_uf"].upper()]
    if cfg.get("f_crit","Todas") not in ("Todas",""):  r = [x for x in r if x.get("criticidade_informada") == cfg["f_crit"]]
    if cfg.get("f_status","Todos") not in ("Todos",""): r = [x for x in r if x.get("status_cnd_informado") == cfg["f_status"]]
    return r


def _sort_labels(labels, dim_key):
    if dim_key in ("mes_validade","mes_emissao","ano_validade","ano_emissao"):
        return sorted(l for l in labels if l != "—") + (["—"] if "—" in labels else [])
    if dim_key == "__faixa_vencimento":
        ordem = ["Vencida","≤ 15 dias","≤ 30 dias","OK (> 30d)","Sem data"]
        return [l for l in ordem if l in labels]
    crits = ["Baixa","Média","Alta","Altíssima"]
    if all(l in crits or l == "—" for l in labels):
        return [l for l in crits if l in labels] + (["—"] if "—" in labels else [])
    return labels


def _build_series_metrica(rows, x_key, met_key, top_n=15):
    groups = defaultdict(list)
    for row in rows: groups[_dim_val(row,x_key)].append(row)
    total = len(rows)
    series = {k: _metric_val(v,met_key,total) for k,v in groups.items()}
    labels = _sort_labels(list(series.keys()), x_key)
    if len(labels) > top_n:
        by_val = sorted(series, key=lambda k: series[k], reverse=True)[:top_n]
        labels = [l for l in labels if l in by_val]
    return labels, [series[l] for l in labels]


def _build_series_dimensao(rows, x_key, y_key, top_x=12, top_y=8):
    groups  = defaultdict(lambda: defaultdict(int))
    y_counts= Counter()
    for row in rows:
        xv = _dim_val(row,x_key); yv = _dim_val(row,y_key)
        groups[xv][yv] += 1; y_counts[yv] += 1
    x_totals = {x: sum(groups[x].values()) for x in groups}
    x_labels = _sort_labels(list(groups.keys()), x_key)
    if len(x_labels) > top_x:
        top_x_set = set(sorted(x_totals, key=x_totals.get, reverse=True)[:top_x])
        x_labels = [l for l in x_labels if l in top_x_set]
    y_labels = _sort_labels(list(y_counts.keys()), y_key)
    if len(y_labels) > top_y:
        y_labels = [l for l, _ in y_counts.most_common(top_y)]
    matrix = {x: {y: groups[x].get(y,0) for y in y_labels} for x in x_labels}
    return x_labels, y_labels, matrix


# ══════════════════════════════════════════════════════════════════════════════
#  Janela de configuração
# ══════════════════════════════════════════════════════════════════════════════

class PanelConfigWindow(ctk.CTkToplevel):

    def __init__(self, master, panel_idx, current_cfg, uf_values, on_save, on_cancel=None):
        super().__init__(master)
        self.panel_idx = panel_idx
        self.cfg       = dict(current_cfg)
        self.on_save   = on_save
        self.on_cancel = on_cancel
        self._saved    = False

        self.title(f"Configurar Painel {panel_idx + 1}")
        self.geometry("540x580")
        self.resizable(False, False)
        self.grab_set()
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"540x580+{(sw-540)//2}+{(sh-580)//2}")
        self._uf_vals = ["Todas"] + uf_values
        self._build()
        # Ao fechar pelo X sem salvar → cancel
        self.protocol("WM_DELETE_WINDOW", self._cancel)

    def _build(self):
        ctk.CTkLabel(self, text=f"Painel {self.panel_idx+1} — Configuração",
                     font=ctk.CTkFont(size=14, weight="bold")).pack(pady=(14,8))

        eixos = ctk.CTkFrame(self, fg_color="transparent")
        eixos.pack(fill="x", padx=28, pady=(0,4))
        eixos.grid_columnconfigure(1, weight=1)

        def lrow(r, lbl, widget):
            ctk.CTkLabel(eixos, text=lbl, anchor="w", width=130).grid(
                row=r, column=0, sticky="w", pady=5)
            widget.grid(row=r, column=1, sticky="ew", padx=(8,0), pady=5)
            return widget

        self._x_var = ctk.StringVar(value=self.cfg.get("x_dim",_DIM_LABELS[0]))
        lrow(0,"Eixo X (dimensão):",
             ctk.CTkComboBox(eixos, values=_DIM_LABELS, variable=self._x_var, width=300))

        self._y_mode = ctk.StringVar(value=self.cfg.get("y_mode","metrica"))
        mf = ctk.CTkFrame(eixos, fg_color="transparent")
        mf.grid(row=1, column=0, columnspan=2, sticky="w", pady=(8,2))
        ctk.CTkLabel(mf, text="Eixo Y:  ", anchor="w", width=130).pack(side="left")
        ctk.CTkRadioButton(mf, text="Métrica (valor calculado)",
                           variable=self._y_mode, value="metrica",
                           command=self._on_mode).pack(side="left", padx=(0,20))
        ctk.CTkRadioButton(mf, text="Dimensão (cruzamento)",
                           variable=self._y_mode, value="dimensao",
                           command=self._on_mode).pack(side="left")

        self._y_met_var = ctk.StringVar(value=self.cfg.get("y_met",_MET_LABELS[0]))
        self._y_met_cb  = lrow(2,"  Métrica:",
             ctk.CTkComboBox(eixos, values=_MET_LABELS, variable=self._y_met_var, width=300))

        self._y_dim_var = ctk.StringVar(value=self.cfg.get("y_dim",_DIM_LABELS[1]))
        self._y_dim_cb  = lrow(3,"  Segunda dimensão:",
             ctk.CTkComboBox(eixos, values=_DIM_LABELS, variable=self._y_dim_var, width=300))

        self._chart_var = ctk.StringVar(value=self.cfg.get("chart","Barra vertical"))
        self._chart_cb  = lrow(4,"Tipo de gráfico:",
             ctk.CTkComboBox(eixos, values=_CHART_METRICA, variable=self._chart_var, width=300))

        ctk.CTkLabel(eixos, text="── Filtros opcionais ──",
                     font=ctk.CTkFont(size=10), text_color="gray").grid(
                     row=5, column=0, columnspan=2, pady=(10,4))

        self._f_esf  = ctk.StringVar(value=self.cfg.get("f_esf","Todas"))
        self._f_emp  = ctk.StringVar(value=self.cfg.get("f_emp","Todas"))
        self._f_uf   = ctk.StringVar(value=self.cfg.get("f_uf","Todas"))
        self._f_crit = ctk.StringVar(value=self.cfg.get("f_crit","Todas"))
        self._f_sta  = ctk.StringVar(value=self.cfg.get("f_status","Todos"))

        lrow(6,"Esfera:",       ctk.CTkComboBox(eixos,values=_F_ESFERAS, variable=self._f_esf, width=300))
        lrow(7,"Empresa/Grupo:",ctk.CTkComboBox(eixos,values=_F_EMPRESAS,variable=self._f_emp, width=300))
        lrow(8,"UF:",           ctk.CTkComboBox(eixos,values=self._uf_vals,variable=self._f_uf,width=300))
        lrow(9,"Criticidade:",  ctk.CTkComboBox(eixos,values=_F_CRITS,  variable=self._f_crit,width=300))
        lrow(10,"Status CND:",  ctk.CTkComboBox(eixos,values=_F_STATUS, variable=self._f_sta, width=300))

        bf = ctk.CTkFrame(self, fg_color="transparent")
        bf.pack(fill="x", padx=28, pady=(12,16))
        ctk.CTkButton(bf, text="Salvar e atualizar", width=160, command=self._save).pack(side="left")
        ctk.CTkButton(bf, text="Cancelar", width=100, fg_color="gray30",
                      command=self._cancel).pack(side="right")

        self._on_mode()

    def _on_mode(self):
        mode = self._y_mode.get()
        if mode == "metrica":
            self._y_met_cb.configure(state="normal")
            self._y_dim_cb.configure(state="disabled")
            self._chart_cb.configure(values=_CHART_METRICA)
            if self._chart_var.get() not in _CHART_METRICA:
                self._chart_var.set("Barra vertical")
        else:
            self._y_met_cb.configure(state="disabled")
            self._y_dim_cb.configure(state="normal")
            self._chart_cb.configure(values=_CHART_DIMENSAO)
            if self._chart_var.get() not in _CHART_DIMENSAO:
                self._chart_var.set("Barra empilhada")

    def _save(self):
        self._saved = True
        self.on_save(self.panel_idx, {
            "x_dim":"",   # preenchido abaixo
            "y_mode": self._y_mode.get(),
            "y_met":  self._y_met_var.get(),
            "y_dim":  self._y_dim_var.get(),
            "chart":  self._chart_var.get(),
            "f_esf":  self._f_esf.get(),
            "f_emp":  self._f_emp.get(),
            "f_uf":   self._f_uf.get(),
            "f_crit": self._f_crit.get(),
            "f_status":self._f_sta.get(),
            "x_dim":  self._x_var.get(),
        })
        self.destroy()

    def _cancel(self):
        if not self._saved and self.on_cancel:
            self.on_cancel(self.panel_idx)
        self.destroy()


# ══════════════════════════════════════════════════════════════════════════════
#  Painel individual
# ══════════════════════════════════════════════════════════════════════════════

class DashboardPanel(ctk.CTkFrame):

    def __init__(self, master, idx, cfg, on_config, on_close=None, fixed=True, **kw):
        super().__init__(master, corner_radius=8, **kw)
        self.idx       = idx
        self.cfg       = cfg
        self.on_config = on_config
        self.on_close  = on_close   # None para painéis fixos
        self._fixed    = fixed
        self._figure   = None
        self._build_header()
        self._body = ctk.CTkFrame(self, fg_color="transparent")
        self._body.pack(fill="both", expand=True, padx=4, pady=(0,6))

    def _build_header(self):
        h = ctk.CTkFrame(self, fg_color="transparent")
        h.pack(fill="x", padx=6, pady=(4,0))

        self._title_lbl = ctk.CTkLabel(
            h, text=self._title(), font=ctk.CTkFont(size=10, weight="bold"),
            anchor="w", wraplength=300)
        self._title_lbl.pack(side="left", fill="x", expand=True)

        # Botão fechar [×] — só para painéis extras
        if not self._fixed and self.on_close:
            ctk.CTkButton(
                h, text="×", width=24, height=22,
                font=ctk.CTkFont(size=13),
                fg_color="#7a1a1a", hover_color="#5a1010",
                text_color="white",
                command=lambda: self.on_close(self.idx),
            ).pack(side="right", padx=(2,0))

        # Botão ⚙ — grafite claro visível
        ctk.CTkButton(
            h, text="⚙", width=28, height=22,
            font=ctk.CTkFont(size=13),
            fg_color="#555555", text_color="#dddddd",
            hover_color="#404040",
            command=lambda: self.on_config(self.idx),
        ).pack(side="right")

    def _title(self):
        x    = self.cfg.get("x_dim","?")
        mode = self.cfg.get("y_mode","metrica")
        y    = self.cfg.get("y_met","?") if mode=="metrica" else self.cfg.get("y_dim","?")
        flts = []
        for k,lbl in [("f_esf","Esf"),("f_emp","Emp"),("f_uf","UF"),
                      ("f_crit","Crit"),("f_status","Status")]:
            v = self.cfg.get(k,"")
            if v not in ("Todas","Todos",""): flts.append(f"{lbl}={v}")
        suf = f"  [{', '.join(flts)}]" if flts else ""
        sep = " × " if mode=="dimensao" else " → "
        return f"P{self.idx+1}  {x}{sep}{y}{suf}"

    def update(self, rows):
        for w in self._body.winfo_children(): w.destroy()
        if self._figure:
            try:
                import matplotlib.pyplot as plt; plt.close(self._figure)
            except: pass
            self._figure = None

        self._title_lbl.configure(text=self._title())
        try:
            data  = _apply_filters(rows, self.cfg)
            if not data: self._no_data("Sem dados"); return
            mode  = self.cfg.get("y_mode","metrica")
            chart = self.cfg.get("chart","Barra vertical")
            x_key = _DIM_KEY.get(self.cfg.get("x_dim","Esfera"),"esfera")
            if mode == "metrica":
                met_key = _MET_KEY.get(self.cfg.get("y_met","Quantidade total"),"__count")
                labels, values = _build_series_metrica(data, x_key, met_key)
                if not labels: self._no_data("Sem dados"); return
                if chart == "Tabela simples": self._table_simples(labels, values)
                else:                          self._chart_metrica(labels,values,chart,self.cfg.get("y_met",""))
            else:
                y_key = _DIM_KEY.get(self.cfg.get("y_dim","Criticidade"),"criticidade_informada")
                xl, yl, mat = _build_series_dimensao(data, x_key, y_key)
                if not xl: self._no_data("Sem dados"); return
                if chart == "Tabela cruzada": self._table_cruzada(xl,yl,mat,self.cfg.get("x_dim",""),self.cfg.get("y_dim",""))
                else:                          self._chart_dimensao(xl,yl,mat,chart,self.cfg.get("x_dim",""),self.cfg.get("y_dim",""))
        except Exception as ex:
            self._no_data(f"Erro:\n{ex}")

    def _no_data(self, msg):
        ctk.CTkLabel(self._body, text=msg, text_color="gray", justify="center").pack(expand=True)

    def _chart_metrica(self, labels, values, chart_type, met_label):
        fig = Figure(figsize=(4.0,2.8), dpi=88, tight_layout=True)
        ax  = fig.add_subplot(111)
        colors = [_PAL[i%len(_PAL)] for i in range(len(labels))]
        def fmt(v): return str(int(v)) if isinstance(v,float) and v==int(v) else f"{v:.1f}"

        if chart_type == "Barra vertical":
            bars = ax.bar(labels, values, color=colors, edgecolor="white", lw=0.6)
            ax.bar_label(bars, labels=[fmt(v) for v in values], fontsize=7, padding=2)
            ax.yaxis.set_major_locator(mticker.MaxNLocator(integer=True))
            ticks = [l[:11]+"…" if len(l)>11 else l for l in labels]
            ax.set_xticks(range(len(labels)))
            ax.set_xticklabels(ticks, rotation=30 if len(labels)>4 else 0,
                               ha="right" if len(labels)>4 else "center", fontsize=7)
        elif chart_type == "Barra horizontal":
            rev_l=list(reversed(labels)); rev_v=list(reversed(values))
            short=[l[:20]+"…" if len(l)>20 else l for l in rev_l]
            bars=ax.barh(short,rev_v,color=list(reversed(colors)),edgecolor="white",lw=0.6)
            ax.bar_label(bars,labels=[fmt(v) for v in rev_v],fontsize=7,padding=3)
            ax.xaxis.set_major_locator(mticker.MaxNLocator(integer=True))
            ax.tick_params(axis="y",labelsize=7)
        elif chart_type == "Pizza":
            if len(labels)>9:
                tl,tv=labels[:8],values[:8]; outros=sum(values[8:])
                tl.append("Outros"); tv.append(outros); colors=_PAL[:9]
            else: tl,tv=labels,values
            wedges,texts,autos=ax.pie(tv,labels=tl,autopct="%1.0f%%",colors=colors,
                startangle=90,pctdistance=0.75,wedgeprops={"linewidth":1,"edgecolor":"white"})
            for t in texts: t.set_fontsize(7)
            for a in autos: a.set_fontsize(7)
        elif chart_type == "Linha":
            xp=range(len(labels))
            ax.plot(xp,values,marker="o",color=_PAL[0],lw=1.5,ms=4)
            ax.fill_between(xp,values,alpha=0.12,color=_PAL[0])
            ax.set_xticks(xp)
            ax.set_xticklabels([l[:8] for l in labels],rotation=30,ha="right",fontsize=7)
            ax.yaxis.set_major_locator(mticker.MaxNLocator(integer=True))

        ax.set_title(met_label,fontsize=9,pad=4)
        ax.tick_params(labelsize=8)
        for sp in ax.spines.values(): sp.set_linewidth(0.5)
        self._embed(fig)

    def _chart_dimensao(self, x_labels, y_labels, matrix, chart_type, x_name, y_name):
        fig=Figure(figsize=(4.0,2.8),dpi=88,tight_layout=True)
        ax=fig.add_subplot(111)
        n_x=len(x_labels); n_y=len(y_labels)
        pal=[_PAL[i%len(_PAL)] for i in range(n_y)]
        x_pos=range(n_x)
        short_x=[l[:10]+"…" if len(l)>10 else l for l in x_labels]

        if chart_type=="Barra empilhada":
            bottoms=[0.0]*n_x
            for yi,y_lbl in enumerate(y_labels):
                vals=[matrix[xl].get(y_lbl,0) for xl in x_labels]
                ax.bar(x_pos,vals,bottom=bottoms,label=y_lbl,color=pal[yi],edgecolor="white",lw=0.5)
                bottoms=[b+v for b,v in zip(bottoms,vals)]
            ax.set_xticks(x_pos)
            ax.set_xticklabels(short_x,rotation=30 if n_x>4 else 0,
                               ha="right" if n_x>4 else "center",fontsize=7)
            ax.yaxis.set_major_locator(mticker.MaxNLocator(integer=True))
            ax.legend(fontsize=6,loc="upper right",bbox_to_anchor=(1.02,1),borderaxespad=0)
        elif chart_type=="Barra agrupada":
            width=0.8/max(n_y,1)
            for yi,y_lbl in enumerate(y_labels):
                offs=[xi+(yi-n_y/2+0.5)*width for xi in x_pos]
                vals=[matrix[xl].get(y_lbl,0) for xl in x_labels]
                ax.bar(offs,vals,width=width*0.9,label=y_lbl,color=pal[yi],edgecolor="white",lw=0.4)
            ax.set_xticks(list(x_pos))
            ax.set_xticklabels(short_x,rotation=30 if n_x>4 else 0,
                               ha="right" if n_x>4 else "center",fontsize=7)
            ax.yaxis.set_major_locator(mticker.MaxNLocator(integer=True))
            ax.legend(fontsize=6,loc="upper right",bbox_to_anchor=(1.02,1),borderaxespad=0)

        ax.set_title(f"{x_name} × {y_name}",fontsize=9,pad=4)
        ax.tick_params(labelsize=8)
        for sp in ax.spines.values(): sp.set_linewidth(0.5)
        self._embed(fig)

    def _table_simples(self, labels, values):
        met=self.cfg.get("y_met","Valor")
        tree=ttk.Treeview(self._body,columns=("dim","val"),show="headings",height=8)
        tree.heading("dim",text=self.cfg.get("x_dim","Dimensão"))
        tree.heading("val",text=met)
        tree.column("dim",width=180,anchor="w"); tree.column("val",width=80,anchor="center")
        for l,v in zip(labels,values):
            disp=str(int(v)) if isinstance(v,float) and v==int(v) else str(v)
            tree.insert("","end",values=(l,disp))
        sb=ttk.Scrollbar(self._body,orient="vertical",command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right",fill="y"); tree.pack(fill="both",expand=True)

    def _table_cruzada(self, x_labels, y_labels, matrix, x_name, y_name):
        cols=("x_dim",)+tuple(range(len(y_labels)))+("total",)
        tree=ttk.Treeview(self._body,columns=cols,show="headings",height=min(len(x_labels)+2,8))
        tree.heading("x_dim",text=x_name); tree.column("x_dim",width=110,anchor="w",minwidth=60)
        for yi,y_lbl in enumerate(y_labels):
            sh=y_lbl[:9]+"…" if len(y_lbl)>9 else y_lbl
            tree.heading(yi,text=sh); tree.column(yi,width=max(50,len(sh)*7),anchor="center",minwidth=40)
        tree.heading("total",text="Total"); tree.column("total",width=50,anchor="center",minwidth=40)
        col_tot={y:0 for y in y_labels}
        for x_lbl in x_labels:
            rv=[matrix[x_lbl].get(y,0) for y in y_labels]
            total=sum(rv)
            for y,v in zip(y_labels,rv): col_tot[y]+=v
            tree.insert("","end",values=(x_lbl,)+tuple(rv)+(total,))
        gt=sum(col_tot.values())
        tree.insert("","end",values=("TOTAL",)+tuple(col_tot[y] for y in y_labels)+(gt,),tags=("tot",))
        tree.tag_configure("tot",font=("Segoe UI",9,"bold"))
        sb=ttk.Scrollbar(self._body,orient="vertical",command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        hsb=ttk.Scrollbar(self._body,orient="horizontal",command=tree.xview)
        tree.configure(xscrollcommand=hsb.set)
        sb.pack(side="right",fill="y"); hsb.pack(side="bottom",fill="x")
        tree.pack(fill="both",expand=True)

    def _embed(self, fig):
        self._figure=fig
        canvas=FigureCanvasTkAgg(fig,master=self._body)
        canvas.draw(); canvas.get_tk_widget().pack(fill="both",expand=True)

    def reconfigure(self, cfg): self.cfg=cfg


# ══════════════════════════════════════════════════════════════════════════════
#  Botão [+]
# ══════════════════════════════════════════════════════════════════════════════

class AddPanelButton(ctk.CTkFrame):
    def __init__(self, master, on_click, **kw):
        super().__init__(master, corner_radius=8, **kw)
        ctk.CTkButton(
            self, text="＋\nAdicionar Painel",
            font=ctk.CTkFont(size=18),
            fg_color="transparent", hover_color="gray25",
            text_color="gray60",
            command=on_click,
            height=120,
        ).pack(fill="both", expand=True, padx=8, pady=8)


# ══════════════════════════════════════════════════════════════════════════════
#  Configurações padrão
# ══════════════════════════════════════════════════════════════════════════════

def _default_config(i):
    defaults = [
        {"x_dim":"Esfera",           "y_mode":"metrica",  "y_met":"Quantidade total",    "y_dim":"Criticidade",    "chart":"Pizza",           "f_esf":"Todas","f_emp":"Todas","f_uf":"Todas","f_crit":"Todas","f_status":"Todos"},
        {"x_dim":"Empresa/Grupo",    "y_mode":"metrica",  "y_met":"Quantidade total",    "y_dim":"Esfera",         "chart":"Barra vertical",  "f_esf":"Todas","f_emp":"Todas","f_uf":"Todas","f_crit":"Todas","f_status":"Todos"},
        {"x_dim":"Faixa de Vencimento","y_mode":"metrica","y_met":"Quantidade total",    "y_dim":"Esfera",         "chart":"Barra vertical",  "f_esf":"Todas","f_emp":"Todas","f_uf":"Todas","f_crit":"Todas","f_status":"Todos"},
        {"x_dim":"Esfera",           "y_mode":"dimensao", "y_met":"Quantidade total",    "y_dim":"Criticidade",    "chart":"Barra empilhada", "f_esf":"Todas","f_emp":"Todas","f_uf":"Todas","f_crit":"Todas","f_status":"Todos"},
        {"x_dim":"Mês Vencimento",   "y_mode":"metrica",  "y_met":"Quantidade total",    "y_dim":"Esfera",         "chart":"Linha",           "f_esf":"Todas","f_emp":"Todas","f_uf":"Todas","f_crit":"Todas","f_status":"Todos"},
    ]
    return defaults[i] if i < len(defaults) else defaults[0].copy()


# ══════════════════════════════════════════════════════════════════════════════
#  DashboardFrame principal
# ══════════════════════════════════════════════════════════════════════════════

class DashboardFrame(ctk.CTkFrame):

    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self._raw_rows  = []
        self._uf_vals   = []
        # configs: lista de dicts, índice = posição lógica
        self._configs   = [_default_config(i) for i in range(_NUM_FIXED)]
        self._panels    = []   # lista de DashboardPanel (ordem exibe)
        self._add_btn   = None
        self._load_configs()
        self._build()

    # ── Persistência ──────────────────────────────────────────────────────────

    def _config_path(self):
        base = get_data_dir()
        base.mkdir(parents=True, exist_ok=True)
        return str(base / "dashboard_config.json")

    def _load_configs(self):
        try:
            with open(self._config_path(), encoding="utf-8") as f:
                saved = json.load(f)
            self._configs = []
            for cfg in saved:
                if "y_mode" not in cfg:
                    cfg["y_mode"] = "metrica"
                    cfg.setdefault("y_dim", _DIM_LABELS[1])
                    cfg["x_dim"] = cfg.pop("dim", cfg.get("x_dim", _DIM_LABELS[0]))
                    cfg["y_met"] = cfg.pop("met", cfg.get("y_met", _MET_LABELS[0]))
                self._configs.append(cfg)
            # Garantir mínimo de _NUM_FIXED
            while len(self._configs) < _NUM_FIXED:
                self._configs.append(_default_config(len(self._configs)))
        except Exception:
            pass

    def _save_configs(self):
        try:
            with open(self._config_path(), "w", encoding="utf-8") as f:
                json.dump(self._configs, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    # ── Construção ────────────────────────────────────────────────────────────

    def _build(self):
        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=12, pady=(6,4))
        ctk.CTkLabel(top, text="Dashboard Configurável",
                     font=ctk.CTkFont(size=13, weight="bold")).pack(side="left")
        ctk.CTkLabel(top,
            text="Clique em ⚙ para configurar cada painel. Use [＋] para adicionar (máx. 20).",
            font=ctk.CTkFont(size=10), text_color="gray").pack(side="left", padx=10)

        self._scroll = ctk.CTkScrollableFrame(self)
        self._scroll.pack(fill="both", expand=True, padx=6, pady=(0,6))
        self._scroll.grid_columnconfigure(0, weight=1, uniform="p")
        self._scroll.grid_columnconfigure(1, weight=1, uniform="p")

        self._rebuild_grid()

    def _rebuild_grid(self):
        """Reconstrói a grade completa a partir de self._configs."""
        # Destruir tudo
        for w in self._scroll.winfo_children(): w.destroy()
        self._panels.clear()
        self._add_btn = None

        n = len(self._configs)
        for i, cfg in enumerate(self._configs):
            fixed = (i < _NUM_FIXED)
            p = DashboardPanel(
                self._scroll, idx=i, cfg=cfg,
                on_config=self._open_config,
                on_close=None if fixed else self._close_panel,
                fixed=fixed,
            )
            r, c = divmod(i, 2)
            p.grid(row=r, column=c, sticky="nsew", padx=6, pady=6, ipady=4)
            self._panels.append(p)

        # Botão [+] — só se não atingiu o máximo
        if n < _MAX_PANELS:
            r, c = divmod(n, 2)
            self._add_btn = AddPanelButton(self._scroll, on_click=self._add_panel)
            self._add_btn.grid(row=r, column=c, sticky="nsew", padx=6, pady=6, ipady=4)

    # ── API pública ───────────────────────────────────────────────────────────

    def update(self, rows):
        self._raw_rows = rows
        self._uf_vals  = sorted({(r.get("uf") or "").upper()
                                  for r in rows if r.get("uf")})
        for p in self._panels:
            p.update(rows)

    # ── Configuração ──────────────────────────────────────────────────────────

    def _open_config(self, idx):
        win = PanelConfigWindow(
            self, idx, self._configs[idx],
            uf_values=self._uf_vals,
            on_save=self._on_saved,
        )
        self.wait_window(win)

    def _on_saved(self, idx, cfg):
        self._configs[idx] = cfg
        self._panels[idx].reconfigure(cfg)
        self._panels[idx].update(self._raw_rows)
        self._save_configs()

    # ── Adicionar painel ──────────────────────────────────────────────────────

    def _add_panel(self):
        if len(self._configs) >= _MAX_PANELS: return
        new_idx = len(self._configs)
        # Criar config temporária
        temp_cfg = _default_config(0).copy()
        self._configs.append(temp_cfg)
        self._save_configs()

        # Abrir configuração — se cancelar, remove o painel
        win = PanelConfigWindow(
            self, new_idx, temp_cfg,
            uf_values=self._uf_vals,
            on_save=self._on_new_saved,
            on_cancel=self._on_new_cancelled,
        )
        self.wait_window(win)

    def _on_new_saved(self, idx, cfg):
        self._configs[idx] = cfg
        self._save_configs()
        self._rebuild_grid()
        for p in self._panels:
            p.update(self._raw_rows)

    def _on_new_cancelled(self, idx):
        # Remover config temporária
        if idx < len(self._configs):
            self._configs.pop(idx)
        self._save_configs()
        # Não precisa rebuild pois o painel ainda não foi adicionado visualmente

    # ── Fechar painel extra ───────────────────────────────────────────────────

    def _close_panel(self, idx):
        if idx < _NUM_FIXED: return   # nunca fechar fixos
        self._configs.pop(idx)
        self._save_configs()
        self._rebuild_grid()
        for p in self._panels:
            p.update(self._raw_rows)
