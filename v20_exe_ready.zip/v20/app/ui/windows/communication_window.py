"""
Janela de Comunicação — filiais impactadas por esta CND.
Sem ttk.Notebook — layout direto para evitar problema de texto sumindo.
"""
import customtkinter as ctk
from tkinter import messagebox, ttk
from app.core.normalizers import normalize_whitespace


class CommunicationWindow(ctk.CTkToplevel):
    """
    Gerencia quais filiais são impactadas por pendências desta CND.

    Após fechar:
        confirmed (bool)   — True se salvou
        result (list[str]) — lista final de filiais impactadas
    """

    def __init__(self, master, filiais_atuais=None, filial_ref="", catalog_filiais=None):
        super().__init__(master)

        self.confirmed = False
        self.result: list[str] = []
        self._filial_ref = normalize_whitespace(filial_ref)
        self._catalog = catalog_filiais or []
        self._items: list[str] = list(filiais_atuais or [])

        self.title("Comunicação — Filiais Impactadas")
        self.geometry("520x460")
        self.minsize(460, 380)
        self.resizable(True, True)
        self.grab_set()

        self.update_idletasks()
        try:
            mx = master.winfo_rootx() + master.winfo_width() // 2
            my = master.winfo_rooty() + master.winfo_height() // 2
            self.geometry(f"+{mx - 260}+{my - 230}")
        except Exception:
            pass

        self._build_ui()
        self._refresh_list()

    def _build_ui(self):
        # Cabeçalho
        hdr = ctk.CTkFrame(self, fg_color="transparent")
        hdr.pack(fill="x", padx=16, pady=(14, 0))

        ctk.CTkLabel(hdr, text="Filiais Impactadas",
                     font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w")

        desc = "Registre quais outras filiais têm a emissão de CND impactada por pendências desta CND."
        if self._filial_ref:
            desc += f"\n  Filial desta CND: {self._filial_ref}"
        ctk.CTkLabel(hdr, text=desc, font=ctk.CTkFont(size=11),
                     text_color="gray", justify="left", wraplength=480).pack(anchor="w", pady=(4, 0))

        # Área de adição
        add_frame = ctk.CTkFrame(self, fg_color="transparent")
        add_frame.pack(fill="x", padx=16, pady=(12, 4))

        self._entry_var = ctk.StringVar()
        self._combo = ctk.CTkComboBox(add_frame, values=self._catalog,
                                      variable=self._entry_var, width=300)
        self._combo.pack(side="left", padx=(0, 8))
        self._combo.set("")

        ctk.CTkButton(add_frame, text="Adicionar", width=100,
                      command=self._add_item).pack(side="left")

        # Lista de filiais já adicionadas
        list_frame = ctk.CTkFrame(self)
        list_frame.pack(fill="both", expand=True, padx=16, pady=4)

        self._tree = ttk.Treeview(list_frame, columns=("filial",), show="headings", height=10)
        self._tree.heading("filial", text="Filial impactada")
        self._tree.column("filial", width=460, anchor="w")

        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self._tree.pack(fill="both", expand=True)

        # Botões de remoção
        rem_frame = ctk.CTkFrame(self, fg_color="transparent")
        rem_frame.pack(fill="x", padx=16, pady=(4, 0))

        ctk.CTkButton(rem_frame, text="Remover selecionada", width=160,
                      fg_color="#3a3a3a", hover_color="#4a4a4a",
                      command=self._remove_selected).pack(side="left")
        ctk.CTkButton(rem_frame, text="Limpar tudo", width=100,
                      fg_color="#3a3a3a", hover_color="#4a4a4a",
                      command=self._clear_all).pack(side="left", padx=8)

        # Botões de ação
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=16, pady=(8, 16))

        ctk.CTkButton(btn_frame, text="Salvar", width=120,
                      command=self._on_save).pack(side="right", padx=(8, 0))
        ctk.CTkButton(btn_frame, text="Fechar sem salvar", width=140,
                      fg_color="#3a3a3a", hover_color="#4a4a4a",
                      command=self.destroy).pack(side="right")

        self._combo.bind("<Return>", lambda _e: self._add_item())

    def _refresh_list(self):
        for row in self._tree.get_children():
            self._tree.delete(row)
        for filial in self._items:
            self._tree.insert("", "end", values=(filial,))

    def _add_item(self):
        val = normalize_whitespace(self._entry_var.get())
        if not val:
            return
        if self._filial_ref and val.upper() == self._filial_ref.upper():
            messagebox.showwarning("Não permitido",
                                   "Não é possível adicionar a própria filial como impactada.",
                                   parent=self)
            return
        if any(v.upper() == val.upper() for v in self._items):
            messagebox.showwarning("Duplicado", f"A filial '{val}' já está na lista.", parent=self)
            return
        self._items.append(val)
        self._refresh_list()
        self._combo.set("")

    def _remove_selected(self):
        for iid in self._tree.selection():
            val = self._tree.item(iid, "values")[0]
            self._items = [v for v in self._items if v != val]
        self._refresh_list()

    def _clear_all(self):
        if self._items and messagebox.askyesno("Confirmar", "Remover todas?", parent=self):
            self._items.clear()
            self._refresh_list()

    def _on_save(self):
        self.confirmed = True
        self.result = list(self._items)
        self.destroy()
