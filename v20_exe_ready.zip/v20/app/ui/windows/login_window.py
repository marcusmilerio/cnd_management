import customtkinter as ctk
from tkinter import messagebox


class LoginWindow(ctk.CTkToplevel):
    def __init__(self, master, user_service):
        super().__init__(master)
        self.user_service = user_service
        self.authenticated_user = None

        self.title("CND Manager — Login")
        self.geometry("380x260")
        self.resizable(False, False)
        self.grab_set()

        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"380x260+{(sw-380)//2}+{(sh-260)//2}")

        self._build_ui()
        self.bind("<Return>", lambda _e: self.do_login())

    def _build_ui(self):
        ctk.CTkLabel(
            self, text="CND Manager",
            font=ctk.CTkFont(size=20, weight="bold"),
        ).pack(pady=(28, 4))
        ctk.CTkLabel(
            self, text="Informe suas credenciais de acesso",
            font=ctk.CTkFont(size=12), text_color="gray",
        ).pack(pady=(0, 16))

        self.login_entry = ctk.CTkEntry(self, placeholder_text="Usuário", width=280)
        self.login_entry.pack(pady=5)
        self.login_entry.focus()

        self.password_entry = ctk.CTkEntry(self, placeholder_text="Senha", show="*", width=280)
        self.password_entry.pack(pady=5)

        ctk.CTkButton(self, text="Entrar", command=self.do_login, width=280).pack(pady=16)

    def do_login(self):
        login = self.login_entry.get().strip()
        senha = self.password_entry.get()
        if not login or not senha:
            messagebox.showwarning("Login", "Preencha usuário e senha.", parent=self)
            return
        try:
            self.authenticated_user = self.user_service.login(login, senha)
            self.grab_release()
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Erro de autenticação", str(exc), parent=self)
            self.password_entry.delete(0, "end")
            self.password_entry.focus()
