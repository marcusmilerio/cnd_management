"""
Janela de espera de lock.

Exibida quando a aplicação já está em uso por outro usuário.
Mostra quem está usando, desde quando, e faz rechecagem automática.
Permite assumir controle se o lock for detectado como órfão.
"""
import customtkinter as ctk
from datetime import datetime


class LockWaitWindow(ctk.CTkToplevel):
    """
    Janela exibida quando o app.lock já está ativo.

    Atributos após fechamento:
        action: "wait"    — usuário optou por continuar aguardando (nunca entra)
                "enter"   — lock foi liberado, pode entrar
                "override"— usuário assumiu controle de lock órfão
                "cancel"  — usuário cancelou (fecha o programa)
    """

    def __init__(
        self,
        master,
        lock_data: dict,
        lock_manager,
        retry_seconds: int = 30,
        stale_seconds: int = 90,
        is_admin: bool = False,
    ):
        super().__init__(master)

        self.lock_data = lock_data
        self.lock_manager = lock_manager
        self.retry_seconds = retry_seconds
        self.stale_seconds = stale_seconds
        self.is_admin = is_admin
        self.action = "cancel"
        self._countdown = retry_seconds
        self._after_id = None

        self.title("CND Manager — Banco em uso")
        self.geometry("480x320")
        self.resizable(False, False)
        self.grab_set()

        # Centralizar
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        self.geometry(f"480x320+{(sw-480)//2}+{(sh-320)//2}")

        self._build_ui()
        self._schedule_recheck()

    # ------------------------------------------------------------------ #

    def _build_ui(self):
        ctk.CTkLabel(
            self,
            text="⚠  Banco de dados em uso",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).pack(pady=(20, 6))

        # Informações do lock
        info = self._format_lock_info()
        self._info_label = ctk.CTkLabel(
            self,
            text=info,
            justify="left",
            font=ctk.CTkFont(size=12),
        )
        self._info_label.pack(padx=24, pady=(0, 12))

        # Contador
        self._counter_label = ctk.CTkLabel(
            self,
            text=f"Verificando novamente em {self._countdown}s...",
            font=ctk.CTkFont(size=11),
            text_color="gray",
        )
        self._counter_label.pack(pady=4)

        # Botões
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(pady=16)

        ctk.CTkButton(
            btn_frame, text="Verificar agora", width=140,
            command=self._manual_retry,
        ).pack(side="left", padx=6)

        self._override_btn = ctk.CTkButton(
            btn_frame, text="Assumir controle", width=140,
            command=self._override,
            fg_color="orange", hover_color="darkorange",
            state="disabled",
        )
        self._override_btn.pack(side="left", padx=6)

        ctk.CTkButton(
            btn_frame, text="Cancelar", width=100,
            command=self._cancel,
            fg_color="transparent", border_width=1,
        ).pack(side="left", padx=6)

        # Nota sobre override
        self._override_note = ctk.CTkLabel(
            self,
            text="",
            font=ctk.CTkFont(size=10),
            text_color="gray",
        )
        self._override_note.pack(padx=24)

        self._update_override_state()

    def _format_lock_info(self) -> str:
        d = self.lock_data
        usuario = d.get("usuario_nome") or d.get("usuario_login") or "Desconhecido"
        maquina = d.get("maquina_nome") or "?"
        aberto = d.get("aberto_em", "")
        heartbeat = d.get("heartbeat_em", "")

        try:
            aberto_fmt = datetime.fromisoformat(aberto).strftime("%d/%m/%Y %H:%M:%S")
        except Exception:
            aberto_fmt = aberto

        try:
            hb_dt = datetime.fromisoformat(heartbeat)
            hb_fmt = hb_dt.strftime("%H:%M:%S")
            segundos = (datetime.now() - hb_dt).total_seconds()
            hb_status = f"{hb_fmt}  ({int(segundos)}s atrás)"
        except Exception:
            hb_status = heartbeat

        return (
            f"Usuário    :  {usuario}\n"
            f"Máquina    :  {maquina}\n"
            f"Aberto em  :  {aberto_fmt}\n"
            f"Heartbeat  :  {hb_status}"
        )

    def _is_stale(self) -> bool:
        return self.lock_manager.is_stale(self.lock_data)

    def _update_override_state(self):
        # Override só disponível para ADMIN e apenas quando lock for órfão
        if self.is_admin and self._is_stale():
            self._override_btn.configure(state="normal")
            self._override_note.configure(
                text="⚠ Heartbeat expirado — possível sessão abandonada",
                text_color="orange",
            )
        elif not self.is_admin and self._is_stale():
            self._override_btn.configure(state="disabled")
            self._override_note.configure(
                text="⚠ Sessão abandonada detectada — contacte o administrador",
                text_color="orange",
            )
        else:
            self._override_btn.configure(state="disabled")
            self._override_note.configure(text="", text_color="gray")

    # ------------------------------------------------------------------ #
    #  Rechecagem                                                          #
    # ------------------------------------------------------------------ #

    def _schedule_recheck(self):
        self._after_id = self.after(1000, self._tick)

    def _tick(self):
        self._countdown -= 1
        if self._countdown <= 0:
            self._do_check()
        else:
            self._counter_label.configure(
                text=f"Verificando novamente em {self._countdown}s..."
            )
            self._after_id = self.after(1000, self._tick)

    def _manual_retry(self):
        if self._after_id:
            self.after_cancel(self._after_id)
        self._do_check()

    def _do_check(self):
        current = self.lock_manager._read()
        if current is None:
            # lock foi liberado
            self.action = "enter"
            self.grab_release()
            self.destroy()
            return

        # atualiza dados do lock exibido
        self.lock_data = current
        self._info_label.configure(text=self._format_lock_info())
        self._update_override_state()

        # reinicia contagem
        self._countdown = self.retry_seconds
        self._counter_label.configure(
            text=f"Verificando novamente em {self._countdown}s..."
        )
        self._schedule_recheck()

    # ------------------------------------------------------------------ #
    #  Ações                                                               #
    # ------------------------------------------------------------------ #

    def _override(self):
        """Assume controle de lock órfão."""
        if self._after_id:
            self.after_cancel(self._after_id)
        self.action = "override"
        self.grab_release()
        self.destroy()

    def _cancel(self):
        if self._after_id:
            self.after_cancel(self._after_id)
        self.action = "cancel"
        self.grab_release()
        self.destroy()
