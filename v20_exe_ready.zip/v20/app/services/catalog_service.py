class CatalogService:
    def __init__(self, repo): self.repo = repo
    def list_values(self, table): return self.repo.list_simple(table)
    def ensure_value(self, table, value): return self.repo.get_or_create_simple(table, value)
