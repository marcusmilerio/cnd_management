"""
BackupService — V7.

- Copia main.db e catalog.db para backup/ com timestamp
- Mantém no máximo max_backups pares (remove os mais antigos)
- Chamado no fechamento (on_close) e manualmente pelo usuário
"""
import shutil
from datetime import datetime
from pathlib import Path


class BackupService:
    def __init__(self, main_db: str, catalog_db: str,
                 backup_dir: str, max_backups: int = 10):
        self.main_db    = Path(main_db)
        self.catalog_db = Path(catalog_db)
        self.backup_dir = Path(backup_dir)
        self.max_backups = max_backups

    def run(self) -> tuple[Path, Path] | None:
        """
        Executa o backup. Retorna (path_main_backup, path_catalog_backup)
        ou None se falhar.
        """
        try:
            self.backup_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            dest_main    = self.backup_dir / f"main_{ts}.db"
            dest_catalog = self.backup_dir / f"catalog_{ts}.db"
            shutil.copy2(self.main_db,    dest_main)
            shutil.copy2(self.catalog_db, dest_catalog)
            self._rotate()
            return dest_main, dest_catalog
        except Exception as e:
            print(f"[BACKUP ERROR] {e}")
            return None

    def _rotate(self):
        """Remove backups antigos mantendo apenas os max_backups mais recentes."""
        mains = sorted(self.backup_dir.glob("main_*.db"))
        while len(mains) > self.max_backups:
            oldest = mains.pop(0)
            ts     = oldest.stem[5:]   # "main_YYYYMMDD_HHMMSS" → "YYYYMMDD_HHMMSS"
            oldest.unlink(missing_ok=True)
            cat = self.backup_dir / f"catalog_{ts}.db"
            cat.unlink(missing_ok=True)

    def list_backups(self) -> list[dict]:
        """Retorna lista de backups disponíveis para exibição."""
        result = []
        for p in sorted(self.backup_dir.glob("main_*.db"), reverse=True):
            ts = p.stem[5:]
            try:
                dt = datetime.strptime(ts, "%Y%m%d_%H%M%S")
                dt_fmt = dt.strftime("%d/%m/%Y %H:%M:%S")
            except Exception:
                dt_fmt = ts
            cat = self.backup_dir / f"catalog_{ts}.db"
            result.append({
                "timestamp":  ts,
                "data_hora":  dt_fmt,
                "main":       str(p),
                "catalog":    str(cat),
                "cat_existe": cat.exists(),
                "tamanho_kb": round(p.stat().st_size / 1024, 1),
            })
        return result
