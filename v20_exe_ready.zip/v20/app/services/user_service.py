from app.security.auth import AuthManager
from app.security.password_hasher import hash_password, verify_password
from app.core.exceptions import ValidationError, AuthenticationError
from app.core.utils import now_iso, new_uuid
from app.core.enums import Profile

_DEFAULT_PASSWORD = "1234"
_VALID_PERFIS = {p.value for p in Profile}


class UserService:
    def __init__(self, user_repo, audit_service=None):
        self.user_repo     = user_repo
        self.audit_service = audit_service
        self.auth          = AuthManager(user_repo)

    def login(self, login: str, password: str) -> dict:
        try:
            user = self.auth.login(login, password)
            self.user_repo.touch_login(user["id"])
            if self.audit_service:
                self.audit_service.log_login_success(user)
            return user
        except AuthenticationError:
            if self.audit_service:
                self.audit_service.log_login_failure(login)
            raise

    def needs_password_change(self, user: dict) -> bool:
        return bool(user.get("must_change_password"))

    def change_password(self, user_id: int, senha_atual: str,
                         nova_senha: str, confirma: str) -> None:
        if len(nova_senha) < 4:
            raise ValidationError("A nova senha deve ter no mínimo 4 caracteres.")
        if nova_senha != confirma:
            raise ValidationError("A confirmação de senha não confere.")
        user = self.user_repo.get_by_id(user_id)
        if not user:
            raise ValidationError("Usuário não encontrado.")
        if not verify_password(senha_atual, user["senha_hash"]):
            raise ValidationError("Senha atual incorreta.")
        if verify_password(nova_senha, user["senha_hash"]):
            raise ValidationError("A nova senha deve ser diferente da senha atual.")
        self.user_repo.update_password(user_id, hash_password(nova_senha))

    def list_users(self) -> list[dict]:
        return self.user_repo.list_all()

    def create_user(self, nome: str, login: str, perfil: str, admin_user: dict) -> dict:
        nome  = nome.strip()
        login = login.strip().lower()
        if not nome:
            raise ValidationError("Nome é obrigatório.")
        if len(login) < 3:
            raise ValidationError("Login deve ter no mínimo 3 caracteres.")
        if perfil not in _VALID_PERFIS:
            raise ValidationError(f"Perfil inválido: {perfil}")
        if self.user_repo.get_by_login(login):
            raise ValidationError(f"Login '{login}' já está em uso.")
        user_id = self.user_repo.insert_user(
            uuid=new_uuid(), nome_usuario=nome, login=login,
            senha_hash=hash_password(_DEFAULT_PASSWORD),
            perfil=perfil, must_change_password=1,
        )
        if self.audit_service:
            self.audit_service.log("CREATE_USER","usuarios",admin_user,user_id,
                                    valor_novo=f"login={login},perfil={perfil}")
        return self.user_repo.get_by_id(user_id)

    def reset_password(self, user_id: int, admin_user: dict, reactivate: bool = False) -> None:
        """Reseta para '1234'. Se reactivate=True e o usuário estiver inativo, reativa também."""
        user = self.user_repo.get_by_id(user_id)
        if not user:
            raise ValidationError("Usuário não encontrado.")
        if user["login"] == "admin" and admin_user["login"] != "admin":
            raise ValidationError("Apenas o próprio admin pode resetar a senha do admin.")
        self.user_repo.update_password(user_id, hash_password(_DEFAULT_PASSWORD), must_change=1)
        if reactivate and not user.get("ativo"):
            self.user_repo.reactivate_user(user_id)
        acao = "reset+reativacao" if (reactivate and not user.get("ativo")) else "reset"
        if self.audit_service:
            self.audit_service.log("UPDATE_USER","usuarios",admin_user,user_id,
                                    campo_alterado="senha_hash", valor_novo=f"reset→1234 ({acao})")

    def deactivate_user(self, user_id: int, admin_user: dict) -> None:
        user = self.user_repo.get_by_id(user_id)
        if not user:
            raise ValidationError("Usuário não encontrado.")
        if user["login"] == "admin":
            raise ValidationError("O usuário admin não pode ser excluído.")
        if user_id == admin_user["id"]:
            raise ValidationError("Você não pode excluir sua própria conta.")
        self.user_repo.deactivate_user(user_id)
        if self.audit_service:
            self.audit_service.log("INACTIVATE_USER","usuarios",admin_user,user_id,
                                    valor_novo="ativo=0")
