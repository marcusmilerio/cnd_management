"""
CndService — V7.

Novidades:
  - Validação: data_emissao não pode ser futura
  - Validação: data_validade >= data_emissao
  - Validação: ambas obrigatórias
  - Unicidade: verifica antes de insert (erro claro ao usuário)
  - Auditoria: log_create_cnd com snapshot, log_update_cnd com diff
  - reactivate_cnd: reativação com REACTIVATE_CND auditado
  - Atomicidade: create e update usam shared_session no repositório
"""
import json
from dataclasses import asdict
from datetime import datetime, date

from app.core.normalizers import normalize_cnpj_display, digits_only, normalize_whitespace
from app.core.validators import validate_required, validate_uf, validate_cnpj
from app.core.exceptions import ValidationError
from app.core.utils import new_uuid, now_iso


class CndService:
    def __init__(self, cnd_repo, catalog_service, audit_service):
        self.cnd_repo        = cnd_repo
        self.catalog_service = catalog_service
        self.audit_service   = audit_service

    def get_cnd_by_id(self, cnd_id: int):
        return self.cnd_repo.get_by_id(cnd_id)

    # ── Create ────────────────────────────────────────────────────────────

    def create_cnd(self, cnd_model, usuario, sessao_id=None) -> int:
        data = asdict(cnd_model)
        self._assert_can_manage_esfera(usuario, data["esfera"])
        payload = self._build_payload(data, usuario, is_update=False)

        # Verificar unicidade antes do insert
        self._assert_unique(payload)

        cnd_id = self.cnd_repo.insert(payload)

        # Auditoria com snapshot completo
        snapshot = dict(payload)
        snapshot["id"] = cnd_id
        self.audit_service.log_create_cnd(cnd_id, snapshot, usuario, sessao_id)
        return cnd_id

    # ── Update ────────────────────────────────────────────────────────────

    def update_cnd(self, cnd_id: int, cnd_model, usuario, sessao_id=None) -> int:
        existing = self.cnd_repo.get_by_id(cnd_id)
        if not existing:
            raise ValueError("Registro de CND não encontrado para edição.")
        self._assert_can_manage_esfera(usuario, existing["esfera"])

        data = asdict(cnd_model)
        payload = self._build_payload(data, usuario, is_update=True)

        # Unicidade: verificar se a nova chave conflita com OUTRO registro
        self._assert_unique(payload, exclude_id=cnd_id)

        self.cnd_repo.update(cnd_id, payload)

        # Auditoria com diff
        after = dict(payload)
        after["id"] = cnd_id
        self.audit_service.log_update_cnd(cnd_id, existing, after, usuario, sessao_id)
        return cnd_id

    # ── Inactivate ────────────────────────────────────────────────────────

    def inactivate_cnd(self, cnd_id: int, motivo: str, usuario: dict, sessao_id=None) -> int:
        motivo_n = normalize_whitespace(motivo)
        if not motivo_n:
            raise ValidationError("O motivo da inativação é obrigatório.")
        existing = self.cnd_repo.get_by_id(cnd_id)
        if not existing:
            raise ValueError("Registro de CND não encontrado.")
        if int(existing.get("registro_ativo") or 0) != 1:
            raise ValidationError("Esta CND já está inativa.")
        self._assert_can_manage_esfera(usuario, existing["esfera"])

        updated_at = now_iso()
        self.cnd_repo.inactivate(cnd_id, motivo_n, usuario["id"], updated_at)
        self.audit_service.log_inactivate_cnd(cnd_id, motivo_n, existing, usuario, sessao_id)
        return cnd_id

    # ── Reactivate ────────────────────────────────────────────────────────

    def reactivate_cnd(self, cnd_id: int, usuario: dict, sessao_id=None) -> int:
        existing = self.cnd_repo.get_by_id(cnd_id)
        if not existing:
            raise ValueError("Registro de CND não encontrado.")
        if int(existing.get("registro_ativo") or 0) == 1:
            raise ValidationError("Esta CND já está ativa.")
        self._assert_can_manage_esfera(usuario, existing["esfera"])

        updated_at = now_iso()
        self.cnd_repo.reactivate(cnd_id, usuario["id"], updated_at)
        self.audit_service.log_reactivate_cnd(cnd_id, existing, usuario, sessao_id)
        return cnd_id

    # ── Comunicação ───────────────────────────────────────────────────────

    def get_comunicacoes(self, cnd_id: int) -> list[str]:
        return self.cnd_repo.list_comunicacoes(cnd_id)

    def save_comunicacoes(self, cnd_id: int, filiais: list[str], usuario, sessao_id=None):
        filiais_norm = list(dict.fromkeys(   # preserva ordem, remove duplicatas
            normalize_whitespace(f) for f in filiais if normalize_whitespace(f)
        ))
        self.cnd_repo.set_comunicacoes(cnd_id, filiais_norm, usuario["id"])
        resumo = ", ".join(filiais_norm)
        self.cnd_repo.update_comunicacao_resumo(cnd_id, resumo)
        self.audit_service.log(
            "UPDATE_COMUNICACAO", "cnd_comunicacoes", usuario, cnd_id, sessao_id,
            valor_novo=resumo,
        )

    # ── Permissões ────────────────────────────────────────────────────────

    def can_manage_esfera(self, usuario: dict, esfera: str) -> bool:
        return self._profile_allows_esfera((usuario or {}).get("perfil", ""), esfera)

    def _assert_can_manage_esfera(self, usuario: dict, esfera: str):
        if not self.can_manage_esfera(usuario, esfera):
            raise PermissionError("Seu perfil não permite alterar registros desta esfera.")

    def _profile_allows_esfera(self, perfil: str, esfera: str) -> bool:
        perfil = (perfil or "").upper().strip()
        esfera = normalize_whitespace(esfera)
        if perfil == "ADMIN":            return True
        if perfil == "CONSULTA":         return False
        if perfil == "EDITOR_FEDERAL":   return esfera == "Federal"
        if perfil == "EDITOR_ESTADUAL":  return esfera == "Estadual"
        if perfil == "EDITOR_MUNICIPAL": return esfera == "Municipal"
        return False

    # ── Unicidade ─────────────────────────────────────────────────────────

    def _assert_unique(self, payload: dict, exclude_id: int | None = None):
        existing_id = self.cnd_repo.find_by_unique_key(
            empresa_grupo_informado = payload["empresa_grupo_informado"],
            filial_informada        = payload["filial_informada"],
            cnpj_numeros            = payload["cnpj_numeros"],
            esfera                  = payload["esfera"],
            uf                      = payload["uf"],
            orgao_emissor_informado = payload["orgao_emissor_informado"],
        )
        if existing_id is not None and existing_id != exclude_id:
            raise ValidationError(
                f"Já existe uma CND cadastrada com esta combinação:\n"
                f"  Empresa: {payload['empresa_grupo_informado']}\n"
                f"  Filial: {payload['filial_informada']}\n"
                f"  CNPJ: {payload['cnpj_informado']}\n"
                f"  Esfera: {payload['esfera']}\n"
                f"  UF: {payload['uf']}\n"
                f"  Órgão: {payload['orgao_emissor_informado']}\n\n"
                f"Se for uma renovação, edite o registro existente (ID #{existing_id})."
            )

    # ── Build payload ─────────────────────────────────────────────────────

    def _build_payload(self, data: dict, usuario: dict, is_update: bool) -> dict:
        # Campos obrigatórios
        validate_required("Esfera",         data["esfera"])
        validate_required("Empresa/Grupo",  data["empresa_grupo_informado"])
        validate_required("Filial",         data["filial_informada"])
        validate_required("UF",             data["uf"])
        validate_required("Local",          data["local_informado"])
        validate_required("CNPJ",           data["cnpj_informado"])
        validate_required("Órgão emissor",  data["orgao_emissor_informado"])
        validate_required("Criticidade",    data["criticidade_informada"])
        validate_required("Status CND",     data["status_cnd_informado"])
        validate_required("Data de emissão",data["data_emissao"])
        validate_required("Data de validade",data["data_validade"])

        validate_uf(data["uf"])
        validate_cnpj(data["cnpj_informado"])

        # Validações de data
        self._validate_dates(data["data_emissao"], data["data_validade"])

        # Catálogo
        empresa_id = self.catalog_service.ensure_value("empresas_grupos",  data["empresa_grupo_informado"])
        filial_id  = self.catalog_service.ensure_value("filiais",          data["filial_informada"])
        local_id   = self.catalog_service.ensure_value("locais",           data["local_informado"])
        orgao_id   = self.catalog_service.ensure_value("orgaos_emissores", data["orgao_emissor_informado"])
        crit_id    = self.catalog_service.ensure_value("criticidades",     data["criticidade_informada"])
        status_id  = self.catalog_service.ensure_value("status_cnd",       data["status_cnd_informado"])

        status_proc_id = (
            self.catalog_service.ensure_value("status_processo", data["status_processo_informado"])
            if data.get("status_processo_informado") else None
        )
        resp_id = (
            self.catalog_service.ensure_value("responsaveis", data["responsavel_informado"])
            if data.get("responsavel_informado") else None
        )
        anal_id = (
            self.catalog_service.ensure_value("analistas_filial", data["analista_filial_informado"])
            if data.get("analista_filial_informado") else None
        )

        # dias_para_vencer: calculado dinamicamente no SQL (list_summary).
        # Gravamos NULL aqui — o campo no banco existe por compatibilidade.
        payload = {
            "esfera":                       normalize_whitespace(data["esfera"]),
            "empresa_grupo_id":             empresa_id,
            "empresa_grupo_informado":      normalize_whitespace(data["empresa_grupo_informado"]),
            "filial_id":                    filial_id,
            "filial_informada":             normalize_whitespace(data["filial_informada"]),
            "uf":                           data["uf"].upper(),
            "local_id":                     local_id,
            "local_informado":              normalize_whitespace(data["local_informado"]),
            "cnpj_informado":               normalize_cnpj_display(data["cnpj_informado"]),
            "cnpj_numeros":                 digits_only(data["cnpj_informado"]),
            "inscricao_estadual":           normalize_whitespace(data.get("inscricao_estadual","") or ""),
            "inscricao_municipal":          normalize_whitespace(data.get("inscricao_municipal","") or ""),
            "orgao_emissor_id":             orgao_id,
            "orgao_emissor_informado":      normalize_whitespace(data["orgao_emissor_informado"]),
            "criticidade_id":               crit_id,
            "criticidade_informada":        normalize_whitespace(data["criticidade_informada"]),
            "status_cnd_id":                status_id,
            "status_cnd_informado":         normalize_whitespace(data["status_cnd_informado"]),
            "numero_certidao":              normalize_whitespace(data.get("numero_certidao","") or ""),
            "prazo_vencimento_texto":       normalize_whitespace(data.get("prazo_vencimento_texto","") or ""),
            "mapeamento":                   normalize_whitespace(data.get("mapeamento","") or ""),
            "informacoes_filial":           normalize_whitespace(data.get("informacoes_filial","") or ""),
            "responsavel_id":               resp_id,
            "responsavel_informado":        normalize_whitespace(data.get("responsavel_informado","") or ""),
            "analista_filial_id":           anal_id,
            "analista_filial_informado":    normalize_whitespace(data.get("analista_filial_informado","") or ""),
            "comunicacao_resumo":           normalize_whitespace(data.get("comunicacao_resumo","") or ""),
            "obs_estracta":                 normalize_whitespace(data.get("obs_estracta","") or ""),
            "status_processo_id":           status_proc_id,
            "status_processo_informado":    normalize_whitespace(data.get("status_processo_informado","") or ""),
            "obs_status":                   normalize_whitespace(data.get("obs_status","") or ""),
            "obs_filial":                   normalize_whitespace(data.get("obs_filial","") or ""),
            "observacoes":                  normalize_whitespace(data.get("observacoes","") or ""),
            "data_emissao":                 data["data_emissao"],
            "data_validade":                data["data_validade"],
            "dias_para_vencer":             None,  # calculado no SQL
            "caminho_pdf":                  normalize_whitespace(data.get("caminho_pdf","") or ""),
            "versao_registro":              int(data.get("versao_registro") or 1),
        }

        if is_update:
            payload["atualizado_por_usuario_id"] = usuario["id"]
            payload["atualizado_em"]             = now_iso()
            payload["versao_registro"]           = payload["versao_registro"] + 1
        else:
            payload["uuid"]                  = new_uuid()
            payload["registro_ativo"]        = 1
            payload["registro_status"]       = "Ativo"
            payload["motivo_inativacao"]     = ""
            payload["criado_por_usuario_id"] = usuario["id"]
            payload["criado_em"]             = now_iso()

        return payload

    @staticmethod
    def _validate_dates(emissao_iso: str, validade_iso: str):
        hoje = date.today()
        try:
            d_emi = datetime.fromisoformat(emissao_iso).date()
        except Exception:
            raise ValidationError("Data de emissão inválida.")
        try:
            d_val = datetime.fromisoformat(validade_iso).date()
        except Exception:
            raise ValidationError("Data de validade inválida.")

        if d_emi > hoje:
            raise ValidationError("A data de emissão não pode ser uma data futura.")
        if d_val < d_emi:
            raise ValidationError("A data de validade não pode ser anterior à data de emissão.")
