"""
AuditService — V7.

Eventos obrigatórios (Bloco 7 do questionário):
  CREATE_CND      → snapshot completo em payload_json
  UPDATE_CND      → diff campo→antes/depois em payload_json
  INACTIVATE_CND  → motivo + snapshot
  REACTIVATE_CND  → snapshot
  LOGIN_SUCCESS   → usuario + maquina
  LOGIN_FAILURE   → login tentado + maquina
  LOCK_OVERRIDE   → quem tinha o lock + quem assumiu
  INTEGRITY_OVERRIDE → hashes + usuário

Campos funcionais ignorados no diff (infraestrutura interna):
  uuid, integrity_signature, versao_registro,
  criado_em, criado_por_usuario_id,
  atualizado_em, atualizado_por_usuario_id,
  inativado_em, inativado_por_usuario_id,
  registro_ativo, dias_para_vencer
"""
import json
from app.core.utils import get_hostname, now_iso

# Campos que NÃO entram no diff funcional
_SKIP_DIFF = frozenset({
    "uuid", "integrity_signature", "versao_registro",
    "criado_em", "criado_por_usuario_id",
    "atualizado_em", "atualizado_por_usuario_id",
    "inativado_em", "inativado_por_usuario_id",
    "registro_ativo", "dias_para_vencer",
    "id", "empresa_grupo_id", "filial_id", "local_id",
    "orgao_emissor_id", "criticidade_id", "status_cnd_id",
    "status_processo_id", "responsavel_id", "analista_filial_id",
})


def _make_diff(before: dict, after: dict) -> dict:
    """
    Retorna apenas os campos que mudaram.
    Formato: {campo: {"antes": valor, "depois": valor}}
    NULL e string vazia são tratados como distintos.
    """
    diff = {}
    all_keys = set(before) | set(after)
    for k in all_keys:
        if k in _SKIP_DIFF:
            continue
        v_antes  = before.get(k)
        v_depois = after.get(k)
        # Normaliza None → None, resto para str para comparação justa
        if v_antes != v_depois:
            diff[k] = {"antes": v_antes, "depois": v_depois}
    return diff


def _snapshot(data: dict) -> dict:
    """Remove campos puramente internos do snapshot."""
    return {k: v for k, v in data.items() if k not in _SKIP_DIFF}


class AuditService:
    def __init__(self, repo):
        self.repo = repo

    # ── API genérica (compatibilidade com código existente) ──────────────

    def log(
        self,
        evento_tipo,
        tabela_alvo,
        usuario,
        registro_id=None,
        sessao_id=None,
        campo_alterado=None,
        valor_anterior=None,
        valor_novo=None,
        motivo=None,
        payload_json=None,
    ):
        self.repo.insert_event({
            "evento_tipo":    evento_tipo,
            "tabela_alvo":    tabela_alvo,
            "registro_id":    registro_id,
            "payload_json":   json.dumps(payload_json, ensure_ascii=False) if payload_json else None,
            "campo_alterado": campo_alterado,
            "valor_anterior": str(valor_anterior) if valor_anterior is not None else None,
            "valor_novo":     str(valor_novo)     if valor_novo     is not None else None,
            "motivo":         motivo,
            "usuario_id":     usuario["id"]    if usuario else None,
            "usuario_login":  usuario["login"] if usuario else None,
            "maquina_nome":   get_hostname(),
            "evento_em":      now_iso(),
            "sessao_id":      sessao_id,
        })

    # ── APIs específicas ─────────────────────────────────────────────────

    def log_create_cnd(self, cnd_id: int, snapshot: dict, usuario: dict, sessao_id=None):
        """CREATE_CND com snapshot completo."""
        self.log(
            "CREATE_CND", "cnds", usuario, cnd_id, sessao_id,
            payload_json={"evento": "CREATE_CND", "snapshot": _snapshot(snapshot)},
        )

    def log_update_cnd(self, cnd_id: int, before: dict, after: dict,
                       usuario: dict, sessao_id=None):
        """UPDATE_CND com diff campo a campo."""
        diff = _make_diff(before, after)
        if not diff:
            return  # nada mudou de fato
        self.log(
            "UPDATE_CND", "cnds", usuario, cnd_id, sessao_id,
            payload_json={"evento": "UPDATE_CND", "diff": diff},
        )

    def log_inactivate_cnd(self, cnd_id: int, motivo: str, snapshot: dict,
                            usuario: dict, sessao_id=None):
        self.log(
            "INACTIVATE_CND", "cnds", usuario, cnd_id, sessao_id,
            campo_alterado="registro_status",
            valor_anterior=snapshot.get("registro_status", "Ativo"),
            valor_novo="Inativo",
            motivo=motivo,
            payload_json={"evento": "INACTIVATE_CND", "motivo": motivo,
                          "snapshot_antes": _snapshot(snapshot)},
        )

    def log_reactivate_cnd(self, cnd_id: int, snapshot: dict,
                            usuario: dict, sessao_id=None):
        self.log(
            "REACTIVATE_CND", "cnds", usuario, cnd_id, sessao_id,
            campo_alterado="registro_status",
            valor_anterior="Inativo",
            valor_novo="Ativo",
            payload_json={"evento": "REACTIVATE_CND",
                          "snapshot_antes": _snapshot(snapshot)},
        )

    def log_login_success(self, usuario: dict, sessao_id=None):
        self.log("LOGIN_SUCCESS", "usuarios", usuario, usuario["id"], sessao_id)

    def log_login_failure(self, login_tentado: str, maquina: str | None = None):
        """LOGIN_FAILURE — sem usuário autenticado."""
        self.repo.insert_event({
            "evento_tipo":    "LOGIN_FAILURE",
            "tabela_alvo":    "usuarios",
            "registro_id":    None,
            "payload_json":   json.dumps({"login_tentado": login_tentado}),
            "campo_alterado": None,
            "valor_anterior": None,
            "valor_novo":     None,
            "motivo":         "Credenciais inválidas",
            "usuario_id":     None,
            "usuario_login":  login_tentado,
            "maquina_nome":   maquina or get_hostname(),
            "evento_em":      now_iso(),
            "sessao_id":      None,
        })

    def log_lock_override(self, lock_data_anterior: dict,
                           usuario: dict, sessao_id=None):
        self.log(
            "LOCK_OVERRIDE", "system", usuario, None, sessao_id,
            payload_json={
                "evento": "LOCK_OVERRIDE",
                "lock_anterior": lock_data_anterior,
                "assumido_por": usuario.get("login"),
            },
        )

    def log_integrity_override(self, hashes_info: dict,
                                usuario: dict, sessao_id=None):
        self.log(
            "INTEGRITY_OVERRIDE", "system", usuario, None, sessao_id,
            payload_json={"evento": "INTEGRITY_OVERRIDE", **hashes_info},
        )
