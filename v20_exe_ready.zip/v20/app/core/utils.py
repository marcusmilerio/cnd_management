from datetime import datetime
from pathlib import Path
import socket, uuid

def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")

def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p

def get_hostname() -> str:
    return socket.gethostname()

def new_uuid() -> str:
    return str(uuid.uuid4())
