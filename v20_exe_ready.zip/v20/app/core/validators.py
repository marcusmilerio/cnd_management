from .exceptions import ValidationError
from .normalizers import digits_only
VALID_UFS = {"AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG","PA","PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO"}

def validate_required(label: str, value: str | None) -> None:
    if not (value or "").strip():
        raise ValidationError(f"{label} é obrigatório.")

def validate_uf(uf: str) -> None:
    if (uf or "").upper() not in VALID_UFS:
        raise ValidationError("UF inválida.")

def validate_cnpj(value: str) -> None:
    if len(digits_only(value)) != 14:
        raise ValidationError("CNPJ deve conter 14 dígitos.")
