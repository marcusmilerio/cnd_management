class AppError(Exception):
    pass

class IntegrityError(AppError):
    pass

class LockInUseError(AppError):
    """
    Levantado quando o lock de uso exclusivo já está ativo.
    lock_data: dict com os dados do lock atual (quem está usando, heartbeat etc.)
    """
    def __init__(self, message: str, lock_data: dict | None = None) -> None:
        super().__init__(message)
        self.lock_data = lock_data or {}

class ValidationError(AppError):
    pass

class AuthenticationError(AppError):
    pass

class PermissionError(AppError):
    pass
