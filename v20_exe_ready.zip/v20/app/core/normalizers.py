import re

def normalize_whitespace(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").strip())

def normalize_upper(value: str) -> str:
    return normalize_whitespace(value).upper()

def digits_only(value: str) -> str:
    return re.sub(r"\D", "", value or "")

def normalize_cnpj_display(value: str) -> str:
    digits = digits_only(value)
    if len(digits) != 14:
        return value.strip()
    return f"{digits[:2]}.{digits[2:5]}.{digits[5:8]}/{digits[8:12]}-{digits[12:]}"


import unicodedata

def strip_accents(value: str) -> str:
    """Remove acentos para comparação sem acento."""
    return "".join(
        c for c in unicodedata.normalize("NFD", value or "")
        if unicodedata.category(c) != "Mn"
    )
