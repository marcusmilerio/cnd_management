from __future__ import annotations

import sys
from pathlib import Path


def get_app_root() -> Path:
    """
    Retorna a pasta-base da aplicação.

    - Empacotado (.exe): pasta onde está o executável
    - Python normal: raiz do projeto (pasta que contém main.py, data, backup, config.json)
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def get_config_path() -> Path:
    return get_app_root() / "config.json"


def get_data_dir() -> Path:
    return get_app_root() / "data"


def get_backup_dir_default() -> Path:
    return get_app_root() / "backup"


def resolve_external_path(raw_path: str | None, *, default_dir: Path) -> Path:
    """
    Resolve um caminho configurado para um caminho externo e persistente.

    Regras:
    - vazio/None -> usa default_dir
    - absoluto -> preserva
    - relativo   -> relativo à pasta da aplicação (ao lado do .exe)
    """
    if not raw_path:
        return default_dir

    p = Path(raw_path)
    if p.is_absolute():
        return p
    return get_app_root() / p
