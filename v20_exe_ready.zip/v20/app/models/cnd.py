from dataclasses import dataclass
from typing import Optional


@dataclass
class CND:
    esfera: str
    empresa_grupo_informado: str
    filial_informada: str
    uf: str
    local_informado: str
    cnpj_informado: str
    orgao_emissor_informado: str
    criticidade_informada: str
    status_cnd_informado: str

    inscricao_estadual: str = ""
    inscricao_municipal: str = ""
    numero_certidao: str = ""
    prazo_vencimento_texto: str = ""
    mapeamento: str = ""
    informacoes_filial: str = ""
    responsavel_informado: str = ""
    analista_filial_informado: str = ""
    comunicacao_resumo: str = ""
    obs_estracta: str = ""
    status_processo_informado: str = ""
    obs_status: str = ""
    obs_filial: str = ""
    observacoes: str = ""
    data_emissao: str = ""
    data_validade: str = ""
    caminho_pdf: str = ""

    id: Optional[int] = None
    uuid: str = ""
    registro_ativo: int = 1
    registro_status: str = "Ativo"
    motivo_inativacao: str = ""
    dias_para_vencer: Optional[int] = None
    versao_registro: int = 1
