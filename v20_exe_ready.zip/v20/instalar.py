"""
CND Manager — Instalador com GUI
Requer Python 3.11+ e customtkinter instalado.
Executar: python instalar.py
"""
import os
import sys
import json
import shutil
import subprocess
import threading
from pathlib import Path
import customtkinter as ctk
from tkinter import filedialog, messagebox

ctk.set_appearance_mode("system")
ctk.set_default_color_theme("blue")

APP_NAME    = "CND Manager"
APP_VERSION = "1.0.0"
SCRIPT_DIR  = Path(__file__).parent.resolve()


class InstaladorWindow(ctk.CTk):

    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} — Instalador v{APP_VERSION}")
        self.geometry("620x580")
        self.resizable(False, False)
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"620x580+{(sw-620)//2}+{(sh-580)//2}")

        self._step = 0          # 0=boas-vindas 1=caminhos 2=instalando 3=concluído
        self._install_dir  = ctk.StringVar(value=str(Path.home() / APP_NAME))
        self._data_dir     = ctk.StringVar(value="")   # relativo ao install_dir
        self._backup_dir   = ctk.StringVar(value="")
        self._create_shortcut = ctk.BooleanVar(value=True)

        self._build()
        self._show_step(0)

    # ── Layout base ───────────────────────────────────────────────────

    def _build(self):
        # Cabeçalho
        hdr = ctk.CTkFrame(self, height=70, corner_radius=0, fg_color="#1f538d")
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        ctk.CTkLabel(hdr, text=f"  {APP_NAME}",
                     font=ctk.CTkFont(size=20, weight="bold"),
                     text_color="white").pack(side="left", padx=20, pady=15)
        ctk.CTkLabel(hdr, text=f"v{APP_VERSION}",
                     font=ctk.CTkFont(size=11),
                     text_color="#aaccff").pack(side="right", padx=20)

        # Área de conteúdo
        self._content = ctk.CTkFrame(self, fg_color="transparent")
        self._content.pack(fill="both", expand=True, padx=30, pady=20)

        # Botões de navegação
        nav = ctk.CTkFrame(self, fg_color="transparent", height=50)
        nav.pack(fill="x", padx=30, pady=(0,16))
        nav.pack_propagate(False)
        self._btn_back = ctk.CTkButton(nav, text="◀  Voltar", width=110,
                                        fg_color="gray30",
                                        command=self._prev_step)
        self._btn_back.pack(side="left")
        self._btn_next = ctk.CTkButton(nav, text="Avançar  ▶", width=130,
                                        command=self._next_step)
        self._btn_next.pack(side="right")
        self._btn_cancel = ctk.CTkButton(nav, text="Cancelar", width=90,
                                          fg_color="gray20", hover_color="gray30",
                                          command=self.quit)
        self._btn_cancel.pack(side="right", padx=(0,8))

    def _clear_content(self):
        for w in self._content.winfo_children():
            w.destroy()

    # ── Navegação ─────────────────────────────────────────────────────

    def _show_step(self, step: int):
        self._step = step
        self._clear_content()
        handlers = [
            self._step_boas_vindas,
            self._step_caminhos,
            self._step_instalando,
            self._step_concluido,
        ]
        handlers[step]()
        self._btn_back.configure(state="normal" if step in (1,) else "disabled")
        if step == 0:
            self._btn_next.configure(text="Avançar  ▶", state="normal")
        elif step == 1:
            self._btn_next.configure(text="Instalar  ▶", state="normal")
        elif step >= 2:
            self._btn_next.configure(state="disabled")
            self._btn_back.configure(state="disabled")
            self._btn_cancel.configure(state="disabled")

    def _next_step(self):
        if self._step == 0: self._show_step(1)
        elif self._step == 1: self._start_install()

    def _prev_step(self):
        if self._step == 1: self._show_step(0)

    # ── Passo 0: Boas-vindas ──────────────────────────────────────────

    def _step_boas_vindas(self):
        ctk.CTkLabel(self._content,
                     text="Bem-vindo ao instalador do CND Manager",
                     font=ctk.CTkFont(size=16, weight="bold")).pack(pady=(10,20))

        txt = (
            "Este assistente irá guiá-lo na instalação do CND Manager.\n\n"
            "O que será feito:\n"
            "  • Copiar os arquivos do aplicativo para a pasta escolhida\n"
            "  • Configurar as pastas de dados e backup\n"
            "  • Gerar o arquivo de configuração (config.json)\n"
            "  • Criar um atalho para execução do aplicativo\n\n"
            "Recomendação para uso em rede:\n"
            "  Instale em uma pasta compartilhada acessível a todos os usuários\n"
            "  (ex: \\\\servidor\\CND_Manager).\n\n"
            "Clique em Avançar para configurar os caminhos de instalação."
        )
        ctk.CTkLabel(self._content, text=txt, justify="left",
                     font=ctk.CTkFont(size=12),
                     wraplength=520).pack(anchor="w", pady=(0,10))

        ctk.CTkLabel(self._content,
                     text="⚠  Python 3.11+ com customtkinter e matplotlib são necessários.",
                     text_color="orange",
                     font=ctk.CTkFont(size=11)).pack(anchor="w", pady=(10,0))

    # ── Passo 1: Caminhos ─────────────────────────────────────────────

    def _step_caminhos(self):
        ctk.CTkLabel(self._content, text="Configuração de Pastas",
                     font=ctk.CTkFont(size=15, weight="bold")).pack(pady=(0,16))

        def _row(parent, label, var, btn_cmd):
            f = ctk.CTkFrame(parent, fg_color="transparent")
            f.pack(fill="x", pady=5)
            ctk.CTkLabel(f, text=label, width=140, anchor="w").pack(side="left")
            ctk.CTkEntry(f, textvariable=var, width=270).pack(side="left", padx=4)
            ctk.CTkButton(f, text="…", width=36, command=btn_cmd).pack(side="left")
            return f

        # Pasta de instalação
        _row(self._content, "Pasta de instalação:", self._install_dir,
             lambda: self._browse_dir(self._install_dir, "Pasta de instalação"))

        ctk.CTkLabel(self._content,
                     text="As pastas de dados e backup serão criadas dentro da pasta de instalação\n"
                          "caso você deixe os campos abaixo em branco.",
                     font=ctk.CTkFont(size=10), text_color="gray",
                     justify="left").pack(anchor="w", pady=(6,6))

        _row(self._content, "Pasta de dados\n(vazio = auto):", self._data_dir,
             lambda: self._browse_dir(self._data_dir, "Pasta de dados"))
        _row(self._content, "Pasta de backup\n(vazio = auto):", self._backup_dir,
             lambda: self._browse_dir(self._backup_dir, "Pasta de backup"))

        ctk.CTkCheckBox(self._content,
                        text="Criar arquivo de atalho (run.bat) na pasta de instalação",
                        variable=self._create_shortcut).pack(anchor="w", pady=(14,0))

        # Resumo dinâmico
        self._summary_lbl = ctk.CTkLabel(self._content, text="",
                                          font=ctk.CTkFont(size=10),
                                          text_color="gray", justify="left")
        self._summary_lbl.pack(anchor="w", pady=(12,0))
        self._install_dir.trace_add("write", lambda *_: self._update_summary())
        self._update_summary()

    def _browse_dir(self, var: ctk.StringVar, title: str):
        d = filedialog.askdirectory(title=title)
        if d:
            var.set(d)

    def _update_summary(self):
        inst = self._install_dir.get() or "?"
        data = self._data_dir.get()   or f"{inst}\\data"
        bk   = self._backup_dir.get() or f"{inst}\\backup"
        txt  = f"Resumo:\n  Instalação : {inst}\n  Dados      : {data}\n  Backup     : {bk}"
        if hasattr(self, "_summary_lbl"):
            self._summary_lbl.configure(text=txt)

    # ── Passo 2: Instalando ───────────────────────────────────────────

    def _step_instalando(self):
        ctk.CTkLabel(self._content, text="Instalando…",
                     font=ctk.CTkFont(size=15, weight="bold")).pack(pady=(20,16))
        self._progress = ctk.CTkProgressBar(self._content, width=480)
        self._progress.pack(pady=8)
        self._progress.set(0)
        self._log_box = ctk.CTkTextbox(self._content, height=200, state="disabled")
        self._log_box.pack(fill="x", pady=8)

    def _log(self, msg: str):
        self._log_box.configure(state="normal")
        self._log_box.insert("end", msg + "\n")
        self._log_box.see("end")
        self._log_box.configure(state="disabled")
        self.update()

    def _set_progress(self, v: float):
        self._progress.set(v)
        self.update()

    # ── Instalação real ───────────────────────────────────────────────

    def _start_install(self):
        install_dir = Path(self._install_dir.get().strip())
        if not install_dir or str(install_dir) == ".":
            messagebox.showerror("Erro", "Informe a pasta de instalação.")
            return

        data_dir   = Path(self._data_dir.get().strip())   if self._data_dir.get().strip()   else install_dir / "data"
        backup_dir = Path(self._backup_dir.get().strip()) if self._backup_dir.get().strip() else install_dir / "backup"

        self._show_step(2)

        def _do_install():
            try:
                # 1. Criar pastas
                self._log(f"Criando pastas…")
                install_dir.mkdir(parents=True, exist_ok=True)
                data_dir.mkdir(parents=True, exist_ok=True)
                backup_dir.mkdir(parents=True, exist_ok=True)
                self._set_progress(0.15)

                # 2. Copiar arquivos
                self._log("Copiando arquivos do aplicativo…")
                dirs_to_copy = ["app"]
                for d in dirs_to_copy:
                    src = SCRIPT_DIR / d
                    dst = install_dir / d
                    if src.exists():
                        if dst.exists():
                            shutil.rmtree(dst)
                        shutil.copytree(src, dst)
                        self._log(f"  ✓ {d}/")

                for f in ["main.py", "requirements.txt"]:
                    src = SCRIPT_DIR / f
                    if src.exists():
                        shutil.copy2(src, install_dir / f)
                        self._log(f"  ✓ {f}")
                self._set_progress(0.45)

                # 3. Copiar bancos limpos apenas se não existirem
                self._log("Configurando banco de dados…")
                for db in ["main.db", "catalog.db"]:
                    src = SCRIPT_DIR / "data" / db
                    dst = data_dir / db
                    if not dst.exists() and src.exists():
                        shutil.copy2(src, dst)
                        self._log(f"  ✓ {db} (banco inicial)")
                    elif dst.exists():
                        self._log(f"  · {db} (já existe, mantido)")
                self._set_progress(0.65)

                # 4. Gerar config.json com caminhos absolutos
                self._log("Gerando config.json…")
                src_cfg = SCRIPT_DIR / "config.json"
                cfg = json.loads(src_cfg.read_text(encoding="utf-8")) if src_cfg.exists() else {}
                cfg["paths"] = {
                    "main_db":        str(data_dir / "main.db"),
                    "catalog_db":     str(data_dir / "catalog.db"),
                    "integrity_file": str(data_dir / "integrity.dat"),
                    "lock_file":      str(data_dir / "app.lock"),
                    "backup_dir":     str(backup_dir),
                }
                (install_dir / "config.json").write_text(
                    json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
                self._log("  ✓ config.json")
                self._set_progress(0.80)

                # 5. Criar run.bat
                if self._create_shortcut.get():
                    self._log("Criando run.bat…")
                    bat = f'@echo off\ncd /d "{install_dir}"\npython main.py\npause\n'
                    bat_path = install_dir / "run.bat"
                    bat_path.write_text(bat, encoding="cp1252")
                    self._log(f"  ✓ run.bat")
                self._set_progress(0.95)

                # 6. Criar requirements_install.bat
                req_bat = (
                    "@echo off\n"
                    "echo Instalando dependências Python...\n"
                    "pip install customtkinter matplotlib\n"
                    "echo.\n"
                    "echo Pronto! Execute run.bat para iniciar o CND Manager.\n"
                    "pause\n"
                )
                (install_dir / "instalar_dependencias.bat").write_text(req_bat, encoding="cp1252")
                self._log("  ✓ instalar_dependencias.bat")

                self._set_progress(1.0)
                self._log("\n✅ Instalação concluída com sucesso!")
                self._log(f"\nPara iniciar: execute run.bat em\n{install_dir}")
                self.after(100, lambda: self._show_step(3))

            except Exception as ex:
                self._log(f"\n❌ Erro durante a instalação:\n{ex}")
                self.after(100, lambda: self._btn_next.configure(
                    state="disabled"))

        threading.Thread(target=_do_install, daemon=True).start()

    # ── Passo 3: Concluído ────────────────────────────────────────────

    def _step_concluido(self):
        self._btn_cancel.configure(state="normal", text="Fechar")
        ctk.CTkLabel(self._content, text="✅  Instalação concluída!",
                     font=ctk.CTkFont(size=18, weight="bold"),
                     text_color="#2a9d2a").pack(pady=(20,16))

        inst = self._install_dir.get()
        txt = (
            f"O CND Manager foi instalado em:\n{inst}\n\n"
            "Próximos passos:\n"
            "  1. Execute instalar_dependencias.bat (uma vez por máquina)\n"
            "     para instalar Python e as bibliotecas necessárias.\n\n"
            "  2. Execute run.bat para iniciar o CND Manager.\n\n"
            "  3. No primeiro acesso, use:\n"
            "       Login: admin\n"
            "       Senha: admin123\n"
            "     Você será solicitado a trocar a senha imediatamente.\n\n"
            "  4. Para acesso em rede, compartilhe a pasta de instalação\n"
            "     e certifique-se que cada usuário tem Python instalado\n"
            "     ou execute instalar_dependencias.bat em cada máquina."
        )
        ctk.CTkLabel(self._content, text=txt, justify="left",
                     font=ctk.CTkFont(size=12),
                     wraplength=520).pack(anchor="w")


if __name__ == "__main__":
    app = InstaladorWindow()
    app.mainloop()
