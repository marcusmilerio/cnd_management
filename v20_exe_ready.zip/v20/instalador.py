"""
Instalador CND Manager — GUI com CustomTkinter.

Fluxo:
  1. Bem-vindo
  2. Escolha de pastas (instalação, dados, backup)
  3. Confirmação + instalação
  4. Conclusão

O instalador:
  - Copia todos os arquivos para a pasta de instalação
  - Gera config.json com os caminhos escolhidos
  - Cria atalho CND_Manager.bat (e .vbs para ocultar o console)
  - Verifica se Python está disponível
"""
import json
import os
import shutil
import sys
import subprocess
from pathlib import Path

try:
    import customtkinter as ctk
    from tkinter import filedialog, messagebox
except ImportError:
    print("ERRO: CustomTkinter não encontrado. Execute: pip install customtkinter")
    sys.exit(1)

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Diretório onde está o instalador (fonte dos arquivos)
_SRC = Path(__file__).parent.resolve()

_CONFIG_TEMPLATE = {
    "app_name":    "CND Manager",
    "version":     "1.0.0",
    "ui": {
        "theme":        "dark",
        "color_theme":  "blue"
    },
    "paths": {
        "main_db":        "{DATA}/main.db",
        "catalog_db":     "{DATA}/catalog.db",
        "integrity_file": "{DATA}/integrity.dat",
        "lock_file":      "{DATA}/app.lock",
        "backup_dir":     "{BACKUP}"
    },
    "security": {
        "sqlcipher_key_env":    "CND_DB_KEY",
        "fallback_sqlcipher_key": "cnd-manager-key-2024",
        "hmac_secret_env":      "CND_HMAC_SECRET",
        "fallback_hmac_secret": "cnd-manager-hmac-2024"
    },
    "lock": {
        "heartbeat_seconds":  15,
        "stale_after_seconds": 60,
        "retry_check_seconds": 10
    },
    "backup": {
        "max_backups": 30
    }
}


def _check_python() -> tuple[bool, str]:
    """Verifica se Python 3.11+ está disponível."""
    try:
        result = subprocess.run(
            [sys.executable, "--version"],
            capture_output=True, text=True)
        ver = result.stdout.strip() or result.stderr.strip()
        return True, ver
    except Exception:
        return False, ""


def _check_deps() -> list[str]:
    """Retorna lista de pacotes faltando."""
    needed = ["customtkinter", "matplotlib", "openpyxl"]
    missing = []
    for pkg in needed:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    return missing


def _install_deps(missing: list[str], log_fn):
    """Instala pacotes faltando via pip."""
    for pkg in missing:
        log_fn(f"Instalando {pkg}…")
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg, "--quiet"],
                check=True)
            log_fn(f"  ✓ {pkg} instalado")
        except subprocess.CalledProcessError:
            log_fn(f"  ✗ Falha ao instalar {pkg}")


def _copy_files(src: Path, dest: Path, log_fn):
    """Copia todos os arquivos da aplicação para dest."""
    excludes = {"instalador.py", "instalador.exe", "__pycache__",
                ".git", "*.pyc", "build", "dist"}

    def _should_skip(p: Path) -> bool:
        name = p.name
        return (name in excludes or name.endswith(".pyc") or
                "__pycache__" in str(p))

    dest.mkdir(parents=True, exist_ok=True)

    for item in src.rglob("*"):
        if _should_skip(item): continue
        rel = item.relative_to(src)
        target = dest / rel
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)
            log_fn(f"  Copiado: {rel}")


def _write_config(dest: Path, data_dir: Path, backup_dir: Path):
    """Gera config.json com caminhos absolutos."""
    cfg = json.loads(json.dumps(_CONFIG_TEMPLATE))  # deep copy
    cfg["paths"]["main_db"]        = str(data_dir / "main.db")
    cfg["paths"]["catalog_db"]     = str(data_dir / "catalog.db")
    cfg["paths"]["integrity_file"] = str(data_dir / "integrity.dat")
    cfg["paths"]["lock_file"]      = str(data_dir / "app.lock")
    cfg["paths"]["backup_dir"]     = str(backup_dir)

    with open(dest / "config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


def _create_launcher(dest: Path, python_exe: str):
    """Cria launcher .bat e .vbs (sem janela de console)."""
    bat = dest / "CND_Manager.bat"
    bat.write_text(
        f'@echo off\ncd /d "{dest}"\n"{python_exe}" main.py\n',
        encoding="cp1252")

    vbs = dest / "CND_Manager.vbs"
    vbs.write_text(
        f'Set ws = CreateObject("WScript.Shell")\n'
        f'ws.Run Chr(34) & "{bat}" & Chr(34), 0\n',
        encoding="utf-8")


# ══════════════════════════════════════════════════════════════════════════════
#  Interface gráfica
# ══════════════════════════════════════════════════════════════════════════════

class Installer(ctk.CTk):

    def __init__(self):
        super().__init__()
        self.title("CND Manager — Instalador")
        self.geometry("640x520")
        self.resizable(False, False)
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"640x520+{(sw-640)//2}+{(sh-520)//2}")

        # Caminhos escolhidos
        self._dir_install = ctk.StringVar(value=str(Path.home() / "CND_Manager"))
        self._dir_data    = ctk.StringVar()
        self._dir_backup  = ctk.StringVar()

        # Atualizar dados/backup quando instalação muda
        self._dir_install.trace_add("write", self._on_install_change)

        self._pages: list[ctk.CTkFrame] = []
        self._current = 0
        self._build_pages()
        self._show_page(0)

        # Inicializar defaults
        self._on_install_change()

    def _on_install_change(self, *_):
        base = Path(self._dir_install.get())
        self._dir_data.set(str(base / "data"))
        self._dir_backup.set(str(base / "backup"))

    # ── Páginas ───────────────────────────────────────────────────────

    def _build_pages(self):
        self._pages = [
            self._page_welcome(),
            self._page_folders(),
            self._page_confirm(),
            self._page_done(),
        ]

    def _show_page(self, idx: int):
        for p in self._pages:
            p.pack_forget()
        self._pages[idx].pack(fill="both", expand=True)
        self._current = idx

    # ── Página 1: Boas-vindas ─────────────────────────────────────────

    def _page_welcome(self) -> ctk.CTkFrame:
        f = ctk.CTkFrame(self, fg_color="transparent")
        ctk.CTkLabel(f, text="CND Manager",
                     font=ctk.CTkFont(size=28, weight="bold")).pack(pady=(60,8))
        ctk.CTkLabel(f, text="Assistente de Instalação",
                     font=ctk.CTkFont(size=14), text_color="gray").pack()

        py_ok, py_ver = _check_python()
        status_color = "green" if py_ok else "red"
        py_txt = f"✓ {py_ver}" if py_ok else "✗ Python não encontrado"
        ctk.CTkLabel(f, text=py_txt, text_color=status_color,
                     font=ctk.CTkFont(size=12)).pack(pady=(30,0))

        missing = _check_deps()
        if missing:
            ctk.CTkLabel(f,
                text=f"Pacotes a instalar: {', '.join(missing)}",
                text_color="orange", font=ctk.CTkFont(size=11)).pack(pady=4)
        else:
            ctk.CTkLabel(f, text="✓ Todas as dependências já instaladas",
                         text_color="green", font=ctk.CTkFont(size=11)).pack(pady=4)

        ctk.CTkLabel(f,
            text="Este assistente irá:\n"
                 "• Escolher onde instalar o CND Manager\n"
                 "• Definir pastas de dados e backup\n"
                 "• Criar um atalho para iniciar o sistema",
            font=ctk.CTkFont(size=12), justify="left").pack(pady=(20,0), padx=60, anchor="w")

        btn = ctk.CTkFrame(f, fg_color="transparent")
        btn.pack(side="bottom", fill="x", padx=30, pady=20)
        ctk.CTkButton(btn, text="Próximo →", width=140,
                      command=lambda: self._show_page(1),
                      state="normal" if py_ok else "disabled").pack(side="right")
        return f

    # ── Página 2: Pastas ──────────────────────────────────────────────

    def _page_folders(self) -> ctk.CTkFrame:
        f = ctk.CTkFrame(self, fg_color="transparent")
        ctk.CTkLabel(f, text="Configuração de pastas",
                     font=ctk.CTkFont(size=18, weight="bold")).pack(pady=(30,4))
        ctk.CTkLabel(f, text="Defina onde o CND Manager será instalado.",
                     text_color="gray").pack(pady=(0,20))

        def _folder_row(parent, label, var, row):
            ctk.CTkLabel(parent, text=label, anchor="w", width=140).grid(
                row=row, column=0, sticky="w", padx=(20,8), pady=8)
            ctk.CTkEntry(parent, textvariable=var, width=300).grid(
                row=row, column=1, sticky="ew", padx=4, pady=8)
            ctk.CTkButton(parent, text="…", width=36,
                command=lambda v=var: v.set(
                    filedialog.askdirectory(title=label) or v.get())
            ).grid(row=row, column=2, padx=(4,20), pady=8)

        grid = ctk.CTkFrame(f, fg_color="transparent")
        grid.pack(fill="x", padx=20)
        grid.grid_columnconfigure(1, weight=1)

        _folder_row(grid, "Pasta de instalação:", self._dir_install, 0)
        _folder_row(grid, "Pasta de dados:",      self._dir_data,    1)
        _folder_row(grid, "Pasta de backup:",     self._dir_backup,  2)

        ctk.CTkLabel(f,
            text="💡 A pasta de instalação pode ser um caminho de rede (ex: \\\\servidor\\CND)\n"
                 "     As pastas de dados e backup serão criadas automaticamente.",
            text_color="gray", font=ctk.CTkFont(size=11), justify="left").pack(
            pady=(16,0), padx=30, anchor="w")

        btn = ctk.CTkFrame(f, fg_color="transparent")
        btn.pack(side="bottom", fill="x", padx=30, pady=20)
        ctk.CTkButton(btn, text="← Voltar", width=100, fg_color="gray30",
                      command=lambda: self._show_page(0)).pack(side="left")
        ctk.CTkButton(btn, text="Próximo →", width=140,
                      command=self._go_confirm).pack(side="right")
        return f

    def _go_confirm(self):
        if not self._dir_install.get().strip():
            messagebox.showwarning("Atenção", "Escolha a pasta de instalação.")
            return
        self._show_page(2)

    # ── Página 3: Confirmação ─────────────────────────────────────────

    def _page_confirm(self) -> ctk.CTkFrame:
        f = ctk.CTkFrame(self, fg_color="transparent")
        ctk.CTkLabel(f, text="Confirmar instalação",
                     font=ctk.CTkFont(size=18, weight="bold")).pack(pady=(30,4))

        self._confirm_text = ctk.CTkTextbox(f, height=220, state="disabled")
        self._confirm_text.pack(fill="x", padx=30, pady=10)

        # Atualizar resumo quando esta página for exibida
        f.bind("<Visibility>", lambda _: self._update_confirm())

        btn = ctk.CTkFrame(f, fg_color="transparent")
        btn.pack(side="bottom", fill="x", padx=30, pady=20)
        ctk.CTkButton(btn, text="← Voltar", width=100, fg_color="gray30",
                      command=lambda: self._show_page(1)).pack(side="left")
        ctk.CTkButton(btn, text="Instalar", width=140,
                      fg_color="#1a5a1a", hover_color="#104010",
                      command=self._run_install).pack(side="right")
        return f

    def _update_confirm(self):
        txt = (
            f"Pasta de instalação:\n  {self._dir_install.get()}\n\n"
            f"Pasta de dados:\n  {self._dir_data.get()}\n\n"
            f"Pasta de backup:\n  {self._dir_backup.get()}\n\n"
            f"Python usado:\n  {sys.executable}\n\n"
            f"Será criado:\n  CND_Manager.bat  (iniciar sem console)\n"
            f"  CND_Manager.vbs  (iniciar sem console)\n"
            f"  config.json  (configuração com seus caminhos)\n"
        )
        self._confirm_text.configure(state="normal")
        self._confirm_text.delete("1.0", "end")
        self._confirm_text.insert("1.0", txt)
        self._confirm_text.configure(state="disabled")

    # ── Página 4: Instalação / Conclusão ──────────────────────────────

    def _page_done(self) -> ctk.CTkFrame:
        f = ctk.CTkFrame(self, fg_color="transparent")
        ctk.CTkLabel(f, text="Instalando…",
                     font=ctk.CTkFont(size=18, weight="bold")).pack(pady=(30,4))

        self._log = ctk.CTkTextbox(f, height=260, state="disabled")
        self._log.pack(fill="x", padx=30, pady=10)

        self._done_btn = ctk.CTkButton(f, text="Fechar", width=140,
                                        state="disabled", command=self.destroy)
        self._done_btn.pack(side="bottom", pady=20)
        return f

    def _log_line(self, msg: str):
        self._log.configure(state="normal")
        self._log.insert("end", msg + "\n")
        self._log.see("end")
        self._log.configure(state="disabled")
        self.update()

    def _run_install(self):
        self._update_confirm()
        self._show_page(3)
        self.update()

        install_dir = Path(self._dir_install.get())
        data_dir    = Path(self._dir_data.get())
        backup_dir  = Path(self._dir_backup.get())

        try:
            # 1. Dependências
            missing = _check_deps()
            if missing:
                self._log_line(f"Instalando dependências: {', '.join(missing)}")
                _install_deps(missing, self._log_line)

            # 2. Copiar arquivos
            self._log_line(f"\nCopiando arquivos para:\n  {install_dir}")
            _copy_files(_SRC, install_dir, self._log_line)

            # 3. Criar pastas de dados e backup
            data_dir.mkdir(parents=True, exist_ok=True)
            backup_dir.mkdir(parents=True, exist_ok=True)
            self._log_line(f"\nPasta de dados criada:  {data_dir}")
            self._log_line(f"Pasta de backup criada: {backup_dir}")

            # 4. Gerar config.json
            _write_config(install_dir, data_dir, backup_dir)
            self._log_line("\nconfig.json gerado com seus caminhos.")

            # 5. Criar launcher
            _create_launcher(install_dir, sys.executable)
            self._log_line("Launcher CND_Manager.bat criado.")
            self._log_line("Launcher CND_Manager.vbs criado (sem console).")

            self._log_line("\n" + "─"*50)
            self._log_line("✓ Instalação concluída com sucesso!")
            self._log_line(f"\nPara iniciar o sistema, execute:")
            self._log_line(f"  {install_dir / 'CND_Manager.vbs'}")
            self._log_line("\nDica: crie um atalho para CND_Manager.vbs")
            self._log_line("      na área de trabalho de cada usuário.")

        except Exception as e:
            self._log_line(f"\n✗ ERRO: {e}")
            import traceback
            self._log_line(traceback.format_exc())

        self._done_btn.configure(state="normal")


if __name__ == "__main__":
    app = Installer()
    app.mainloop()
